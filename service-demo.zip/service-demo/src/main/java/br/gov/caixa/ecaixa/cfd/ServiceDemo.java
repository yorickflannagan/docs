package br.gov.caixa.ecaixa.cfd;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.crypthing.things.appservice.ThingsService;
import org.crypthing.things.snmp.ErrorBean;
import org.crypthing.things.snmp.ProcessingEvent;
import org.crypthing.things.snmp.SignalBean;
import org.crypthing.things.snmp.ProcessingEvent.ProcessingEventType;
import org.eclipse.microprofile.config.inject.ConfigProperty;


@Path("/service")
public class ServiceDemo
{

	@Inject
	ThingsService _service;
	@ConfigProperty(name = "org.crypthing.things.endpoint", defaultValue = "myEndpoint")
	String _endpoint;

    @GET
    @Produces(MediaType.TEXT_PLAIN)
	public Response getSomething(@QueryParam("type") int type)
	{
		Response.Status status;
		String entity;
		try
		{
			if (type == 0) throw new RuntimeException();
			if (type == 1)
			{
				// Ocorreu uma falha de negócio: log warning
				status = Response.Status.BAD_REQUEST;
				entity = "Falha na validação do request";
				_service.warning(new ProcessingEvent(ProcessingEventType.warning, new SignalBean(_endpoint, entity).encode()));
			}
			else
			{
				// Operação de negócio bem sucedida: log info (se for o caso)
				status = Response.Status.OK;
				entity = "Operação bem sucedida";
				_service.info(new ProcessingEvent(ProcessingEventType.info, new SignalBean(_endpoint, entity).encode()));
			}
		}
		catch (final Exception e)
		{
			// Erro interno: log error
			status = Response.Status.INTERNAL_SERVER_ERROR;
			entity = "Ocorreu um erro na execução";
			_service.error(new ProcessingEvent(ProcessingEventType.error, new ErrorBean(_endpoint, entity, e).encode()));
		}

		// Bilhete a operação
		if (status == Response.Status.OK) _service.success();
		else _service.failure();

		return Response.status(status).entity(entity).build();
    }
}