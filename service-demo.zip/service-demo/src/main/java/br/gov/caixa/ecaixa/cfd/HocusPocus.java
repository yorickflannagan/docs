package br.gov.caixa.ecaixa.cfd;

import javax.inject.Singleton;

import org.crypthing.things.appservice.ThingsService;

/**
 * Trata-se de gatilho, indispensável porque o quarkus descobre as anotações CDI
 * exclusivamente em tempo de compilação. Como o serviço é distribuído num JAR
 * à parte, a criação desta classe é necessária para forçar a descoberta.
 */
@Singleton
public class HocusPocus extends ThingsService{}
