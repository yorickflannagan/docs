#include "jmqc.h"
#include "jni_facilities.h"
#include "mqcx.h"
#include <string.h>

static inline jfieldID _JNI_GET_FIELD
(
	JNIEnv *env,
	jobject instance,
	const char *field,
	const char *sig
)
{
	jclass classz;
	classz = (*env)->GetObjectClass(env, instance);
	return (*env)->GetFieldID(env, classz, field, sig);
}

static inline void _JNI_SET_BYTEARRAY_FIELD
(
	JNIEnv *env,
	jobject instance,
	const char *name,
	PMQBYTE field,
	MQLONG size
)
{
	jfieldID id;
	jbyteArray value;
	jclass e;

	if (!(id = _JNI_GET_FIELD(env, instance, name, "[B"))) return;
	JNI_ASSERT
	(
		env,
		value = (*env)->NewByteArray(env, size),
		e,
		OUT_OF_MEMORY_ERROR,
		"Could not create jbyteArray instance"
	);
	(*env)->SetByteArrayRegion(env, value, 0, size, (jbyte *) field);
	(*env)->SetObjectField(env, instance, id, value);
}

#define _JNI_CHECK_REASON(_env, _e, _reason)							\
{														\
	switch (_reason)											\
	{													\
	case MQRC_NONE:											\
		break;											\
	case MQX_ARGUMENT_ERROR:									\
		JNI_THROW_EXCEPTION(_env, _e, ILLEGAL_ARG_EX, "Invalid argument");	\
		return _reason;										\
	case MQX_MEMORY_ERROR:										\
		JNI_THROW_EXCEPTION(_env, _e, OUT_OF_MEMORY_ERROR, "Out of memory");	\
		return _reason;										\
	default: return _reason;									\
	}													\
}

static inline MQLONG _JNI_GET_IDARG(JNIEnv *env, jbyteArray field, MQLONG size, jbyte **jout, PMQBYTE *pOut)
{
	jsize len;
      jclass e;
      jbyte *id;
      PMQBYTE pId;

	if ((len = (*env)->GetArrayLength(env, field)) != size)
	{
		JNI_THROW_EXCEPTION(env, e, ILLEGAL_ARG_EX, "Wrong size");
		return MQX_ARGUMENT_ERROR;
	}
	if (!(id = (*env)->GetByteArrayElements(env, field, JNI_NULL)))
	{
		JNI_THROW_EXCEPTION(env, e, RUNTIME_EX, "Array access error");
		return MQRC_UNEXPECTED_ERROR;
	}
	if (id[0]) pId = (PMQBYTE) id;
	else pId = NULL;
	*jout = id;
	*pOut = pId;
	return MQRC_NONE;
}

JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxNewConnection
(
	JNIEnv *env,
	jclass ignored,
	jstring address,
	jstring channel,
	jstring manager,
	jstring userID,
	jstring password,
	jobject ret
)
{
	jclass e;
	jsize size;
	char *utf, *user, *pwd;
	MQXNAME mqName;
	MQXCHANNEL mqChannel;
	MQXQMGR mqManager;
	PMQX_CONNECTION out;
	MQLONG reason;
	jfieldID field;

	JNI_ASSERT_ARGSR
	(
		env,
		(size = (*env)->GetStringUTFLength
		(
			env,
			address
		)) <= MQ_CONN_NAME_LENGTH,
		e,
		MQX_ARGUMENT_ERROR
	);
	JNI_GET_STRING_ARGR(env, address, utf, e, MQRC_UNEXPECTED_ERROR);
	memset(mqName, 0, MQ_CONN_NAME_LENGTH);
	memcpy(mqName, utf, size);
	(*env)->ReleaseStringUTFChars(env, address, utf);
	JNI_ASSERT_ARGSR
	(
		env,
		(size = (*env)->GetStringUTFLength
		(
			env,
			channel
		)) <= MQ_CHANNEL_NAME_LENGTH,
		e,
		MQX_ARGUMENT_ERROR
	);
	JNI_GET_STRING_ARGR(env, channel, utf, e, MQRC_UNEXPECTED_ERROR);
	memset(mqChannel, 0, MQ_CHANNEL_NAME_LENGTH);
	memcpy(mqChannel, utf, size);
	(*env)->ReleaseStringUTFChars(env, channel, utf);
	JNI_ASSERT_ARGSR
	(
		env,
		(size = (*env)->GetStringUTFLength
		(
			env,
			manager
		)) <= MQ_Q_MGR_NAME_LENGTH,
		e,
		MQX_ARGUMENT_ERROR
	);
	JNI_GET_STRING_ARGR(env, manager, utf, e, MQRC_UNEXPECTED_ERROR);
	memset(mqManager, 0, MQ_Q_MGR_NAME_LENGTH);
	memcpy(mqManager, utf, size);
	(*env)->ReleaseStringUTFChars(env, manager, utf);

	JNI_GET_STRING_ARGR(env, userID, user, e, MQRC_UNEXPECTED_ERROR);
	JNI_GET_STRING_ARGR(env, password, pwd, e, MQRC_UNEXPECTED_ERROR);
	reason = MQX_new_connection(mqName, mqChannel, mqManager, user, pwd, &out);
	(*env)->ReleaseStringUTFChars(env, userID, user);
	(*env)->ReleaseStringUTFChars(env, password, pwd);

	_JNI_CHECK_REASON(env, e, reason);

	if (!(field = _JNI_GET_FIELD(env, ret, "hConn", "J")))
	{
		MQX_release(out);
		return MQRC_UNEXPECTED_ERROR;
	}
	(*env)->SetLongField(env, ret, field, (jlong) out);
	return reason;
}

JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxReleaseConnection
(
	JNIEnv *env,
	jclass ignored,
	jlong handle
)
{
	return MQX_release((PMQX_CONNECTION) handle);
}

JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxQueueDepth
(
	JNIEnv *env,
	jclass ignored,
	jlong hConn,
	jstring queue,
	jintArray ret
)
{
	jclass e;
	jsize size;
	char *utf;
	MQXQUEUE mqQueue;
	MQLONG out;
	MQLONG reason;
	jint val;

	JNI_ASSERT_ARGSR
	(
		env,
		(size = (*env)->GetStringUTFLength
		(
			env,
			queue
		)) <= MQ_Q_NAME_LENGTH,
		e,
		MQX_ARGUMENT_ERROR
	);
	JNI_GET_STRING_ARGR(env, queue, utf, e, MQRC_UNEXPECTED_ERROR);
	memset(mqQueue, 0, MQ_Q_NAME_LENGTH);
	memcpy(mqQueue, utf, size);
	(*env)->ReleaseStringUTFChars(env, queue, utf);
	reason = MQX_depth((PMQX_CONNECTION) hConn, mqQueue, &out);
	_JNI_CHECK_REASON(env, e, reason);
	val = out;
	(*env)->SetIntArrayRegion(env, ret, 0, 1, &val);
	return reason;
}

JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxOpenQueue
(
	JNIEnv *env,
	jclass ignored,
	jlong hConn,
	jstring queue,
	jboolean input,
	jboolean convert,
	jboolean convertMsgId,
	jboolean convertCorrelId,
	jint maxMsgLen,
	jobject ret
)
{
	jclass e;
	jsize size;
	char *utf;
	MQXQUEUE mqQueue;
	PMQX_QUEUE out;
	MQLONG reason;
	jfieldID field;

	JNI_ASSERT_ARGSR
	(
		env,
		(size = (*env)->GetStringUTFLength
		(
			env,
			queue
		)) <= MQ_Q_NAME_LENGTH,
		e,
		MQX_ARGUMENT_ERROR
	);
	JNI_GET_STRING_ARGR(env, queue, utf, e, MQRC_UNEXPECTED_ERROR);
	memset(mqQueue, 0, MQ_Q_NAME_LENGTH);
	memcpy(mqQueue, utf, size);
	(*env)->ReleaseStringUTFChars(env, queue, utf);

	reason = MQX_open
	(
		(PMQX_CONNECTION) hConn,
		mqQueue,
		input,
		convert,
		convertMsgId,
		convertCorrelId,
		maxMsgLen,
		&out
	);
	_JNI_CHECK_REASON(env, e, reason);

	if (!(field = _JNI_GET_FIELD(env, ret, "hObj", "J")))
	{
		MQX_close((PMQX_CONNECTION) hConn, out);
		return MQRC_UNEXPECTED_ERROR;
	}
	(*env)->SetLongField(env, ret, field, (jlong) out);
	return reason;
}

JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxCloseQueue
(
	JNIEnv *env,
	jclass ignored,
	jlong hConn,
	jlong hObj
)
{
	return MQX_close((PMQX_CONNECTION) hConn, (PMQX_QUEUE) hObj);
}

JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxSendExpire
(
	JNIEnv *env,
	jclass ignored,
	jlong hConn,
	jlong hObj,
	jint expire,
	jbyteArray msgId,
	jbyteArray correlId,
	jbyteArray msg,
	jobject ret
)
{
	jsize len;
      jclass e;
      jbyte *_msgId, *_correlId, *_msg;
      PMQBYTE pMsgId, pCorrelId;
      MQX_MESSAGE resp;
      MQLONG reason;

	if
	(
		MQX_HAS_FAILED
		(
			(
				reason = _JNI_GET_IDARG
				(
					env,
					msgId,
					MQ_MSG_ID_LENGTH,
					&_msgId,
					&pMsgId
				)
			)
		)
	)	return reason;
	if
	(
		MQX_HAS_FAILED
		(
			(
				reason = _JNI_GET_IDARG
				(
					env,
					correlId,
					MQ_CORREL_ID_LENGTH,
					&_correlId,
					&pCorrelId
				)
			)
		)
	)
	{
		(*env)->ReleaseByteArrayElements(env, msgId, _msgId, JNI_ABORT);
		return reason;
	}

	JNI_GET_BYTE_ARRAY_OR_DIER
	(
		env, msg, _msg, len, e,
		{
			(*env)->ReleaseByteArrayElements
			(
				env,
				msgId,
				_msgId,
				JNI_ABORT
			);
			(*env)->ReleaseByteArrayElements
			(
				env,
				correlId,
				_correlId,
				JNI_ABORT
			);
		},
		MQRC_UNEXPECTED_ERROR
	);

	memset(&resp, 0, sizeof(MQX_MESSAGE));
	reason = MQX_send
	(
		(PMQX_CONNECTION) hConn,
		(PMQX_QUEUE) hObj,
		pMsgId,
		pCorrelId,
		(PMQBYTE) _msg,
		len,
		expire,
		&resp
	);
	(*env)->ReleaseByteArrayElements(env, msgId, _msgId, JNI_ABORT);
	(*env)->ReleaseByteArrayElements(env, correlId, _correlId, JNI_ABORT);
	(*env)->ReleaseByteArrayElements(env, msg, _msg, JNI_ABORT);
	_JNI_CHECK_REASON(env, e, reason);

	if (!pMsgId)
		_JNI_SET_BYTEARRAY_FIELD
		(
			env,
			ret,
			"msgId",
			resp.msgId,
			MQ_MSG_ID_LENGTH
		);
	if (!pCorrelId)
		_JNI_SET_BYTEARRAY_FIELD
		(
			env,
			ret,
			"correlId",
			resp.correlId,
			MQ_CORREL_ID_LENGTH
		);
	return reason;
}

JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxSend
(
	JNIEnv *env,
	jclass ignored,
	jlong hConn,
	jlong hObj,
	jbyteArray msgId,
	jbyteArray correlId,
	jbyteArray msg,
	jobject ret
)
{
	return Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxSendExpire
		(
			env,
			ignored,
			hConn,
			hObj,
			0,
			msgId,
			correlId,
			msg,
			ret
		);
}

JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxReceive
(
	JNIEnv *env,
	jclass ignored,
	jlong hConn,
	jlong hObj,
	jbyteArray msgId,
	jbyteArray correlId,
	jint timeout,
	jobject ret
)
{
      jbyte *_msgId, *_correlId;
      PMQBYTE pMsgId, pCorrelId;
      MQLONG reason;
      MQX_MESSAGE resp;

	if
	(
		MQX_HAS_FAILED
		(
			(
				reason = _JNI_GET_IDARG
				(
					env,
					msgId,
					MQ_MSG_ID_LENGTH,
					&_msgId,
					&pMsgId
				)
			)
		)
	)	return reason;
	if
	(
		MQX_HAS_FAILED
		(
			(
				reason = _JNI_GET_IDARG
				(
					env,
					correlId,
					MQ_CORREL_ID_LENGTH,
					&_correlId,
					&pCorrelId
				)
			)
		)
	)
	{
		(*env)->ReleaseByteArrayElements(env, msgId, _msgId, JNI_ABORT);
		return reason;
	}

	memset(&resp, 0, sizeof(MQX_MESSAGE));
	if
	(
		(
			reason = MQX_receive
			(
				(PMQX_CONNECTION) hConn,
				(PMQX_QUEUE) hObj,
				pMsgId,
				pCorrelId,
				timeout,
				&resp
			)
		) 	== MQRC_NO_MSG_AVAILABLE
	)	return reason;
	if (!MQX_HAS_FAILED(reason))
	{
		_JNI_SET_BYTEARRAY_FIELD(
			env,
			ret,
			"msgId",
			resp.msgId,
			MQ_MSG_ID_LENGTH
		);
		_JNI_SET_BYTEARRAY_FIELD
		(
			env,
			ret,
			"correlId",
			resp.correlId,
			MQ_CORREL_ID_LENGTH
		);
		_JNI_SET_BYTEARRAY_FIELD
		(
			env,
			ret,
			"message",
			resp.buffer,
			resp.buflen
		);
	}
	return reason;
}

JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxBegin
(
	JNIEnv *env,
	jclass ignored,
	jlong hConn
)
{
	PMQX_CONNECTION hHandle;
	jclass e;

	hHandle = (PMQX_CONNECTION) hConn;
	JNI_ASSERTR
	(
		env,
		!hHandle->trans,
		e,
		ILLEGAL_STATE_EXCEPTION,
		"Transaction already in progress",
		MQRC_UOW_IN_PROGRESS
	);
	return MQX_begin(hHandle);
}

JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxCommit
(
	JNIEnv *env,
	jclass ignored,
	jlong hConn
)
{
	PMQX_CONNECTION hHandle;
	jclass e;

	hHandle = (PMQX_CONNECTION) hConn;
	JNI_ASSERTR
	(
		env,
		hHandle->trans,
		e,
		ILLEGAL_STATE_EXCEPTION,
		"Transaction not in progress",
		MQRC_CALL_IN_PROGRESS
	);
	return MQX_commit(hHandle);
}

JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxBack
(
	JNIEnv *env,
	jclass ignored,
	jlong hConn
)
{
	PMQX_CONNECTION hHandle;
	jclass e;

	hHandle = (PMQX_CONNECTION) hConn;
	JNI_ASSERTR
	(
		env,
		hHandle->trans,
		e,
		ILLEGAL_STATE_EXCEPTION,
		"Transaction not in progress",
		MQRC_CALL_IN_PROGRESS
	);
	return MQX_back(hHandle);
}

JNIEXPORT jboolean JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxIsTransaction
(
	JNIEnv *env,
	jclass ignored,
	jlong hConn
)
{
	return ((PMQX_CONNECTION) hConn)->trans;
}
