#ifndef __JMQC_H__
#define __JMQC_H__

#if defined(__GNUC__)	/* To pass pointers to and from Java we must do some questionable things... */
#	pragma GCC diagnostic ignored "-Wint-to-pointer-cast"
#	pragma GCC diagnostic ignored "-Wpointer-to-int-cast"
#	pragma GCC diagnostic ignored "-Wlong-long"
#endif

#include <jni.h>

#ifdef __cplusplus
extern "C"
{
#endif

JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxNewConnection
(
	JNIEnv*,
	jclass,
	jstring,
	jstring,
	jstring,
	jstring,
	jstring,
	jobject
);
JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxReleaseConnection
(
	JNIEnv*,
	jclass,
	jlong
);
JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxOpenQueue
(
	JNIEnv*,
	jclass,
	jlong,
	jstring,
	jboolean,
	jboolean,
	jboolean,
	jboolean,
	jint,
	jobject
);
JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxCloseQueue
(
	JNIEnv*,
	jclass,
	jlong,
	jlong
);
JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxSend
(
	JNIEnv*,
	jclass,
	jlong,
	jlong,
	jbyteArray,
	jbyteArray,
	jbyteArray,
	jobject
);
JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxSendExpire
(
	JNIEnv *,
	jclass,
	jlong,
	jlong,
	jint,
	jbyteArray,
	jbyteArray,
	jbyteArray,
	jobject
);

JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxReceive
(
	JNIEnv*,
	jclass,
	jlong,
	jlong,
	jbyteArray,
	jbyteArray,
	jint,
	jobject
);
JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxBegin
(
	JNIEnv*,
	jclass,
	jlong
);
JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxCommit
(
	JNIEnv*,
	jclass,
	jlong
);
JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxBack
(
	JNIEnv*,
	jclass,
	jlong
);
JNIEXPORT jint JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxQueueDepth
(
	JNIEnv*,
	jclass,
	jlong,
	jstring,
	jlongArray
);
/*
 * Class:     br_gov_caixa_mqx_MQXConnectionImpl
 * Method:    mqxIsTransaction
 * Signature: (J)Z
 */
JNIEXPORT jboolean JNICALL
Java_br_gov_caixa_mqx_MQXConnectionImpl_mqxIsTransaction
(
	JNIEnv*,
	jclass,
	jlong
);


#ifdef __cplusplus
}
#endif

#define ILLEGAL_STATE_EXCEPTION	"org/crypthing/things/messaging/MQXIllegalStateException"

#endif
