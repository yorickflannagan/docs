#include "mqcx.h"
#include <stdlib.h>
#include <string.h>

MQCNO connOptsDefault = { MQX_MQCNO_DEFAULT };
MQCNO connOptsShared = { MQX_MQCNO_SHARED_NO_BL };
MQCNO connOptsSharedBlocking = { MQX_MQCNO_SHARED_BL };
#define MQX_NO_AUTH	"_*_*_*_*_*"

LIBEXPORT MQLONG LIBCALL MQX_new_connection
(
	_IN_ MQXNAME address,
	_IN_ MQXCHANNEL channel,
	_IN_ MQXQMGR manager,
	_IN_ char *userid,
	_IN_ char *pwd,
	_OUT_ PMQX_CONNECTION *hHandle
)
{
	return MQX_new_connection_ex(address, channel, manager, 0 , 0, userid, pwd, hHandle);
}
LIBEXPORT MQLONG LIBCALL MQX_new_connection_ex
(
	_IN_ MQXNAME address,
	_IN_ MQXCHANNEL channel,
	_IN_ MQXQMGR manager,
	_IN_ MQBOOL shared,
	_IN_ MQBOOL block,
	_IN_ char *userid,
	_IN_ char *pwd,
	_OUT_ PMQX_CONNECTION *hHandle
)
{
	MQCD connection = { MQX_MQCD_DEFAULT };
	MQCNO connOpts;
	MQHCONN hConn;
	MQLONG compCode, reason;
	PMQX_CONNECTION out;
	MQCSP csp = { MQCSP_DEFAULT };

	if(!shared){ connOpts = connOptsDefault; }
	else { if(block) { connOpts = connOptsShared; } else { connOpts = connOptsSharedBlocking; } }

	memcpy(connection.ConnectionName, address, MQ_CONN_NAME_LENGTH);
	memcpy(connection.ChannelName, channel, MQ_CHANNEL_NAME_LENGTH);
	connOpts.ClientConnPtr = &connection;

	if (strcmp(userid, MQX_NO_AUTH) != 0)
	{
		connOpts.SecurityParmsPtr = &csp;
		connOpts.Version = MQCNO_VERSION_5;
		csp.AuthenticationType = MQCSP_AUTH_USER_ID_AND_PWD;
		csp.CSPUserIdPtr = (char*) userid;
		csp.CSPUserIdLength = strlen(userid);
		csp.CSPPasswordPtr = (char*) pwd;
		csp.CSPPasswordLength = strlen(pwd);
	}

	MQCONNX((PMQCHAR) manager, &connOpts, &hConn, &compCode, &reason);
	if (!MQX_HAS_FAILED(reason))
	{
		MQX_ASSERT_MEM_OR_DIE
		(
			out = (PMQX_CONNECTION) malloc(sizeof(MQX_CONNECTION)),
			MQDISC(&hConn, &compCode, &reason);
		);
		memcpy(out->manager, manager, MQ_Q_MGR_NAME_LENGTH);
		out->hConn = hConn;
		out->trans = MQX_FALSE;
		out->dirty = MQX_FALSE;
		*hHandle = out;
	}
	return reason;
}

LIBEXPORT MQLONG LIBCALL MQX_release(_IN_ PMQX_CONNECTION hHandle)
{
	MQLONG compCode, reason;

	MQX_ASSERT_ARG(hHandle);
	MQDISC(&hHandle->hConn, &compCode, &reason);
	free(hHandle);
	return reason;
}

LIBEXPORT MQLONG LIBCALL MQX_depth(_IN_ PMQX_CONNECTION hCHandle, _IN_ MQXQUEUE queue, _OUT_ MQLONG *depth)
{
	MQLONG opt = MQOO_INQUIRE | MQOO_FAIL_IF_QUIESCING;
	MQLONG compCode, reason;
	MQHOBJ hQueue;
	MQOD object = { MQOD_DEFAULT };
	MQLONG query[] = { MQIA_CURRENT_Q_DEPTH }, ret[1];

	memcpy(object.ObjectName, queue, MQ_Q_NAME_LENGTH);
	MQOPEN(hCHandle->hConn, &object, opt, &hQueue, &compCode, &reason);
	if (!MQX_HAS_FAILED(reason))
	{
		MQINQ(hCHandle->hConn, hQueue, 1, query, 1, ret, 0, NULL, &compCode, &reason);
		if (!MQX_HAS_FAILED(reason)) *depth = ret[0];
		MQCLOSE(hCHandle->hConn, &hQueue, 0, &compCode, &reason);
	}
	return reason;
}

LIBEXPORT MQLONG LIBCALL MQX_open
(
	_IN_ PMQX_CONNECTION hCHandle,
	_IN_ MQXQUEUE queue,
	_IN_ MQBOOL input,
	_IN_ MQBOOL convert,
	_IN_ MQBOOL convertMsgId,
	_IN_ MQBOOL convertCorrelId,
	_IN_ MQLONG maxMsgLen,
	_OUT_ PMQX_QUEUE *hHandle
)
{
	MQLONG compCode, reason, opt;
	MQOD object = { MQOD_DEFAULT };
	MQHOBJ hObj;
	PMQX_QUEUE out;

	MQX_ASSERT_ARG
	(
		hCHandle &&
		(
			(input && maxMsgLen) ||
			(!input && !maxMsgLen)
		)
	);
	memcpy(object.ObjectName, queue, MQ_Q_NAME_LENGTH);
	memcpy(object.ObjectQMgrName, hCHandle->manager, MQ_Q_MGR_NAME_LENGTH);
	opt = input ? MQX_GET_OPTIONS : MQX_PUT_OPTIONS;
	MQOPEN(hCHandle->hConn, &object, opt, &hObj, &compCode, &reason);
	if (!MQX_HAS_FAILED(reason))
	{
		MQX_ASSERT_MEM_OR_DIE
		(
			out = (PMQX_QUEUE) malloc(sizeof(MQX_QUEUE)),
			MQCLOSE(hCHandle->hConn, &hObj, MQCO_NONE, &compCode, &reason)
		);
		memset(out, 0, sizeof(MQX_QUEUE));
		if (input)
		{
			MQX_ASSERT_MEM_OR_DIE
			(
				out->buffer = (PMQBYTE) malloc(maxMsgLen),
				{
					free(out);
					MQCLOSE
					(
						hCHandle->hConn,
						&hObj,
						MQCO_NONE,
						&compCode,
						&reason
					);
				}
			);
			out->bufflen = maxMsgLen;
		}
		out->hObj = hObj;
		out->convert = convert;
		out->convertMsgId = convertMsgId;
		out->convertCorrelId = convertCorrelId;
		*hHandle = out;
	}
	return reason;
}

LIBEXPORT MQLONG LIBCALL MQX_close(_IN_ PMQX_CONNECTION hCHandle, _IN_ PMQX_QUEUE hHandle)
{
	MQLONG compCode, reason;

	MQX_ASSERT_ARG(hCHandle && hHandle);
	MQX_back(hCHandle);
	MQCLOSE(hCHandle->hConn, &hHandle->hObj, MQCO_NONE, &compCode, &reason);
	if (hHandle->buffer) free(hHandle->buffer);
	free(hHandle);
	return reason;
}

LIBEXPORT MQLONG LIBCALL MQX_send
(
	_IN_ PMQX_CONNECTION hcHandle,
	_IN_ PMQX_QUEUE hqHandle,
	_IN_ PMQBYTE msgId,
	_IN_ PMQBYTE correlId,
	_IN_ PMQBYTE buffer,
	_IN_ MQLONG buflen,
	_IN_ MQLONG expire,
	_OUT_ PMQX_MESSAGE hMsg
)
{
	/* TODO: Colocar parâmetro de persistir ou não a mensagem
	 */
	MQMD md = { MQMD_DEFAULT };
	MQPMO pmo = { MQPMO_DEFAULT };
	MQLONG compCode, reason;

	if (hcHandle->trans) pmo.Options |= MQPMO_SYNCPOINT;
	else pmo.Options |= MQPMO_NO_SYNCPOINT;
	if (!msgId) pmo.Options |= MQPMO_NEW_MSG_ID;
	else
	{
		if
		(
			hqHandle->convertMsgId
		)	MQX_utf8_to_ebcdic(md.MsgId, msgId, MQ_MSG_ID_LENGTH);
		else	memcpy(md.MsgId, msgId, MQ_MSG_ID_LENGTH);
	}
	if (!correlId) pmo.Options |= MQPMO_NEW_CORREL_ID;
	else
	{
		if
		(
			hqHandle->convertCorrelId
		)	MQX_utf8_to_ebcdic
			(
				md.CorrelId,
				correlId,
				MQ_CORREL_ID_LENGTH
			);
		else	memcpy(md.CorrelId, correlId, MQ_CORREL_ID_LENGTH);
	}
	if (hqHandle->convert) memcpy(md.Format, MQFMT_STRING, MQ_FORMAT_LENGTH);
	if (expire > 0) md.Expiry = expire;
	MQPUT
	(
		hcHandle->hConn,
		hqHandle->hObj,
		&md,
		&pmo,
		buflen,
		buffer,
		&compCode,
		&reason
	);
	if (compCode == MQCC_OK)
	{
		/*
		 * Nós devolvemos md.MsgId e/ou md.CorrelId somente se produzidas pelo MQSeries,
		 * i.e., se os flags MQPMO_NEW_MSG_ID e/ou MQPMO_NEW_CORREL_ID tiverem sido ligados
		 */
		if (hcHandle->trans) hcHandle->dirty = MQX_TRUE;
		if (!msgId) memcpy(hMsg->msgId, md.MsgId, MQ_MSG_ID_LENGTH);
		if (!correlId)
			memcpy(hMsg->correlId, md.CorrelId, MQ_CORREL_ID_LENGTH);
	}
	return reason;
}

LIBEXPORT MQLONG LIBCALL MQX_receive
(
	_IN_ PMQX_CONNECTION hcHandle,
	_IN_ PMQX_QUEUE hqHandle,
	_IN_ PMQBYTE msgId,
	_IN_ PMQBYTE correlId,
	_IN_ MQLONG timeout,
	_OUT_ PMQX_MESSAGE hMsg
)
{
	MQMD md = { MQMD_DEFAULT };
	MQGMO gmo = { MQX_MQGMO_DEFAULT };
	MQLONG compCode, reason, datalen;

	if (hqHandle->convert)
	{
		gmo.Options |= MQGMO_CONVERT;
		memcpy(md.Format, MQFMT_STRING, MQ_FORMAT_LENGTH);
	}
	if (hcHandle->trans) gmo.Options |= MQGMO_SYNCPOINT;
	else gmo.Options |= MQGMO_NO_SYNCPOINT;
	if (timeout > 0)
	{
		gmo.WaitInterval = timeout;
		gmo.Options |= MQGMO_WAIT;
	}
	else gmo.Options |= MQGMO_NO_WAIT;
	if (msgId)
	{
		gmo.MatchOptions |= MQMO_MATCH_MSG_ID;
		memcpy(md.MsgId, msgId, MQ_MSG_ID_LENGTH);
	}
	if (correlId)
	{
		gmo.MatchOptions |= MQMO_MATCH_CORREL_ID;
		memcpy(md.CorrelId, correlId, MQ_CORREL_ID_LENGTH);
	}
	MQGET
	(
		hcHandle->hConn,
		hqHandle->hObj,
		&md,
		&gmo,
		hqHandle->bufflen,
		hqHandle->buffer,
		&datalen,
		&compCode,
		&reason
	);
	if (reason == MQRC_TRUNCATED_MSG_FAILED)
	{
		free(hqHandle->buffer);
		hqHandle->buffer = (PMQBYTE) malloc(datalen);
		hqHandle->bufflen = datalen;
		return MQX_receive
			(
				hcHandle,
				hqHandle,
				msgId,
				correlId,
				timeout,
				hMsg
			);
	}
	if (compCode == MQCC_OK)
	{
		if (hcHandle->trans) hcHandle->dirty = MQX_TRUE;
		hMsg->buffer = hqHandle->buffer;
		hMsg->buflen = datalen;
		if
		(
			hqHandle->convertMsgId
		)	MQX_ebcdic_to_utf8(hMsg->msgId, md.MsgId, MQ_MSG_ID_LENGTH);
		else	memcpy(hMsg->msgId, md.MsgId,MQ_MSG_ID_LENGTH);
		if
		(
			hqHandle->convertCorrelId
		)	MQX_ebcdic_to_utf8
			(
				hMsg->correlId,
				md.CorrelId,
				MQ_CORREL_ID_LENGTH
			);
		else	memcpy(hMsg->correlId, md.CorrelId, MQ_CORREL_ID_LENGTH);
	}
	return reason;
}

LIBEXPORT MQLONG LIBCALL MQX_commit(_IN_ PMQX_CONNECTION hHandle)
{
	MQLONG compCode, reason;

	if (hHandle->trans && hHandle->dirty) MQCMIT(hHandle->hConn, &compCode, &reason);
	else reason = MQCC_OK;
	hHandle->dirty = MQX_FALSE;
	hHandle->trans = MQX_FALSE;
	return reason;
}

LIBEXPORT MQLONG LIBCALL MQX_back(_IN_ PMQX_CONNECTION hHandle)
{
	MQLONG compCode, reason;

	if (hHandle->trans && hHandle->dirty) MQBACK(hHandle->hConn, &compCode, &reason);
	else reason = MQCC_OK;
	hHandle->dirty = MQX_FALSE;
	hHandle->trans = MQX_FALSE;
	return reason;
}


int utf8_ebcdic_table[256] =
{
	0x00, 0x01, 0x02, 0x03, 0x37, 0x2d, 0x2e, 0x2f,
	0x16, 0x05, 0x25, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
	0x10, 0x11, 0x12, 0x13, 0x3c, 0x3d, 0x32, 0x26,
	0x18, 0x19, 0x3f, 0x27, 0x1c, 0x1d, 0x1e, 0x1f,
	0x40, 0x5a, 0x7f, 0x7b, 0x5b, 0x6c, 0x50, 0x7d,
	0x4d, 0x5d, 0x5c, 0x4e, 0x6b, 0x60, 0x4b, 0x61,
	0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7,
	0xf8, 0xf9, 0x7a, 0x5e, 0x4c, 0x7e, 0x6e, 0x6f,
	0x7c, 0xc1, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7,
	0xc8, 0xc9, 0xd1, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6,
	0xd7, 0xd8, 0xd9, 0xe2, 0xe3, 0xe4, 0xe5, 0xe6,
	0xe7, 0xe8, 0xe9, 0xba, 0xe0, 0xbb, 0xb0, 0x6d,
	0x79, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
	0x88, 0x89, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96,
	0x97, 0x98, 0x99, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6,
	0xa7, 0xa8, 0xa9, 0xc0, 0x4f, 0xd0, 0xa1, 0x07,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f,
	0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f
};
int ebcdic_utf8_table[256] =
{
	0x00, 0x01, 0x02, 0x03, 0x1a, 0x09, 0x1a, 0x7f,
	0x1a, 0x1a, 0x1a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
	0x10, 0x11, 0x12, 0x13, 0x1a, 0x0a, 0x08, 0x1a,
	0x18, 0x19, 0x1a, 0x1a, 0x1c, 0x1d, 0x1e, 0x1f,
	0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x0a, 0x17, 0x1b,
	0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x05, 0x06, 0x07,
	0x1a, 0x1a, 0x16, 0x1a, 0x1a, 0x1a, 0x1a, 0x04,
	0x1a, 0x1a, 0x1a, 0x1a, 0x14, 0x15, 0x1a, 0x1a,
	0x20, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a,
	0x1a, 0x1a, 0x1a, 0x2e, 0x3c, 0x28, 0x2b, 0x7c,
	0x26, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a,
	0x1a, 0x1a, 0x21, 0x24, 0x2a, 0x29, 0x3b, 0x1a,
	0x2d, 0x2f, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a,
	0x1a, 0x1a, 0x1a, 0x2c, 0x25, 0x5f, 0x3e, 0x3f,
	0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a,
	0x1a, 0x60, 0x3a, 0x23, 0x40, 0x27, 0x3d, 0x22,
	0x1a, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
	0x68, 0x69, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a,
	0x1a, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f, 0x70,
	0x71, 0x72, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a,
	0x1a, 0x7e, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78,
	0x79, 0x7a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a,
	0x5e, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a,
	0x1a, 0x1a, 0x5b, 0x5d, 0x1a, 0x1a, 0x1a, 0x1a,
	0x7b, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
	0x48, 0x49, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a,
	0x7d, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f, 0x50,
	0x51, 0x52, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a,
	0x5c, 0x1a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58,
	0x59, 0x5a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a,
	0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
	0x38, 0x39, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a, 0x1a
};

void MQX_utf8_to_ebcdic
(
	PMQBYTE dest,
	PMQBYTE src,
	MQLONG size
)
{
	MQLONG i;
	for (i = 0; i < size; i++) dest[i] = utf8_ebcdic_table[src[i]];
}
void MQX_ebcdic_to_utf8
(
	PMQBYTE dest,
	PMQBYTE src,
	MQLONG size
)
{
	MQLONG i;
	for (i = 0; i < size; i++) dest[i] = ebcdic_utf8_table[src[i]];
}

LIBEXPORT MQLONG LIBCALL MQX_begin_ex(_IN_ PMQX_CONNECTION hHandle)
{
	hHandle->trans = MQX_TRUE;
	return MQRC_NONE;
}

