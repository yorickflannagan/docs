#ifndef __JNI_FACILITIES_H__
#define __JNI_FACILITIES_H__

#ifndef JNI_NULL
#define JNI_NULL				NULL
#endif
#ifndef JNI_NULL_HANDLE
#define JNI_NULL_HANDLE			0L
#endif


#define NULL_POINTER_EX				"java/lang/NullPointerException"
#define ILLEGAL_ARG_EX				"java/lang/IllegalArgumentException"
#define RUNTIME_EX				"java/lang/RuntimeException"
#define OUT_OF_MEMORY_ERROR			"java/lang/OutOfMemoryError"
#define INDEX_OUT_OF_BOUNDS_EX		"java/lang/IndexOutOfBoundsException"


/*
 ****if* Nharu/JNI_Facilities
 *
 * NAME
 *	JNI_THROW_EXCEPTION
 *
 * PURPOSE
 *	Throws a Java exception of any type.
 *
 * SYNOPSIS
 */
#define JNI_THROW_EXCEPTION(jenv, exvar, class, msg)	\
{									\
	(*jenv)->ExceptionClear(jenv);			\
	if ((exvar = (*jenv)->FindClass(jenv, class)))	\
	{								\
		(*jenv)->ThrowNew(jenv, exvar, msg);	\
	}								\
}
/*
 * INPUTS
 *	jenv	- Java environment.
 *	exvar	- jclass exception object.
 *	class	- path to Java exception type.
 *	msg	- message binded to exception.
 *
 ******/


#define JNI_THROW(jenv, exp, exvar, class, msg)		\
{									\
	if (!(exp))							\
	{								\
		JNI_THROW_EXCEPTION				\
		(							\
			jenv,						\
			exvar,					\
			class,					\
			msg						\
		);							\
		return;						\
	}								\
}

#define JNI_THROWR(jenv, exp, exvar, class, msg, rv)	\
{									\
	if (!(exp))							\
	{								\
		JNI_THROW_EXCEPTION				\
		(							\
			jenv,						\
			exvar,					\
			class,					\
			msg						\
		);							\
		return rv;						\
	}								\
}

#define JNI_ASSERT(jenv, exp, exvar, class, msg)	JNI_THROW(jenv, exp, exvar, class, msg)

/*
 ****if* Nharu/JNI_Facilities
 *
 * NAME
 *	JNI_ASSERTR
 *
 * PURPOSE
 *	Ensures that an expression is true; if it is not,
 *	throws a Java exception and return.
 *
 * SYNOPSIS
 */
#define JNI_ASSERTR(jenv, exp, exvar, class, msg, rv)	JNI_THROWR(jenv, exp, exvar, class, msg, rv)
/*
 * INPUTS
 *	jenv	- Java environment.
 *	exp	- expression to evaluate.
 *	exvar	- jclass exception object.
 *	class	- path to Java exception type.
 *	msg	- message binded to exception.
 *	rv	- value to return if expression is false.
 *
 ******/


#define JNI_ASSERT_ARGS(jenv, exp, exvar)			\
	JNI_ASSERT							\
	(								\
		jenv,							\
		exp,							\
		exvar,						\
		ILLEGAL_ARG_EX,					\
		"Invalid argument"				\
	)


#define JNI_ASSERT_ARGSR(jenv, exp, exvar, rv)		\
	JNI_ASSERTR							\
	(								\
		jenv,							\
		exp,							\
		exvar,						\
		ILLEGAL_ARG_EX,					\
		"Invalid argument",				\
		rv							\
	)


#define JNI_ASSERT_OR_DIE(jenv, exp, exvar, class, msg, dieblock)	\
{											\
	if (!(exp))									\
	{										\
		JNI_THROW_EXCEPTION						\
		(									\
			jenv,								\
			exvar,							\
			class,							\
			msg								\
		);									\
		dieblock;								\
		return;								\
	}										\
}

/*
 ****if* Nharu/JNI_Facilities
 *
 * NAME
 *	JNI_ASSERT_OR_DIER
 *
 * PURPOSE
 *	Ensures that an expression is true; if it is not,
 *	throws a Java exception, execute a code block and return.
 *
 * SYNOPSIS
 */
#define JNI_ASSERT_OR_DIER(jenv, exp, exvar, class, msg, dieblock, rv)	\
{												\
	if (!(exp))										\
	{											\
		JNI_THROW_EXCEPTION							\
		(										\
			jenv,									\
			exvar,								\
			class,								\
			msg									\
		);										\
		dieblock;									\
		return rv;									\
	}											\
}

/*
 * INPUTS
 *	jenv		- Java environment.
 *	exp		- expression to evaluete.
 *	exvar		- jclass exception object.
 *	class		- path to Java exception type.
 *	msg		- message binded to exception.
 *	dieblock	- block to execut if expression is false.
 *	rv		- value to return if expression is false.
 *
 ******/


#define JNI_ASSERT_RTE(jenv, exp, exvar, msg)		\
	JNI_THROW							\
	(								\
		jenv,							\
		exp,							\
		exvar,						\
		RUNTIME_EX,						\
		msg							\
	)


#define JNI_ASSERT_RTER(jenv, exp, exvar, msg, rv)	\
	JNI_THROWR							\
	(								\
		jenv,							\
		exp,							\
		exvar,						\
		RUNTIME_EX,						\
		msg,							\
		rv							\
	)


#define JNI_ASSERT_MEM(jenv, exp, exvar)			\
	JNI_ASSERT							\
	(								\
		jenv,							\
		exp,							\
		exvar,						\
		OUT_OF_MEMORY_ERROR,				\
		"Out of memory"					\
	)


/*
 ****if* Nharu/JNI_Facilities
 *
 * NAME
 *	JNI_ASSERT_MEMR
 *
 * PURPOSE
 *	Ensures that a memory allocation expression is true; if it is not,
 *	throws a java/lang/OutOfMemoryError exception and return.
 *
 * SYNOPSIS
 */
#define JNI_ASSERT_MEMR(jenv, exp, exvar, rv)	\
	JNI_ASSERTR						\
	(							\
		jenv,						\
		exp,						\
		exvar,					\
		OUT_OF_MEMORY_ERROR,			\
		"Out of memory",				\
		rv						\
	)

/*
 * INPUTS
 *	jenv	- Java environment.
 *	exp	- expression to evaluete.
 *	exvar	- jclass exception object.
 *	rv	- value to return if expression is false.
 *
 ******/


#define JNI_ASSERT_MEM_OR_DIE(jenv, exp, exvar, dieblock)	\
	JNI_ASSERT_OR_DIE							\
	(									\
		jenv,								\
		exp,								\
		exvar,							\
		OUT_OF_MEMORY_ERROR,					\
		"Out of memory",						\
		dieblock							\
	)


/*
 ****if* Nharu/JNI_Facilities
 *
 * NAME
 *	JNI_ASSERT_MEM_OR_DIER
 *
 * PURPOSE
 *	Ensures that a memory allocation expression is true; if it is not,
 *	throws a java/lang/OutOfMemoryError exception, execute a code block and return.
 *
 * SYNOPSIS
 */
#define JNI_ASSERT_MEM_OR_DIER(jenv, exp, exvar, dieblock, rv)	\
	JNI_ASSERT_OR_DIER							\
	(										\
		jenv,									\
		exp,									\
		exvar,								\
		OUT_OF_MEMORY_ERROR,						\
		"Out of memory",							\
		dieblock,								\
		rv									\
	)

/*
 * INPUTS
 *	jenv		- Java environment.
 *	exp		- expression to evaluete.
 *	exvar		- jclass exception object.
 *	dieblock	- block to execut if expression is false.
 *	rv		- value to return if expression is false.
 *
 ******/



#define JNI_ASSERT_JARRAY(jenv, exp, exvar)		\
	JNI_ASSERT							\
	(								\
		jenv,							\
		exp,							\
		exvar,						\
		INDEX_OUT_OF_BOUNDS_EX,				\
		"Invalid array index"				\
	)


#define JNI_ASSERT_JARRAYR(jenv, exp, exvar, rv)	\
	JNI_ASSERTR							\
	(								\
		jenv,							\
		exp,							\
		exvar,						\
		INDEX_OUT_OF_BOUNDS_EX,				\
		"Invalid array index",				\
		rv							\
	)


#define JNI_GET_BYTE_ARRAY(jenv, from, to, tolen, e)	\
{									\
	tolen = (*jenv)->GetArrayLength(jenv, from);	\
	JNI_ASSERT							\
	(								\
		jenv,							\
		(to = (*jenv)->GetByteArrayElements		\
		(							\
			jenv,						\
			from,						\
			JNI_NULL					\
		)),							\
		e,							\
		RUNTIME_EX,						\
		"Array access error"				\
	);								\
}


/*
 ****if* Nharu/JNI_Facilities
 *
 * NAME
 *	JNI_GET_BYTE_ARRAYR
 *
 * PURPOSE
 *	Get a Java byte array from VM. If something goes wrong, throws
 *	a Java exception and return.
 *
 * SYNOPSIS
 */
#define JNI_GET_BYTE_ARRAYR(jenv, from, to, tolen, e, class, msg, rv)	\
{												\
	tolen = (*jenv)->GetArrayLength(jenv, from);				\
	JNI_ASSERTR										\
	(											\
		jenv,										\
		(to = (*jenv)->GetByteArrayElements					\
		(										\
			jenv,									\
			from,									\
			JNI_NULL								\
		)),										\
		e,										\
		class,									\
		msg,										\
		rv										\
	);											\
}
/*
 * INPUTS
 *	jenv	- Java environment.
 *	from	- jbyteArray object from where array will be extracted.
 *	to	- pointer to jbyte object where to put the array.
 *	tolen	- out: to buffer length.
 *	e	- jclass exception object.
 *	class	- path to Java exception type.
 *	msg	- message binded to exception.
 *	rv	- value to return if operation failes.
 *
 ******/


#define JNI_GET_BYTE_ARRAY_EX(jenv, from, to, tolen, e)	\
	JNI_GET_BYTE_ARRAY						\
	(									\
		jenv,								\
		from,								\
		to,								\
		tolen,							\
		e								\
	)


/*
 ****if* Nharu/JNI_Facilities
 *
 * NAME
 *	JNI_GET_BYTE_ARRAY_EXR
 *
 * PURPOSE
 *	Get a Java byte array from VM. If something goes wrong, throws
 *	a java/lang/RuntimeException and return.
 *
 * SYNOPSIS
 */
#define JNI_GET_BYTE_ARRAY_EXR(jenv, from, to, tolen, e, rv)	\
	JNI_GET_BYTE_ARRAYR							\
	(										\
		jenv,									\
		from,									\
		to,									\
		tolen,								\
		e,									\
		RUNTIME_EX,								\
		"Array access error",						\
		rv									\
	)

/*
 * INPUTS
 *	jenv	- Java environment.
 *	from	- jbyteArray object from where array will be extracted.
 *	to	- pointer to jbyte object where to put the array.
 *	tolen	- out: to buffer length.
 *	e	- jclass exception object.
 *	rv	- value to return if operation failes.
 *
 ******/

#define JNI_GET_BYTE_ARRAY_OR_DIE(jenv, from, to, tolen, e, dieblock)	\
{												\
	tolen = (*jenv)->GetArrayLength(jenv, from);				\
	JNI_ASSERT_OR_DIE									\
	(											\
		jenv,										\
		(to = (*jenv)->GetByteArrayElements					\
		(										\
			jenv,									\
			from,									\
			JNI_NULL								\
		)),										\
		e,										\
		RUNTIME_EX,									\
		"Array access error",							\
		dieblock									\
	);											\
}


#define JNI_GET_BYTE_ARRAY_OR_DIER(jenv, from, to, tolen, e, dieblock, rv)	\
{													\
	tolen = (*jenv)->GetArrayLength(jenv, from);					\
	JNI_ASSERT_OR_DIER									\
	(												\
		jenv,											\
		(to = (*jenv)->GetByteArrayElements						\
		(											\
			jenv,										\
			from,										\
			JNI_NULL									\
		)),											\
		e,											\
		RUNTIME_EX,										\
		"Array access error",								\
		dieblock,										\
		rv											\
	);												\
}


/*
 ****if* Nharu/JNI_Facilities
 *
 * NAME
 *	JNI_SET_BYTE_ARRAYR
 *
 * PURPOSE
 *	Set a Java byte array to VM. If something goes wrong, throws
 *	an exception and return.
 *
 * SYNOPSIS
 */
#define JNI_SET_BYTE_ARRAYR(jenv, len, e, class, msg, value, rv)	\
{											\
	JNI_ASSERTR									\
	(										\
		jenv,									\
		rv = (*jenv)->NewByteArray(jenv, len),			\
		e,									\
		class,								\
		msg,									\
		JNI_NULL								\
	);										\
	(*jenv)->SetByteArrayRegion						\
	(										\
		jenv,									\
		rv,									\
		0L,									\
		len,									\
		(jbyte *) value							\
	);										\
}
/*
 * INPUTS
 *	jenv	- Java environment.
 *	len	- length of array.
 *	e	- jclass exception object.
 *	class	- path to Java exception type.
 *	msg	- message binded to exception.
 *	value	- ponter to jbyte pointer with data.
 *	rv	- value to return.
 *
 ******/


/*
 ****if* Nharu/JNI_Facilities
 *
 * NAME
 *	JNI_SET_BYTE_ARRAY_EXR
 *
 * PURPOSE
 *	Set a Java byte array to VM. If something goes wrong, throws
 *	a java/lang/RuntimeException and return.
 *
 * SYNOPSIS
 */
#define JNI_SET_BYTE_ARRAY_EXR(jenv, len, e, value, rv)	\
	JNI_SET_BYTE_ARRAYR						\
	(									\
		jenv,								\
		len,								\
		e,								\
		RUNTIME_EX,							\
		"Array access error",					\
		value,							\
		rv								\
	)
/*
 * INPUTS
 *	jenv	- Java environment.
 *	len	- length of array.
 *	e	- jclass exception object.
 *	value	- ponter to jbyte pointer with data.
 *	rv	- value to return.
 *
 ******/



/*
 ****if* Nharu/JNI_Facilities
 *
 * NAME
 *	JNI_SET_BYTE_ARRAY_OR_DIER
 *
 * PURPOSE
 *	Set a Java byte array to VM. If something goes wrong, throws
 *	a java/lang/RuntimeException, execute a dieblock and return.
 *
 * SYNOPSIS
 */
#define JNI_SET_BYTE_ARRAY_OR_DIER(jenv, len, e, value, dieblock, rv)	\
{												\
	JNI_ASSERT_OR_DIER								\
	(											\
		jenv,										\
		rv = (*jenv)->NewByteArray(jenv, len),				\
		e,										\
		RUNTIME_EX,									\
		"Array access error",							\
		dieblock,									\
		JNI_NULL									\
	);											\
	(*jenv)->SetByteArrayRegion							\
	(											\
		jenv,										\
		rv,										\
		0L,										\
		len,										\
		(jbyte *) value								\
	);											\
}
/*
 * INPUTS
 *	jenv		- Java environment.
 *	len		- length of array.
 *	e		- jclass exception object.
 *	value		- ponter to jbyte pointer with data.
 *	dieblock	- block to execut if operation fails.
 *	rv		- value to return.
 *
 ******/


#define JNI_GET_STRING_ARGR(_env, _from, _to, _ex, _rv)				\
{													\
	JNI_ASSERTR											\
	(												\
		_env,											\
		_to = (char *) (*_env)->GetStringUTFChars(_env, _from, NULL),	\
		_ex,											\
		NULL_POINTER_EX,									\
		"String argument must not be null",						\
		_rv											\
	);												\
}

#define ASSERTR_NHARU_ERROR(jenv, exp, msgv, e, class, rv)		\
{											\
	if (!(exp))									\
	{										\
		NH_get_last_error(&msgv);					\
		JNI_THROW_EXCEPTION(jenv, e, class, msgv);		\
		return rv;								\
	}										\
}

#define ASSERT_NHARU_ERROR(jenv, exp, msgv, e, class)		\
{										\
	if (!(exp))								\
	{									\
		NH_get_last_error(&msgv);				\
		JNI_THROW_EXCEPTION(jenv, e, class, msgv);	\
		return;							\
	}									\
}

#endif
