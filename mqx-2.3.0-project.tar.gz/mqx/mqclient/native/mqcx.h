#ifndef __MQCX_H__
#define __MQCX_H__

#if defined(__GNUC__)	/* IBM WebSphere MQ is not a pedantic one... */
#	pragma GCC diagnostic ignored "-Wlong-long"
#endif

#include <cmqc.h>
#include <cmqxc.h>

#if	(						\
		defined(linux) ||			\
		defined(__linux) ||		\
		defined(__linux__) ||		\
		defined(__gnu_linux) ||		\
		defined(unix) ||			\
		defined(__unix) ||		\
		defined(__unix__)			\
	)
#	undef MQX_WIN
#	define MQX_UX				1
#	define _GNU_SOURCE
#   define LIBEXPORT
#   define LIBCALL
#else
#   define LIBEXPORT __declspec(dllexport)
#   define LIBCALL __stdcall
#	undef MQX_UX
#	define MQX_WIN				1
#endif

#ifndef NULL
#	if defined(__cplusplus)
#		if (__cplusplus >= 201103L)
#			define NULL			null_ptr
#		else
#			define NULL			((void *) 0)
#		endif
#	else
#		define NULL				0
#	endif
#endif

#ifdef __GNUC__
#	define _IN_					const
#	define _OUT_
#	define _INOUT_
#	define _NOP_				__asm__("nop")
#	define inline				__inline__
#else
#	include <sal.h>
#	define _IN_					_In_ const
#	define _OUT_				_Out_
#	define _INOUT_				_Inout_
#	define _NOP_				__asm nop
#	define inline				__inline
#endif

#define MQX_TRUE					1
#define MQX_FALSE					0
#define MQX_HAS_FAILED(reason)		(reason != MQRC_NONE)
#define MQX_ARGUMENT_ERROR			(-1)
#define MQX_MEMORY_ERROR			(-2)

/* #define MQX_CONN_OPTIONS			(MQCNO_FASTPATH_BINDING | MQCNO_HANDLE_SHARE_NONE | MQCNO_ALL_CONVS_SHARE) */
#define MQX_CONN_OPTIONS				(MQCNO_FASTPATH_BINDING | MQCNO_HANDLE_SHARE_NONE)
#define MQX_CONN_OPTIONS_SHARE_NO_BLOCK	(MQCNO_FASTPATH_BINDING | MQCNO_HANDLE_SHARE_NO_BLOCK)
#define MQX_CONN_OPTIONS_SHARE_BLOCK	(MQCNO_FASTPATH_BINDING | MQCNO_HANDLE_SHARE_BLOCK)
#define MQX_MQCNO_DEFAULT			{MQCNO_STRUC_ID_ARRAY},		\
							MQCNO_VERSION_2,			\
							MQX_CONN_OPTIONS,			\
							0,					\
							NULL,					\
							{MQCT_NONE_ARRAY},		\
							NULL,					\
							0,					\
							{MQCONNID_NONE_ARRAY},		\
							0,					\
							NULL

#define MQX_MQCNO_SHARED_BL			{MQCNO_STRUC_ID_ARRAY},		\
							MQCNO_VERSION_2,			\
							MQX_CONN_OPTIONS_SHARE_BLOCK,			\
							0,					\
							NULL,					\
							{MQCT_NONE_ARRAY},		\
							NULL,					\
							0,					\
							{MQCONNID_NONE_ARRAY},		\
							0,					\
							NULL

#define MQX_MQCNO_SHARED_NO_BL			{MQCNO_STRUC_ID_ARRAY},		\
							MQCNO_VERSION_2,			\
							MQX_CONN_OPTIONS_SHARE_NO_BLOCK,			\
							0,					\
							NULL,					\
							{MQCT_NONE_ARRAY},		\
							NULL,					\
							0,					\
							{MQCONNID_NONE_ARRAY},		\
							0,					\
							NULL


#define MQX_MQCD_KEEPALIVE			600000
#define MQX_MQCD_DEFAULT			{""},					\
							MQCD_VERSION_7,			\
							MQCHT_CLNTCONN,			\
							MQXPT_TCP,				\
							{""},					\
							{""},					\
							{""},					\
							{""},					\
							{""},					\
							{""},					\
							{""},					\
							50,					\
							6000,					\
							10,					\
							60,					\
							999999999,				\
							1200,					\
							{""},					\
							{""},					\
							{""},					\
							{""},					\
							999999999,				\
							4194304,				\
							MQPA_DEFAULT,			\
							MQCDC_NO_SENDER_CONVERSION,	\
							{""},					\
							{""},					\
							{""},					\
							{""},					\
							{""},					\
							{""},					\
							{""},					\
							MQMCAT_PROCESS,			\
							{""},					\
							{""},					\
							{""},					\
							{""},					\
							{""},					\
							10,					\
							1000,					\
							1,					\
							0,					\
							MQNPMS_FAST,			\
							MQCD_CURRENT_LENGTH,		\
							MQ_EXIT_NAME_LENGTH,		\
							MQ_EXIT_DATA_LENGTH,		\
							0,					\
							0,					\
							0,					\
							NULL,					\
							NULL,					\
							NULL,					\
							NULL,					\
							NULL,					\
							NULL,					\
							NULL,					\
							0,					\
							0,					\
							0,					\
							0,					\
							NULL,					\
							NULL,					\
							{MQSID_NONE_ARRAY},		\
							{MQSID_NONE_ARRAY},		\
							{""},					\
							NULL,					\
							0,					\
							MQSCA_REQUIRED,			\
							MQX_MQCD_KEEPALIVE,		\
							{""},					\
							0,					\
							{MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE},	\
							{MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE,	\
							MQCOMPRESS_NOT_AVAILABLE},	\
							0,					\
							0,					\
							50,					\
							MQMON_OFF,				\
							MQMON_OFF,				\
							10,					\
							MQPROP_COMPATIBILITY,		\
							999999999,				\
							999999999,				\
							0,					\
							MQCAFTY_PREFERRED

#define MQX_MQGMO_DEFAULT			{MQGMO_STRUC_ID_ARRAY},					\
							MQGMO_VERSION_2,						\
							(MQGMO_FAIL_IF_QUIESCING ),				\
							0,								\
							0,								\
							0,								\
							{""},								\
							(MQMO_MATCH_MSG_ID | MQMO_MATCH_CORREL_ID),	\
							MQGS_NOT_IN_GROUP,					\
							MQSS_NOT_A_SEGMENT,					\
							MQSEG_INHIBITED,						\
							' ',								\
							{MQMTOK_NONE_ARRAY},					\
							MQRL_UNDEFINED,						\
							0,								\
							MQHM_NONE

#define MQX_GET_OPTIONS				(MQOO_INPUT_SHARED | MQOO_FAIL_IF_QUIESCING)
#define MQX_PUT_OPTIONS				(MQOO_OUTPUT | MQOO_FAIL_IF_QUIESCING)

#define MQX_ASSERT_MEM_OR_DIE(exp, die)	\
{							\
	if (!(exp))					\
	{						\
		die;					\
		return MQX_MEMORY_ERROR;	\
	}						\
}
#define MQX_ASSERT_ARG(exp)			\
{							\
	if (!(exp))					\
		return MQX_ARGUMENT_ERROR;	\
}


typedef MQBYTE MQXNAME[MQ_CONN_NAME_LENGTH];
typedef MQBYTE MQXCHANNEL[MQ_CHANNEL_NAME_LENGTH];
typedef MQBYTE MQXQMGR[MQ_Q_MGR_NAME_LENGTH];
typedef MQBYTE MQXQUEUE[MQ_Q_NAME_LENGTH];

typedef struct MQX_CONNECTION_ST
{
	MQHCONN	hConn;
	MQXQMGR	manager;
	MQBOOL	trans;
	MQBOOL	dirty;

} MQX_CONNECTION, *PMQX_CONNECTION;

typedef struct MQX_QUEUE_ST
{
	MQHOBJ	hObj;
	MQBOOL	convert;
	MQBOOL	convertMsgId;
	MQBOOL	convertCorrelId;
	PMQBYTE	buffer;
	MQLONG	bufflen;
} MQX_QUEUE, *PMQX_QUEUE;

typedef struct MQX_MESSAGE_ST
{
	MQBYTE24	msgId;
	MQBYTE24	correlId;
	PMQBYTE	buffer;
	MQLONG	buflen;

} MQX_MESSAGE, *PMQX_MESSAGE;



#if defined(__cplusplus)
extern "C" {
#endif

LIBEXPORT MQLONG LIBCALL MQX_new_connection
(
	_IN_ MQXNAME,
	_IN_ MQXCHANNEL,
	_IN_ MQXQMGR,
	_IN_ char*,
	_IN_ char*,
	_OUT_ PMQX_CONNECTION*
);

LIBEXPORT MQLONG LIBCALL MQX_new_connection_ex
(
	_IN_ MQXNAME,
	_IN_ MQXCHANNEL,
	_IN_ MQXQMGR,
	_IN_ MQBOOL,
	_IN_ MQBOOL,
	_IN_ char*,
	_IN_ char*,
	_OUT_ PMQX_CONNECTION*
);

LIBEXPORT MQLONG LIBCALL MQX_release(_IN_ PMQX_CONNECTION);
LIBEXPORT MQLONG LIBCALL MQX_open
(
	_IN_ PMQX_CONNECTION,
	_IN_ MQXQUEUE,
	_IN_ MQBOOL,
	_IN_ MQBOOL,
	_IN_ MQBOOL,
	_IN_ MQBOOL,
	_IN_ MQLONG,
	_OUT_ PMQX_QUEUE*
);
LIBEXPORT MQLONG LIBCALL MQX_close(_IN_ PMQX_CONNECTION, _IN_ PMQX_QUEUE);
LIBEXPORT MQLONG LIBCALL MQX_send
(
	_IN_ PMQX_CONNECTION,
	_IN_ PMQX_QUEUE,
	_IN_ PMQBYTE,
	_IN_ PMQBYTE,
	_IN_ PMQBYTE,
	_IN_ MQLONG,
	_IN_ MQLONG,
	_OUT_ PMQX_MESSAGE
);
LIBEXPORT MQLONG LIBCALL MQX_receive
(
	_IN_ PMQX_CONNECTION,
	_IN_ PMQX_QUEUE,
	_IN_ PMQBYTE,
	_IN_ PMQBYTE,
	_IN_ MQLONG,
	_OUT_ PMQX_MESSAGE
);
static inline MQLONG MQX_begin(_IN_ PMQX_CONNECTION hHandle)
{
	hHandle->trans = MQX_TRUE;
	return MQRC_NONE;
}

LIBEXPORT MQLONG LIBCALL MQX_begin_ex(_IN_ PMQX_CONNECTION hHandle);

LIBEXPORT MQLONG LIBCALL MQX_commit(_IN_ PMQX_CONNECTION);
LIBEXPORT MQLONG LIBCALL MQX_back(_IN_ PMQX_CONNECTION);


void MQX_utf8_to_ebcdic
(
	PMQBYTE dest,
	PMQBYTE src,
	MQLONG size
);
void MQX_ebcdic_to_utf8
(
	PMQBYTE dest,
	PMQBYTE src,
	MQLONG size
);
LIBEXPORT MQLONG LIBCALL MQX_depth(_IN_ PMQX_CONNECTION, _IN_ MQXQUEUE, _OUT_ MQLONG*);




#if defined(__cplusplus)
}
#endif


#endif
