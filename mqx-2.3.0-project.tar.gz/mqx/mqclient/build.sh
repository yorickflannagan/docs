#!/bin/bash
#
# MQX
# Build and package Java component and its dependencies
# Arguments
#	-j [jdk-location]: JDK home directory. Optional: default JAVA_HOME environment variable or found by update-alternatives. Must be JDK 1.7.0.
#	-d [mqc-dist]: WebSphre MQClient distribution directory. Optional: default is to search from $HOME
#
check_java()
{
	printf "%s\n" "Searching for JDK 7..."
	if [ -z "$JAVA_HOME" ]; then
		JAVA_HOME=$(update-java-alternatives --jre -l | grep java-7 | awk '{ print $3 }')
		if [ -z "$JAVA_HOME" ]; then
			JAVA_HOME=$(update-java-alternatives --jre -l | grep java-1.7 | awk '{ print $3 }')
		fi
	fi
	if [ ! -f "$JAVA_HOME/bin/java" ]; then
		printf "\n%s\n" "*** Error: JDK must be available ***"
		exit 1
	fi
	local version=$("$JAVA_HOME/bin/java" -version 2>&1 | head -n 1 | cut -d'"' -f2 | cut -d'.' -f2)
	if [[ "$version" > "7" ]]; then
		printf "\n%s\n" "*** Error: JDK must be of version 7 ***"
		exit 1
	fi
	printf "JDK 7 found at %s\n" "$JAVA_HOME"
}
check_mqdist()
{
	printf "%s\n" "Searching for WebSphere MQ Client distribution files..."
	if [ -z "$MQ_INSTALL" ]; then
		local manifest=$(find $HOME -type d ! -perm -g+r,u+r,o+r -prune -o -name MANIFEST.Redist -printf "%T@ %p\n" | sort -n | tail -1 | cut -f2- -d" ")
		MQ_INSTALL=$(dirname "$manifest")
	fi
	if [ ! -f "$MQ_INSTALL/lib64/libmqic_r.so" ]; then
		printf "\n%s\n" "*** Error: MQ Client distribution files must be available ***"
		exit 3
	fi
	printf "WebSphere MQ Client distribution files found at %s\n" "$MQ_INSTALL"
}
make_dist()
{
	local version=$(git describe --tags)
	cd target
	mkdir --parents mqx-dist/lib
	mkdir --parents mqx-dist/lib64
	cp libmqx.so mqx-dist
	cp "$MQ_INSTALL/lib/ccsid.tbl" mqx-dist/lib
	cp "$MQ_INSTALL/lib/ccsid_part2.tbl" mqx-dist/lib
	cp "$MQ_INSTALL/lib64/libmqe_r.so" mqx-dist/lib64
	cp "$MQ_INSTALL/lib64/libmqic_r.so" mqx-dist/lib64
	tar -czvf mqx-dist-$version.tar.gz mqx-dist
	rm --recursive --force mqx-dist
	cd ..
}
while getopts "j:m:d:" c
do
  case $c in
    j) JAVA_HOME=$OPTARG ;;
    d) MQ_INSTALL=$OPTARG ;;
  esac
done

printf "\n%s\n" "* * * * * * * * * * * * * "
printf "%s\n" "MQX components distribution"
printf "%s\n" "* * * * * * * * * * * * * "
check_java
check_mqdist
export JAVA_HOME=$JAVA_HOME
export MQ_INSTALL=$MQ_INSTALL
mvn clean

printf "%s\n" "Building JNI library..."
make -C native
status=$?
if [ "$status" -gt "0" ]; then
	printf "*** Error: native build failure: %d\n" $status
fi

printf "%s\n" "Building Java component..."
mvn package
status=$?
if [ "$status" -gt "0" ]; then
	printf "*** Error: Java build failure: %d\n" $status
fi

printf "%s\n" "Packaging distributions files..."
make_dist
printf "%s\n" "All things done!"
