var sgrprototype = {
    "nssrv:SERVICO_ENTRADA": {
        "$": {
            "xmlns:nssrv": "http://caixa.gov.br/sisgr/seguranca_integrada/autenticacao",
            "xmlns:sibar_base": "http://caixa.gov.br/sibar",
            "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
            "xsi:schemaLocation": "http://caixa.gov.br/sisgr/seguranca_integrada/autenticacao AUTENTICACAO.xsd "
        },
        "sibar_base:HEADER": {
            "VERSAO": "02.02",
            "USUARIO_SERVICO": "XXX",
            "OPERACAO": "AUTENTICACAO",
            "SISTEMA_ORIGEM": "SIBNS",
            "DATA_HORA": "AAAAMMDDHHmmSS"
        },
        "DADOS": {
            "AMBIENTE": {
                "TIPO": "X",
                "SIGLA": "XXXXXXXX"
            },
            "CREDENCIAL": {
                "TIPO": "NNNN",
                "CODIGO": "XXXXXXX"
            },
            "EMAIL": "XXXXXXXX@XXXXXXXX",
            "SENHA": "XXXXXX",
            "INDICADOR_AUTENTICACAO": "X",
            "IP": "NN.NNN.NN.NN"
        }
    }
}
function newBlueprint()
{
    return Object.assign({}, sgrprototype);
}

module.exports=newBlueprint;