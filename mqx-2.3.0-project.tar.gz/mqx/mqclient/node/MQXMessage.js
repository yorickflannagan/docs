'use strict';
const ref = require('ref');
const libmqx = require  ("./mqxbind");
const MQException = require("./MQException");
const MQRC = require("./MQRC");

class MQXMessage
{

    constructor(msgObuffer)
    {
        this.msg = new libmqx.MESSAGE();
        this.msg.buflen=-1;
        if ( typeof msgObuffer != 'undefined') {
            if( !Buffer.isBuffer(msgObuffer) && typeof msgObuffer !== "string" &&   !msgObuffer.isArray() )
            {
                 throw new MQException(MQRC.MQX_MESSAGE_BUFFER_TYPE_ERROR);
            }
            this.msg.buffer=msgObuffer;
            this.msg.buflen=msgObuffer.length;
        }
    }

    getBuffer() { 
            if(this.msg.buflen == -1) throw new MQException(MQRC.MQX_MESSAGE_BUFFER_ERROR); 
            return ref.reinterpret(this.msg.buffer, this.msg.buflen);   
    }
    setBuffer(buffer) { this.msg.buffer = buffer; if(buffer) this.msg.buflen = buffer.length;}
    getBuflen() { return this.msg.buflen;   }
    getID()     { return this.msg.msgId;    }
    setID(id)
    {
        this.msg.id = id;
    }
    getCorrel() { return this.msg.correlId; }
    setCorrel(correlId)
    {
        this.msg.correlId = correlId;
    }
}

module.exports=MQXMessage;