'use strict';
const BPromise = require('bluebird');
const genericPool = BPromise.promisifyAll(require('generic-pool'));
const MQException = require('./MQException');

const MQXConnection = require('./MQXConnection');



function createPool(pOps)
{
        var opts = {
            min: pOps.minpool,
            max: pOps.maxpool,
            Promise: BPromise,
            testOnBorrow: true
        };
        var factory = {
            create: function(){
                return new BPromise(function(resolve, reject){
                    try { 
                        var conn = new MQXConnection(pOps.address, pOps.channel, pOps.manager);
                        resolve(conn);
                    }
                    catch (e) { reject(e); }
                });
            },
            destroy: function(conn){
                return new BPromise(function(resolve, reject){
                    try{ 
                        var ret = conn.close();
                        if(ret) resolve();
                        else reject(ret);
                     }
                    catch (e) { reject(e); }
                });
            },
            validate: function(conn){
                return new BPromise(function(resolve, reject){
                    if(!conn.open || !conn.good) { return resolve(false); } 
                    conn.closeQueues().then( function()  {  resolve(true);  }
                    ).catch( function (e) {  resolve(false);  } );
                });
            }
        };
        return genericPool.createPool(factory, opts);
}

    function closePool(pool)
    {
        pool.drain().then(function() {
            pool.clear();
        });
    }

module.exports={ createPool, closePool };


