const MQXMessage = require("./MQXMessage")
const BPromise = require('bluebird');


function simpleCall(pool, request, response, payload)
{
   return brokerCall(pool, request, response, payload, 5000, true).catch(
       e => {
           if( e.reason == 2009)
           {
               return brokerCall(pool, request, response, payload, 5000, true);
           }
           else{
               reject(e);
           }
       }
   )
}
    
function brokerCall(pool, request, response, payload, timeout, convert)
{
    return new BPromise ( function brokerPromise(resolve, reject)
    {
        pool.acquire().then ( conn =>
        {
            conn.openQueue(request,false,convert,false,false,0).then
            (
                queuePut => {
                        var messageBuf = Buffer.from(payload);
                        return BPromise.all ( 
                            [   queuePut.put(new MQXMessage(messageBuf)),
                                conn.openQueue(response,true,convert,false,false,1024) ] 
                        );
                }
            ).then(
              ([msgPut, queueGet]) => {return queueGet.get(new MQXMessage(), null, msgPut.getID(), timeout);  }

                // Teste curto circuito
                //    ([msgPut, queueGet]) => {
                //      return queueGet.get(new MQXMessage(), msgPut.getID() , null, timeout); }
            ).then(
                msgGet => { resolve(msgGet); }
            ).catch( e => { 
                
                /*  descobrir se é um mqexception,
                    se for  e.reason==2033 lançar uma mensagem diferente,
                    indicando a falta de resposta em tempo. 
                */
                console.log("Vou rejeitar... ");
                reject(e); 
            }
            ).finally( 
                () => { 
                        conn.closeQueues().finally( 
                            () => { return pool.release(conn); } 
                        );
                    }
            );
        });
    }).timeout(timeout+100, "Ocorreu um timeout durante a chamada ao broker. O serviço está ativo? Não ocorreu nenhum ABEND? Qual é o tempo esperado pra atendimento?");
}



module.exports={ simpleCall, brokerCall  };