const ref = require('ref');
const ffi = require('ffi');
const path = require('path');
const Struct = require('ref-struct');
const ArrayType = require('ref-array');
const genericPool = require('generic-pool');

const VOID = ref.types.void;
const boolean = ref.types.bool;
const VOID_P = ref.refType(VOID);
const VOID_P_P = ref.refType(VOID_P);
const UCHAR = ref.types.uchar;
const UCHAR_P = ref.refType(UCHAR);

const LONG_P = ref.refType(ref.types.int64);
const MQ_MSG_ID_LENGTH = 24;
const MQBYTE24 = ArrayType(UCHAR, 24);
const MQXQUEUE = ref.refType(UCHAR); // Sempre lembrar de alocar pelo MQ_Q_NAME_LENGTH.
const MQXNAME = ref.refType(UCHAR);
const MQXCHANNEL = ref.refType(UCHAR);
const MQXMANAGER = ref.refType(UCHAR);

const MQ_Q_MGR_NAME_LENGTH = 48;
const MQ_Q_NAME_LENGTH = 48;
const MQ_CONN_NAME_LENGTH = 264;
const MQ_CHANNEL_NAME_LENGTH = 20;

const CHAR = ref.types.char;
const CHAR_P = ref.refType(CHAR);

var MESSAGE = Struct({
    'msgId'   : MQBYTE24,
    'correlId': MQBYTE24,
    'buffer'  : UCHAR_P,
    'buflen'  : 'int'
});

const MESSAGE_P = ref.refType(MESSAGE);

const libmqx = ffi.Library(path.resolve(__dirname, 'libmqx'), {
    'MQX_new_connection': [ 'int', [ MQXNAME, MQXCHANNEL, MQXMANAGER, CHAR_P, CHAR_P, VOID_P_P ] ],
    'MQX_new_connection_ex': [ 'int', [ MQXNAME, MQXCHANNEL, MQXMANAGER, boolean,  boolean, CHAR_P, CHAR_P, VOID_P_P ] ],
    'MQX_release': [ 'int', [ VOID_P ] ],

    'MQX_open': [ 'int', [ VOID_P, MQXQUEUE, boolean, boolean, boolean,  boolean,  'int',  VOID_P_P ] ],
    'MQX_close': [ 'int', [ VOID_P, VOID_P] ],

    'MQX_send': [ 'int', [ VOID_P, VOID_P, UCHAR_P, UCHAR_P, UCHAR_P, 'int', 'int', MESSAGE_P  ] ],
    'MQX_receive': [ 'int', [ VOID_P, VOID_P, UCHAR_P, UCHAR_P,  'int', MESSAGE_P  ] ],
    'MQX_depth': [ 'int', [ VOID_P, MQXQUEUE , LONG_P] ],

    'MQX_begin_ex': [ 'int', [ VOID_P] ],
    'MQX_commit': [ 'int', [ VOID_P] ],
    'MQX_back': [ 'int', [ VOID_P] ]
});

/*

   int MQX_new_connection_ex( address , channel , manager , shared, blocking, **hConnHandle )
        Abre uma conexão com o MQ.
        - Address tem que ter o formato host(port)
        - Não pode ser maior que MQ_CONN_NAME_LENGTH, ou seja, 264 caracteres*.
        - shared indica se a conexão pode ser compartilhada por várias threads
        - blocking. no caso de conexões compartilhaveis:
            blocking indica que quando uma conexão está sendo ativamente utilizada (GET/PUT) as demais threads ficam esperando.
            Se for false ao invés de esperar as demais threads recebem um erro e podem tomar decisões sobre isto sem ficarem bloqueadas.
        - A responsabilidade de alocação da connection é da biblioteca
        - Ao final liberar com MQX_release


   int MQX_new_connection( address , channel , manager , **hConnHandle )
        Abre uma conexão com o MQ.
        - Address tem que ter o formato host(port)
        - Não pode ser maior que MQ_CONN_NAME_LENGTH, ou seja, 264 caracteres*.
        - A responsabilidade de alocação da connection é da biblioteca
        - Ao final liberar com MQX_release

    int MQX_release(*connHandle)
        Fecha a conexão com o MQ e libera os recursos associados.
        - connHandle é o handle da conexão usado em MQX_new_connection dereferenciado. aka: hConnHandle.deref(),

    int MQX_open ( *connection, queue, input, convert, convertMsgId, convertCorrelId, maxMsgLen, **queueHandle )
        Abre uma fila em uma conexão.
        - Conexão deve estar ativa
        - queue não deve ser maior que MQ_Q_NAME_LENGTH, ou seja, 48 caracteres*
        - Se input = true,  maxMsgLen tem que ser maior que zero.
        - Se input = false, maxMsgLen tem que ser igual a zero.

    int MQX_close(*connHandle, *queueHandle)
        Fecha a conexão
        - connHandle é o handle da conexão usado em MQX_new_connection dereferenciado. aka: hConnHandle.deref(),
        - queueHandle é o handle da conexão usado em MQX_open dereferenciado. aka: hQueueHandle.deref(),

    int MQX_send(*connHandle, *queueHandle, *msgId, *correlId, *buffer, buflen, expire, **hMsg )
        Envia uma mensagem.
        - Conexão(connHandle) deve estar ativa
        - O handle da fila(queueHandle) precisa estar aberto.
        - A fila precisa estar aberta para escrita (input = false, no MQX_open).
        - msgId se diferente de nulo, sobreescreve o mqid do mq. o tamanho deve ser de 24 bytes(core dump a vista).
        - correlId se diferente de nulo, sobreescreve o mqid do mq. o tamanho deve ser de 24 bytes(core dump a vista).
        - buffer tem que ter pelo menos o tamanho de buflen
        - expire diferente de zero marca a mensagem para expirar. Valores em centésimos(pergunte a IBM) de segundo.

    int MQX_receive ( *connHandle, *queueHandle, *msgId, *correlId, timeout, **hMsg )
        Envia uma mensagem.
        - Conexão(connHandle) deve estar ativa
        - O handle da fila(queueHandle) precisa estar aberto.
        - A fila precisa estar aberta para escrita (input = true, no MQX_open).
        - msgId se diferente de nulo, sobreescreve o mqid  na busca da mensagem.
        - correlId se diferente de nulo, sobreescreve o correlid na busca da mensagem.
        - timeout valor de espera pela mensagem, se zero retorna imediatamente.

        * valores retirados do cmqc.h na versão MQ 7.5.x.
*/


function newHandle() {
    return ref.alloc(VOID_P_P);
}





module.exports= {  
                  libmqx,
                  MQX_new_connection: libmqx.MQX_new_connection,
                  MQX_new_connection_ex: libmqx.MQX_new_connection_ex,
                  MQX_release: libmqx.MQX_release,
                  MQX_open: libmqx.MQX_open,
                  MQX_close: libmqx.MQX_close,
                  MQX_send: libmqx.MQX_send,
                  MQX_receive: libmqx.MQX_receive,
                  MQX_depth: libmqx.MQX_depth,
                  MQX_begin_ex: libmqx.MQX_begin_ex,
                  MQX_commit: libmqx.MQX_commit,
                  MQX_back: libmqx.MQX_back,
                  MESSAGE: MESSAGE,
                  newHandle,
                  VOID_P,
                  VOID_P_P,
                  LONG_P,
                  MQ_Q_NAME_LENGTH,
                  MQ_CONN_NAME_LENGTH,
                  MQ_CHANNEL_NAME_LENGTH,
                  MQ_Q_MGR_NAME_LENGTH
                 };