'use strict';
const ref = require('ref');
const libmqx = require  ("./mqxbind");
const MQException = require ('./MQException');
const MQRC = require("./MQRC");
const MQXMessage = require("./MQXMessage");
const BPromise = require('bluebird');


class MQXQueue
{
    constructor(connHandle, queue, input, convert, convertMsgId, convertCorrelId, maxMsgLen, hQueueHandle)
    {
        this.connHandle=connHandle;
        this.hQueueHandle=hQueueHandle;
        this.input=input;
        this.open = false;
        var ret = libmqx.MQX_open(this.connHandle, queue, input, convert, convertMsgId, convertCorrelId, maxMsgLen, hQueueHandle);
        if(ret) throw new MQException(ret);
        this.queueHandle=hQueueHandle.deref();
        this.open = true;
    }

    close()
    {
        var me = this;
        return new BPromise( function closeQueuePromise(resolve, reject)
        {
            var ret = 0;
            if(me.open) {
                me.open = false;
                ret = libmqx.MQX_close(me.connHandle, me.queueHandle);
                if(ret) { reject(new MQException(ret)); } else { resolve(); }
            }
            else {
                reject(new MQException(MQRC.MQX_QUEUE_ALREADY_CLOSED));
            }
        }
        ).bind(this);
    }

    get(message, id, correl, timeout)
    {
        var me = this;
        return new BPromise( function getQueuePromise(resolve, reject) 
            {
                if(!me.input) return reject(new MQException(MQRC.MQX_OUTPUT_ONLY));
                var _id=null;
                var _correl=null;
                if(id) { _id = id.buffer; }
                if(correl) { _correl = correl.buffer; }
                var ret = libmqx.MQX_receive(me.connHandle, me.queueHandle, _id, _correl, timeout, message.msg.ref() );
                if(ret) { 
                    reject(new MQException(ret)); } else{ resolve(message); 
                }
            }
        ).bind(this);    
    }

    put(message)
    {
        var me = this;
        return new BPromise( function putQueuePromise(resolve, reject) 
        {
            if(me.input) reject(new MQException(MQRC.MQX_INPUT_ONLY));
                var ret = libmqx.MQX_send(me.connHandle, me.queueHandle, null, null, message.msg.buffer,  message.msg.buflen, 0, message.msg.ref() );
                if(ret) { reject(new MQException(ret)); } else{ resolve(message); }
            }
        ).bind(this);    
    }

}



//Promise.promisifyAll(MQXQueue.prototype);
module.exports=MQXQueue;