"use strict";

const xml2js = require('xml2js');
const fs = require('fs');
const df = require('../dateformat.js');
const sgr = require('./authsgr');
const MQXBroker = require("../MQXBroker");
const BPromise = require('bluebird');
const pool = require('./testPoolD2.js');
const parser = new xml2js.Parser();
const builder = new xml2js.Builder();

//TODO: Ajustar o teste


  function request(xmldata , cert)
  {
        parser.parseString(xmldata, (err, result) => {
            var agora = df(new Date());
            var header = result['nssrv:SERVICO_ENTRADA']['sibar_base:HEADER'][0];
            var dados = result['nssrv:SERVICO_ENTRADA']['DADOS'][0];
            header.DATA_HORA[0]=agora;
            dados.CONTROLE[0].WEB_SERVER[0].DATA_HORA_WEB[0]=agora;
            dados.CONTROLE[0].USUARIO[0].CERTIFICACAO_SGR[0]=cert;
            MQXBroker.simpleCall(pool,req, res, dados).then(
                msgRet => {
                    console.log(msgRet.getBuffer().toString());
                }
            );
            
        });
      
  }
  
  