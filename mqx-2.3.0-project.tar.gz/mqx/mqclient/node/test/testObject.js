const MQXMessage = require("../MQXMessage");
const BPromise = require('bluebird');
const pool = require('./testPool.js');

var queue = "LQ.REQ.TESTE_DIEGO";

pool.acquire().then( conn =>
{
    conn.begin().then( theq => { return conn.openQueue(queue,false,false,false,false,0); }
    ).then( queuePut => {
            var messageBuf = Buffer.alloc(25);
            messageBuf.write("Mensagem[\0\0a] de texto");
            return BPromise.all([queuePut.put(new MQXMessage(messageBuf)), conn.openQueue(queue,true,false,false,false,128)]);
        }
    ).then(
        ([msgPut, queueGet]) => {return queueGet.get(new MQXMessage(), msgPut.getID(), null, 200); }
    ).then(
        msgGet => { console.log(msgGet.getBuffer().toString()); conn.commit(); }
    ).catch( e => { console.log(e); conn.back(); }
    ).finally( () => {
            console.log("releasing");
            conn.closeQueues().finally( () => { return pool.release(conn); } );
        }
    );
});
console.log("isto deveria ocorrer depois e ocorre...");