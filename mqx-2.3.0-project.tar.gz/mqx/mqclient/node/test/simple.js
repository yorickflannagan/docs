'use strict';
const MQXPoolFactory = require('../MQXPoolFactory');
const MQException = require ('../MQException');
const MQXMessage = require("../MQXMessage");
const BPromise = require('bluebird');


var ops = {
    address : "rjd2.des.corerj.caixa(1414)",
    channel : "TESTE_DIEGO.SVRCONN",
    manager : "RJD1",
    minpool : 1,
    maxpool : 5
};

var queue = "LQ.REQ.TESTE_DIEGO";

var pool = MQXPoolFactory.createPool(ops);
pool.acquire().then(
    function(conn)
    {
        console.log("pool connection obtida.");
        conn.openQueue(queue,false,false,false,false,0).then(
            putQ => {
                console.log("Fila aberta. Fechando.");
                return putQ.close();
            }
        ).then(() => {pool.release(conn);});            
    }).catch(
        err => {
            console.log(err);
        }
    );
