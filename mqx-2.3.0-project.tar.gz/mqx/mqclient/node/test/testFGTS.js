const MQXBroker = require("../MQXBroker");
const BPromise = require('bluebird');
const pool = require('./testPoolD2.js');
const fs = require('fs');

var req="SIBNS.REQ.INFORMACOES_FGTS";
var res="SIBNS.RSP.INFORMACOES_FGTS";
fs.readFile('/home/dsvs/development/mqx/mqclient/node/samples/CONTA_FGTS.xml', 'utf8', function (err,data) {
  if (err) {
    return console.log(err);
  }
  MQXBroker.simpleCall(pool,req, res, data).then(
    msgRet => {
        console.log(msgRet.getBuffer().toString());
    }
  );
});


