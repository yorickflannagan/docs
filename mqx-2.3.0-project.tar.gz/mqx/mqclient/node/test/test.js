const libmqx = require ('../mqxbind');
const MQException = require ('../MQException');
const ref = require('ref');




var address = "rjd2.des.corerj.caixa(1414)";
var channel = "TESTE_DIEGO.SVRCONN";
var manager = "RJD1";
var hConnHandle = libmqx.newHandle();
var hPutQueueHandle = libmqx.newHandle();
var hGetQueueHandle = libmqx.newHandle();
var messagePut = new libmqx.MESSAGE();
var messageGet = new libmqx.MESSAGE();
var queueBuf = Buffer.alloc(libmqx.MQ_Q_NAME_LENGTH);
queueBuf.write("LQ.REQ.TESTE_DIEGO");




var ret = libmqx.MQX_new_connection(address, channel, manager, hConnHandle);
console.log("Abertura da conexão: " + ret);
if(!ret)
 {
    var mqHandle = hConnHandle.deref();
    try 
    {
        ret = libmqx.MQX_open(mqHandle, queueBuf, false, false, false,  false,  0,  hPutQueueHandle);
        console.log("Abertura da fila de put:" + ret);
        if(!ret)
        {
            var putQueueHandle = hPutQueueHandle.deref();
            try 
            {
                var messageBuf = Buffer.alloc(20);
                messageBuf.write("Mensagem[\0] de texto");
                console.log(messageBuf.toString());
                

                ret = libmqx.MQX_send(mqHandle, putQueueHandle, null, null, messageBuf,messageBuf.length, 0, messagePut.ref() );
                if(!ret)
                {
                    console.log("Message sent!");
                    ret = libmqx.MQX_open(mqHandle, queueBuf, true, false, false,  false,  200,  hGetQueueHandle);
                    console.log("Abertura da fila de get:" + ret);
                    if(!ret)
                    {
                        var getQueueHandle = hGetQueueHandle.deref();
                        try 
                        {
                            ret = libmqx.MQX_receive(mqHandle, getQueueHandle, messagePut.msgId.buffer , null, 0, messageGet.ref() );
                            if(!ret)
                            {
                                console.log("Message received!");
                                console.log(ref.reinterpret(messageGet.buffer,messageGet.buflen).toString() );
                            }
                        }
                        finally { ret = libmqx.MQX_close(mqHandle, getQueueHandle); }
                    }
                }
            }
            finally { ret = libmqx.MQX_close(mqHandle, putQueueHandle); }
        }
    }
    finally {ret = libmqx.MQX_release(mqHandle); }
 }

