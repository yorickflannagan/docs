const MQXBroker = require("../MQXBroker");
const pool = require('./testPoolD2');
const xml2js = require('xml2js');
const builder = new xml2js.Builder();
const sgrcall = require('./sgrBluePrint');

var req="SISGR.REQ.SEGURANCA_INTEGRADA";
var res="SISGR.RSP.SEGURANCA_INTEGRADA";
var sgrObj = sgrcall();

var dados = sgrObj['nssrv:SERVICO_ENTRADA'].DADOS;


dados.CREDENCIAL.TIPO="001";
dados.CREDENCIAL.CODIGO="10015996317";
dados.SENHA="112233";
dados.IP="172.16.25.82";

var xml = builder.buildObject(sgrObj);

MQXBroker.simpleCall(pool,req, res, xml).then(
    msgRet => {
        console.log(msgRet.getBuffer().toString());
    }
);


