const xml2js = require('xml2js');
const fs = require('fs');
const parser = new xml2js.Parser({explicitArray:false});
const builder = new xml2js.Builder();
const jsonxml = require('../samples/jsontestxml');

function transform(xml, jobjfile)
{
    fs.readFile(xml, 'utf8', function (err,data) {
        if (err) {
          return console.log(err);
        }
      
        parser.parseString(data, (err, result) => 
        {
            fs.writeFile(jobjfile, JSON.stringify(result));
        });
    });
}

function toxml(json, xml)
{
        {
            fs.writeFile(xml, builder.buildObject(json));
        }
}

module.exports=transform;
transform("/home/dsvs/development/mqx/mqclient/node/samples/CONTA_FGTS.xml", "/home/dsvs/development/mqx/mqclient/node/samples/CONTA_FGTS.json");
//transform("/home/dsvs/development/mqx/mqclient/node/samples/exemplo-utilizacao-MQ.xml", "/home/dsvs/development/mqx/mqclient/node/samples/exemplo-utilizacao-MQ.json");
//toxml(jsonxml(), '/home/dsvs/development/mqx/mqclient/node/samples/jsontestxml.xml');
//transform("/home/dsvs/development/mqx/mqclient/node/samples/CONTA_FGTS_RESPONSE.xml", "/home/dsvs/development/mqx/mqclient/node/samples/CONTA_FGTS_RESPONSE.json");
