const MQXBroker = require("../MQXBroker");
const BPromise = require('bluebird');
const pool = require('./testPool.js');

var queue = "LQ.REQ.TESTE_DIEGO";


MQXBroker.simpleCall(pool,queue, queue, "Hello Broker!").then(
    msgRet => {
        console.log(msgRet.getBuffer().toString());
    }
);

