const MQXPoolFactory = require('../MQXPoolFactory');

ops = {
    address : "rjd2.des.corerj.caixa(1414)",
    channel : "TESTE_DIEGO.SVRCONN",
    manager : "RJD1",
    minpool : 1,
    maxpool : 5
};

var pool = MQXPoolFactory.createPool(ops);

module.exports=pool;