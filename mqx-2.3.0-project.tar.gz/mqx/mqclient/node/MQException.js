'use strict';
const ExtendableError = require("./errors")
const MQRC = require("./MQRC");
MQRC(0);


class MQException extends ExtendableError {
    constructor(reason) {
        super("[MQReason: "+ reason + "] - " + MQRC(reason));
        this.reason = reason;
    }
}

module.exports= MQException;

