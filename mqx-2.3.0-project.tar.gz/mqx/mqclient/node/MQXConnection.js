'use strict';
const ref = require('ref');
const libmqx = require  ("./mqxbind");
const MQXQueue  = require  ("./MQXQueue");
const MQException = require ('./MQException');
const BPromise = require('bluebird');
const MQRC = require("./MQRC");
const MQX_NO_AUTH = "     ";

class MQXConnection {
    /**
     * Cria uma nova conexão com o MQ.
     */
    constructor(address , channel , manager , shared, blocking, userID, password)
    {
        this.open = false;
        this.address = address;
        this.addressb = Buffer.alloc(libmqx.MQ_CONN_NAME_LENGTH);
        this.addressb.write(address);

        this.channel = channel;
        this.channelb = Buffer.alloc(libmqx.MQ_CHANNEL_NAME_LENGTH);
        this.channelb.write(channel);

        this.manager = manager;
        this.managerb = Buffer.alloc(libmqx.MQ_Q_MGR_NAME_LENGTH);
        this.managerb.write(manager);

        this.shared = shared;
        this.blocking  = blocking;
        this.hConnHandle = ref.alloc(libmqx.VOID_P_P);
        this.queuesOUT = new Map();
	  this.queuesIN = new Map();

	  var user, pwd;
	  if (!userID) { user = MQX_NO_AUTH; pwd = MQX_NO_AUTH; }
	  else { user = userID; pwd = password; }
        var ret = libmqx.MQX_new_connection_ex(this.addressb, this.channelb, this.managerb, shared, blocking, user, pwd, this.hConnHandle);

	  if(ret) throw new MQException(ret);
        this.connHandle = this.hConnHandle.deref();
        this.open = true;
        this.good = true;
        /* TODO: registrar as situaçẽos onde a conexão está com problemas...  falha ao liberar etc. */
    }

    /* 
        Abre uma fila, se já tiver sido aberta para o mesmo tipo de acesso(input = true/false ) 
        lança uma exception pois não dá para garantir que as outras configurações serão as mesmas.

        IMPORTANTE!
        Para abrir a mesma fila com outras configurações que não a de entrada/saida em uma mesma conexão,
        feche primeiro a anterior.
    */
    openQueue( queue, input, convert, convertMsgId, convertCorrelId, maxMsgLen)
    {
        var me = this;
        var p = new BPromise( function openQueuePromise(resolve, reject)
        {
            var mqxQueue = (input) ? me.queuesIN.get(queue) : me.queuesOUT.get(queue);
            if(mqxQueue)  return reject("Fila " + queue +" já aberta nesta conexão para " + ((input) ?  "leitura" : "escrita"));

            var hQueueHandle = ref.alloc(libmqx.VOID_P_P);
            var queueb = Buffer.alloc(libmqx.MQ_Q_NAME_LENGTH);
            queueb.write(queue);

            try
            {
                var q =  new MQXQueue(me.connHandle, queueb, input, convert, convertMsgId, convertCorrelId, maxMsgLen, hQueueHandle);
                if(input)  { me.queuesIN.set(queue, q); }  else{ me.queuesOUT.set(queue, q); }
                return resolve(q);
            }
            catch(e) {
                if(e.reason == 2009 ) { me.good = false; }
                reject(e);
            }
        }).bind(this);
        p.disposer(function(queue, promise){queue.close();});
        return p;
    }

    begin()
    {
        // Begin não faz nada de IO, então não há porque criar uma promise, mas para manter o padrão idiomático.
        var ret = libmqx.MQX_begin_ex(this.connHandle);
        if(ret) { return BPromise.reject(new MQException(ret)); }
        else { return BPromise.resolve(this); }
    }

    commit()
    {
        var me = this;
        return new BPromise( function commit(resolve, reject) {
            var ret = libmqx.MQX_commit(me.connHandle);
            if(ret) { 
                if(ret == 2009 ) { me.good = false; }
                reject(new MQException(ret)); 
            }
            else { resolve(me); }
        }).bind(this);
    }

    back()
    {
        var me = this;
        return new BPromise( function commit(resolve, reject) {
            var ret = libmqx.MQX_back(me.connHandle);
            if(ret) { 
                if(ret == 2009 ) { me.good = false; }
                reject(new MQException(ret)); 
            }
            else { resolve(me); }
        }).bind(this);
    }
    

    depth(queue)
    {
        var me = this;
        return new BPromise( function commit(resolve, reject) {
            var quant = ref.alloc(ref.types.int64);
            var queueb = Buffer.alloc(libmqx.MQ_Q_NAME_LENGTH);
            queueb.write(queue, 0 , queue.length);
            var ret = libmqx.MQX_depth(me.connHandle, queueb, quant.ref());
            if(ret) { 
                if(ret == 2009 ) { me.good = false; }
                reject(new MQException(ret)); 
            }

            var i = 0;
            for(i=0; i < quant.length; i++)
            {
                console.log(quant.readUInt8(i));
            }
            resolve(me);
        }).bind(this);
    }

    close()
    {
        var me = this;
        return new BPromise(function closePromise(resolve, reject)
        {
            var ret = 0;
            if(me.open)
            {
                me.open=false; /* Thou shall leak, but never blow! */
                me.closeQueues().then(
                    function()
                    { /* nothing to be done */ }
                ).catch(
                    function (e)
                    {
                        return reject(e);
                    }
                ).finally(
                    function()
                    {
                        var ret = libmqx.MQX_release(me.connHandle);
                        if(ret) { 
                            if(ret == 2009 ) { me.good = false; }
                            return reject(new MQException(ret)); 
                        }
                        else resolve();
                    }
                );
            }
        }).bind(this);
    }

    closeQueues()
    {
        var me = this;
        return new BPromise(function closePromise(resolve, reject)
        {
            var ret = 0;
            var first = null;

            if(me.open)
            {
                me.queuesIN.forEach(function callback (value, index, array)
                {
                    try{value.close(); } catch(e) { first = first == null ? e : first; }
                });
                me.queuesIN.clear();
                me.queuesOUT.forEach(function callback (value, index, array)
                {
                    try{value.close(); } catch(e) { first = first == null ? e : first; }
                });
                me.queuesOUT.clear();
                if(first) return reject(first);
                return resolve();
            }
            else{
                reject(MQRC.MQX_CONNECTION_ALREADY_CLOSED);
            }
        });
    }
}

/* Promise.promisifyAll(MQXConnection.prototype); */
module.exports=MQXConnection;