'use strict';
function dateformat(d) {
    var strDt;
    if (d.toLocaleFormat !== 'undefined') {
        strDt = d.toLocaleFormat('%Y%m%d%H%M%S00');
    } else {
        strDt = '' + d.getFullYear();
        strDt += (d.getMonth() > 8) ? '' : '0';
        strDt += (d.getMonth() + 1);
        strDt += d.getDate() > 9 ? '' : '0';
        strDt += (d.getDate());
        strDt += d.getHours() > 9 ? '' : '0';
        strDt += (d.getHours());
        strDt += d.getMinutes() > 9 ? '' : '0';
        strDt += (d.getMinutes());
        strDt += d.getSeconds() > 9 ? '' : '0';
        strDt += (d.getSeconds());
        strDt += '00';
    }
    return strDt;
}

module.exports = dateformat;