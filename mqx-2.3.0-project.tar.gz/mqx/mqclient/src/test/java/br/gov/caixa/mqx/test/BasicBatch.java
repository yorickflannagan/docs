package br.gov.caixa.mqx.test;

//import java.io.ByteArrayInputStream;
import java.io.IOException;
//import java.sql.Connection;
import java.sql.SQLException;
//import java.sql.Statement;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NameNotFoundException;
import javax.naming.NamingException;
//import javax.sql.DataSource;

import org.crypthing.things.appservice.MQXFactory;
import org.crypthing.things.appservice.Sandbox;
import org.crypthing.things.config.ConfigException;
import org.crypthing.things.snmp.ProcessingEvent;
import org.crypthing.things.snmp.ProcessingEvent.ProcessingEventType;
import org.crypthing.things.messaging.MQXConnection;
import org.crypthing.things.messaging.MQXMessage;
import org.crypthing.things.messaging.MQXQueue;

public final class BasicBatch extends Sandbox
{
//	private DataSource db;
	private MQXFactory mq;
	private int maxCommit;

	@Override
	public void startup(final Properties props)throws ConfigException
	{
		if (props == null || props.getProperty("max-commit") == null) throw new ConfigException("BasicBatch requires configuration to run");
		try
		{
			maxCommit = Integer.parseInt(props.getProperty("max-commit"));
			final InitialContext ctx = new InitialContext();
			try
			{
				Object o = ctx.lookup("java:jdbc/oracns");
//				if (o instanceof DataSource) db = (DataSource) o;
//				else throw new ConfigException("JNDI name java:jdbc/oracns is not bound to a DataSource");
				o = ctx.lookup("java:mqx/mqdes");
				if (o instanceof MQXFactory) mq = (MQXFactory) o;
				else throw new ConfigException("JNDI name java:mqx/mqdes is not bound to a MQXFactory");
			}
			finally
			{
				ctx.close();
			}
		}
		catch (final NumberFormatException e)
		{
			throw new ConfigException("Invalid sandbox configuration");
		}
		catch (final NameNotFoundException e)
		{
			throw new ConfigException("JNDI name of required resource not bounded", e);
		}
		catch (final NamingException e)
		{
			throw new ConfigException(e);
		}
	}

	@Override public boolean execute() throws IOException, SQLException
	{
		final MQXConnection mqConn = mq.getConnection();
		final MQXQueue get = mqConn.openQueue("getqueue");
		final MQXQueue put = mqConn.openQueue("putqueue");
		int counter;
		try
		{
			MQXMessage inMsg; 
			do
			{
				mqConn.begin();
				counter = 0;
				try
				{
					do
					{
						inMsg = get.receive(null);
						if (inMsg.getMessage() != null)
						{
							// Faz alguma coisa com a mensagem e
							final MQXMessage newMsg = new MQXMessage();  // cria uma nova, se for o caso
							// ...
							final MQXMessage outMsg = put.send(newMsg);  // Envia a mensagem para o destinatário
							// Faz alguma coisa com a resposta do método
							// ...
							success();
						}
					}
					while (isRunning() && inMsg.getMessage() != null && ++counter < maxCommit);
					mqConn.commit();
				}
				catch (final IOException e)
				{
					fire(new ProcessingEvent(ProcessingEventType.error, "Mensagem personalizada de erro", e));
					mqConn.back();
					failure();
					throw e;
				}
			}
			while (isRunning() && inMsg.getMessage() != null);
		}
		finally
		{
			if (put != null) put.close();
			if (get != null) get.close();
			mqConn.close();
		}
		return true;
	}
}
