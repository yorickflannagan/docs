package br.gov.caixa.mqx.test;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.soap.SOAPException;

import org.crypthing.things.appservice.MQXFactory;
import org.crypthing.things.appservice.Sandbox;
import org.crypthing.things.config.ConfigException;
import org.crypthing.things.messaging.MQXConnection;
import org.crypthing.things.messaging.MQXQueue;

import br.gov.caixa.soap.SOAPElement;
import br.gov.caixa.ws.client.WebClient;

public class WSClient extends Sandbox
{
	private MQXFactory mq;
	private WebClient wsClient;

	@Override
	public void startup(final Properties props) throws ConfigException
	{
		try
		{
			final InitialContext ctx = new InitialContext();
			try
			{
				Object o = ctx.lookup("java:mqx/mqdes");
				if (o instanceof MQXFactory) mq = (MQXFactory) o;
				else throw new ConfigException("JNDI name java:mqx/mqdes is not bound to a MQXFactory");
				o = ctx.lookup("java:ws/EnviarLoteEventos");
				if (o instanceof WebClient) wsClient = (WebClient) o;
				else throw new ConfigException("JNDI name java:ws/EnviarLoteEventos is not bound to a WebClient");
			}
			finally
			{
				ctx.close();
			}
		}
		catch (final NamingException e) { throw new ConfigException(e); }
	}

	@Override
	protected boolean execute() throws IOException, SQLException
	{
		final MQXConnection mqConn = mq.getConnection();
		final MQXQueue queue = mqConn.openQueue("getqueue");
		try
		{
			byte[] xml;
			do
			{
				xml = queue.receive(null).getMessage();
				if (xml != null)
				{
					try
					{
						final SOAPElement result = wsClient.send(new String(xml, StandardCharsets.UTF_8)).get("EnviarLoteEventosResult");
						System.out.println(result.getData());
					}
					catch (final SOAPException | IOException e)
					{
						e.printStackTrace();
					}
				}
			}
			while (isRunning() && xml != null);
		}
		finally
		{
			if (queue != null) queue.close();
			mqConn.close();
		}
		return true;
	}

}
