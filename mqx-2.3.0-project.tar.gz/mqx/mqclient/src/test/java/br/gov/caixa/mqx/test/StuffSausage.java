package br.gov.caixa.mqx.test;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NameNotFoundException;
import javax.naming.NamingException;

import org.crypthing.things.appservice.MQXFactory;
import org.crypthing.things.appservice.Sandbox;
import org.crypthing.things.config.ConfigException;
import org.crypthing.things.messaging.MQXConnection;
import org.crypthing.things.messaging.MQXMessage;
import org.crypthing.things.messaging.MQXQueue;

public class StuffSausage extends Sandbox
{
	private MQXFactory mq;
	private int maxPut;

	@Override
	public void startup(final Properties props) throws ConfigException
	{
		if (props == null || props.getProperty("max-put") == null) throw new ConfigException("BasicBatch requires configuration to run");
		try
		{
			maxPut = Integer.parseInt(props.getProperty("max-put"));
			final InitialContext ctx = new InitialContext();
			try
			{
				Object o = ctx.lookup("java:mqx/mqdes");
				if (o instanceof MQXFactory) mq = (MQXFactory) o;
				else throw new ConfigException("JNDI name java:mqx/mqdes is not bound to a MQXFactory");
			}
			finally { ctx.close(); }
		}
		catch (final NumberFormatException e)
		{
			throw new ConfigException("Invalid sandbox configuration");
		}
		catch (final NameNotFoundException e)
		{
			throw new ConfigException("JNDI name of required resource not bounded", e);
		}
		catch (final NamingException e)
		{
			throw new ConfigException(e);
		}
	}
	@Override
	protected boolean execute() throws IOException, SQLException
	{
		final MQXConnection mqConn = mq.getConnection();
		final MQXQueue put = mqConn.openQueue("putgetqueue");
		int i = 0;
		try
		{
			do
			{
				put.send(new MQXMessage(LOTE));
				success();
			}
			while (isRunning() && ++i < maxPut);
		}
		finally
		{
			if (put != null) put.close();
			if (mqConn != null) mqConn.close();
		}
		return true;
	}

	private static final byte[] LOTE =
		("<eSocial xmlns=\"http://www.esocial.gov.br/schema/empregador/lote/eventos/envio/v1_0_0\">" +
		"<envioLoteEventos grupo=\"1234\">" +
		"<ideEmpregador>" +
		"<tpInscricao>123</tpInscricao>" +
		"<nrInscricao>str1234</nrInscricao>" +
		"</ideEmpregador>" +
		"<ideTransmissor>" +
		"<tpInscricao>123</tpInscricao>" +
		"<nrInscricao>str1234</nrInscricao>" +
		"</ideTransmissor>" +
		"<eventos>" +
		"<evento id=\"ABCD\" >" +
		"<eSocial xmlns=\"http://www.esocial.gov.br/schema/evt/evtRemun/v02_00_00\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\">" +
		"<evtRemun Id=\"A123456789012345678901234\" versao=\"str1234\">" +
		"<ideEvento>" +
		"<indRetif>1</indRetif>" +
		"<nrRecibo>str123400000000000000000</nrRecibo>" +
		"<indApuracao>1</indApuracao>" +
		"<perApur>str1234</perApur>" +
		"<tpAmb>1</tpAmb>" +
		"<procEmi>1</procEmi>" +
		"<verProc>str1234</verProc>" +
		"</ideEvento>" +
		"<ideEmpregador>" +
		"<tpInsc>1</tpInsc>" +
		"<nrInsc>str1234</nrInsc>" +
		"</ideEmpregador>" +
		"<ideTrabalhador>" +
		"<cpfTrab>12345678901</cpfTrab>" +
		"<nisTrab>str12340000</nisTrab>" +
		"<qtdDepSF>33</qtdDepSF>" +
		"<qtdDepIRRF>33</qtdDepIRRF>" +
		"<infoMV>" +
		"<indMV>1</indMV>" +
		"<remunOutrEmpr>" +
		"<tpInsc>1</tpInsc>" +
		"<nrInsc>str1234</nrInsc>" +
		"<vlrRemunOE>123.45</vlrRemunOE>" +
		"</remunOutrEmpr>" +
		"</infoMV>" +
		"<infoComplem>" +
		"<nmTrab>str1234</nmTrab>" +
		"<dtNascto>2012-12-13</dtNascto>" +
		"<codCBO>str123</codCBO>" +
		"<natAtividade>1</natAtividade>" +
		"<qtdDiasTrab>1</qtdDiasTrab>" +
		"</infoComplem>" +
		"<procJudTrab>" +
		"<tpTrib>1</tpTrib>" +
		"<nrProcJud>str1234</nrProcJud>" +
		"</procJudTrab>" +
		"</ideTrabalhador>" +
		"<infoPerApur>" +
		"<recPgtos>" +
		"<ideRecPgto>745</ideRecPgto>" +
		"<ideEstabLot>" +
		"<tpInsc>1</tpInsc>" +
		"<nrInsc>str1234</nrInsc>" +
		"<codLotacao>str1234</codLotacao>" +
		"<remunPerApur>" +
		"<matricula>str1234</matricula>" +
		"<codCateg>1234</codCateg>" +
		"<vlrLiq>123.45</vlrLiq>" +
		"<indResBr>S</indResBr>" +
		"<dtPagto>2012-12-13</dtPagto>" +
		"<indSimples>1</indSimples>" +
		"<itensRemun>" +
		"<codRubr>str1234</codRubr>" +
		"<ideTabRubr>str1234</ideTabRubr>" +
		"<qtdRubr>123.45</qtdRubr>" +
		"<vrUnit>123.45</vrUnit>" +
		"<vrRubr>123.45</vrRubr>" +
		"</itensRemun>" +
		"<infoSaudeColet>" +
		"<detOper>" +
		"<cnpjOper>12345678901234</cnpjOper>" +
		"<regANS>str123</regANS>" +
		"<vrPgTit>123.45</vrPgTit>" +
		"<detPlano>" +
		"<cpfDep>12345678901</cpfDep>" +
		"<dtNasctoDep>2012-12-13</dtNasctoDep>" +
		"<nmDep>str1234</nmDep>" +
		"<relDep>1</relDep>" +
		"<vlrPgDep>123.45</vlrPgDep>" +
		"</detPlano>" +
		"</detOper>" +
		"</infoSaudeColet>" +
		"<infoAgNocivo>" +
		"<grauExp>1</grauExp>" +
		"</infoAgNocivo>" +
		"<pensaoAlim>" +
		"<cpfBenef>12345678901</cpfBenef>" +
		"<dtNasctoBenef>2012-12-13</dtNasctoBenef>" +
		"<nmBenefic>str1234</nmBenefic>" +
		"<vlrPensao>123.45</vlrPensao>" +
		"</pensaoAlim>" +
		"<pgtoExt>" +
		"<idePais>" +
		"<codPais>str</codPais>" +
		"<indNIF>1</indNIF>" +
		"<nifBenef>str1234</nifBenef>" +
		"</idePais>" +
		"<endExt>" +
		"<dscLograd>str1234</dscLograd>" +
		"<nrLograd>str1234</nrLograd>" +
		"<complem>str1234</complem>" +
		"<bairro>str1234</bairro>" +
		"<nmCid>str1234</nmCid>" +
		"<codPostal>str1234</codPostal>" +
		"</endExt>" +
		"</pgtoExt>" +
		"</remunPerApur>" +
		"</ideEstabLot>" +
		"</recPgtos>" +
		"</infoPerApur>" +
		"<infoPerAnt>" +
		"<ideADC>" +
		"<dtAcConv>2012-12-13</dtAcConv>" +
		"<tpAcConv>s</tpAcConv>" +
		"<recPgtos>" +
		"<ideRecPgto>745</ideRecPgto>" +
		"<idePeriodo>" +
		"<perRef>str1234</perRef>" +
		"<ideEstabLot>" +
		"<tpInsc>1</tpInsc>" +
		"<nrInsc>str1234</nrInsc>" +
		"<codLotacao>str1234</codLotacao>" +
		"<remunPerAnt>" +
		"<matricula>str1234</matricula>" +
		"<codCateg>1234</codCateg>" +
		"<vlrLiq>123.45</vlrLiq>" +
		"<indResBr>S</indResBr>" +
		"<dtPagto>2012-12-13</dtPagto>" +
		"<indSimples>1</indSimples>" +
		"<itensRemun>" +
		"<codRubr>str1234</codRubr>" +
		"<ideTabRubr>str1234</ideTabRubr>" +
		"<qtdRubr>123.45</qtdRubr>" +
		"<vrUnit>123.45</vrUnit>" +
		"<vrRubr>123.45</vrRubr>" +
		"</itensRemun>" +
		"<infoAgNocivo>" +
		"<grauExp>1</grauExp>" +
		"</infoAgNocivo>" +
		"<pensaoAlim>" +
		"<cpfBenef>12345678901</cpfBenef>" +
		"<dtNasctoBenef>2012-12-13</dtNasctoBenef>" +
		"<nmBenefic>str1234</nmBenefic>" +
		"<vlrPensao>123.45</vlrPensao>" +
		"</pensaoAlim>" +
		"<pgtoExt>" +
		"<idePais>" +
		"<codPais>str</codPais>" +
		"<indNIF>1</indNIF>" +
		"<nifBenef>str1234</nifBenef>" +
		"</idePais>" +
		"<endExt>" +
		"<dscLograd>str1234</dscLograd>" +
		"<nrLograd>str1234</nrLograd>" +
		"<complem>str1234</complem>" +
		"<bairro>str1234</bairro>" +
		"<nmCid>str1234</nmCid>" +
		"<codPostal>str1234</codPostal>" +
		"</endExt>" +
		"</pgtoExt>" +
		"</remunPerAnt>" +
		"</ideEstabLot>" +
		"</idePeriodo>" +
		"</recPgtos>" +
		"</ideADC>" +
		"</infoPerAnt>" +
		"</evtRemun>" +
		"<ds:Signature>" +
		"<ds:SignedInfo>" +
		"<ds:CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\" />" +
		"<ds:SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\" />" +
		"<ds:Reference URI=\"http://www.w3.org\">" +
		"<ds:Transforms>" +
		"<ds:Transform Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\">" +
		"<ds:XPath>OBLADIOBLADA</ds:XPath>" +
		"</ds:Transform>" +
		"<ds:Transform Algorithm=\"http://www.w3.org/2000/09/xmldsig#enveloped-signature\">" +
		"<ds:XPath>OBLADIOBLADA</ds:XPath>" +
		"</ds:Transform>" +
		"</ds:Transforms>" +
		"<ds:DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\"></ds:DigestMethod>" +
		"<ds:DigestValue>0FB8</ds:DigestValue>" +
		"</ds:Reference>" +
		"</ds:SignedInfo>" +
		"<ds:SignatureValue>0FB8</ds:SignatureValue>" +
		"<ds:KeyInfo>" +
		"<ds:X509Data>" +
		"<ds:X509Certificate>0FB8</ds:X509Certificate>" +
		"</ds:X509Data>" +
		"</ds:KeyInfo>" +
		"</ds:Signature>" +
		"</eSocial>" +
		"</evento>" +
		"</eventos>" +
		"</envioLoteEventos>" +
		"</eSocial>").getBytes(StandardCharsets.UTF_8);
}
