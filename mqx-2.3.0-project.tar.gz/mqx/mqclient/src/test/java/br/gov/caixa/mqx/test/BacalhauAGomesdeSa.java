package br.gov.caixa.mqx.test;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;

import br.gov.caixa.soap.SOAPEnvelope;
import br.gov.caixa.soap.SOAPParser;

public class BacalhauAGomesdeSa {

	public static void bacalhauDoDiego() throws Exception
	{
		System.setProperty("javax.xml.stream.XMLInputFactory", "com.ctc.wstx.stax.WstxInputFactory");
		System.setProperty("javax.xml.stream.XMLOutputFactory", "com.ctc.wstx.stax.WstxOutputFactory");
		System.setProperty("javax.xml.stream.XMLEventFactory", "com.ctc.wstx.stax.WstxEventFactory");
//			org.codehaus.stax2.ri.evt.CharactersEventImpl a;

		final String ESCAPED =
			"<?xml version=\"1.0\" ?>" +
			"<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
			"<soap:Body>" +
			"<EnviarLoteEventos xmlns=\"http://www.esocial.gov.br/servicos/empregador/lote/eventos/envio/v1_0_0\">" +
			"<loteEventos>" +
			"abc&amp;cde" +
			"</loteEventos>" +
			"</EnviarLoteEventos>" +
			"</soap:Body>" +
			"</soap:Envelope>";

			System.out.println(System.getProperty("javax.xml.stream.XMLEventFactory"));
			SOAPEnvelope ret = SOAPParser.parseRequest(new ByteArrayInputStream(ESCAPED.getBytes(StandardCharsets.UTF_8)), 512);
			System.out.println(ret.toString());		

	}
	public static void main(String[] args) throws Exception
	{
		File target = new File(BacalhauAGomesdeSa.class.getProtectionDomain().getCodeSource().getLocation().getPath(), "libmqx.so");
		System.out.println(target.getAbsolutePath());
	}

}
