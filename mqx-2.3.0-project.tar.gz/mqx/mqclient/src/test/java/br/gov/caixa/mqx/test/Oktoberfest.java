package br.gov.caixa.mqx.test;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NameNotFoundException;
import javax.naming.NamingException;

import org.crypthing.things.appservice.MQXFactory;
import org.crypthing.things.appservice.Sandbox;
import org.crypthing.things.config.ConfigException;
import org.crypthing.things.messaging.MQXConnection;
import org.crypthing.things.messaging.MQXMessage;
import org.crypthing.things.messaging.MQXQueue;

public class Oktoberfest extends Sandbox
{
	private MQXFactory mq;

	@Override
	public void startup(final Properties props) throws ConfigException
	{
		try
		{
			final InitialContext ctx = new InitialContext();
			try
			{
				Object o = ctx.lookup("java:mqx/mqdes");
				if (o instanceof MQXFactory) mq = (MQXFactory) o;
				else throw new ConfigException("JNDI name java:mqx/mqdes is not bound to a MQXFactory");
			}
			finally { ctx.close(); }
		}
		catch (final NameNotFoundException e)
		{
			throw new ConfigException("JNDI name of required resource not bounded", e);
		}
		catch (final NamingException e)
		{
			throw new ConfigException(e);
		}
	}
	@Override
	protected boolean execute() throws IOException, SQLException
	{
		final MQXConnection mqConn = mq.getConnection();
		final MQXQueue get = mqConn.openQueue("getputqueue");
		try
		{
			MQXMessage inMsg;
			do
			{
				inMsg = get.receive(null);
				if (inMsg.getMessage() != null) success();
			}
			while (isRunning() && inMsg.getMessage() != null);
		}
		finally
		{
			if (get != null) get.close();
			if (mqConn != null) mqConn.close();
		}
		return true;
	}
}
