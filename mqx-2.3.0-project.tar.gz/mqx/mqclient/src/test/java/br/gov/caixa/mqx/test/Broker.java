package br.gov.caixa.mqx.test;

import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.crypthing.things.appservice.MQXFactory;
import org.crypthing.things.appservice.Sandbox;
import org.crypthing.things.config.ConfigException;
import org.crypthing.things.messaging.MQXConnection;
import org.crypthing.things.messaging.MQXConnectionException;
import org.crypthing.things.messaging.MQXMessage;

import br.gov.caixa.BufferedStringWriter;

public final class Broker extends Sandbox
{
	private MQXFactory mq;
	private byte[] request;
	MQXConnection hConn;
	@Override
	public void startup(final Properties props)throws ConfigException
	{
		if (props == null || props.getProperty("broker-request") == null) throw new ConfigException("BrokerTest requires proper configuration to run");
		try 
		{ 
			
			request = readFile(props.getProperty("broker-request")).getBytes(StandardCharsets.UTF_8);
		
		}
		catch (final IOException e) { throw new ConfigException("Could not load request file", e); }
		try
		{
			final InitialContext ctx = new InitialContext();
			final Object o = ctx.lookup("java:mqx/mqdes");
			if (o instanceof MQXFactory) mq = (MQXFactory) o;
			else throw new ConfigException("Invalid lookup for MQXFactory");
			hConn = mq.getConnection();
		}
		catch (MQXConnectionException | NamingException e) { throw new ConfigException("Could not find JNDI entry for MQXConnector", e); }
	}

	@Override
	protected boolean execute() throws IOException, SQLException
	{
		while(isRunning())
		{
			hConn.call("brokerRequest", "brokerResponse", new MQXMessage(request));
			success();
		}
		return true;
	}

	private String readFile(final String target) throws IOException
	{
		final FileReader in = new FileReader(target);
		try
		{
			final BufferedStringWriter out = new BufferedStringWriter();
			try
			{
				final char[] buffer = new char[512];
				int read;
				while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
				return out.toString();
			}
			finally { out.close(); }
		}
		finally { in.close(); }
	}
}
