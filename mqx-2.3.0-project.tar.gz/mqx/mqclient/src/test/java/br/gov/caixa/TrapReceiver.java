package br.gov.caixa;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
//import java.util.UUID;

import org.snmp4j.CommandResponder;
import org.snmp4j.CommandResponderEvent;
import org.snmp4j.MessageDispatcher;
import org.snmp4j.MessageDispatcherImpl;
import org.snmp4j.PDU;
import org.snmp4j.Snmp;
import org.snmp4j.TransportMapping;
import org.snmp4j.mp.MPv2c;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.GenericAddress;
import org.snmp4j.smi.UdpAddress;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.MultiThreadedMessageDispatcher;
import org.snmp4j.util.ThreadPool;

public class TrapReceiver
{
	public static void main(String[] args)
	{
		TrapReceiver tr = new TrapReceiver();
		try
		{
			tr.receive(args[0]);
		}
		catch (Throwable e)
		{
			e.printStackTrace();
		}
	}
	
	public void receive(final String arg) throws Throwable
	{
		final String ip = arg != null ? arg : "127.0.0.1/8163";
		ThreadPool threadPool = ThreadPool.create("DispatcherPool", 10);
		MessageDispatcher mtDispatcher = new MultiThreadedMessageDispatcher(threadPool, new MessageDispatcherImpl());
		mtDispatcher.addMessageProcessingModel(new MPv2c());
		Address targetAddress = GenericAddress.parse("udp:" + ip);
		TransportMapping<?> transport = new DefaultUdpTransportMapping((UdpAddress)targetAddress);
		Snmp snmp = new Snmp(mtDispatcher, transport);
		CommandResponder trapPrinter = new CommandResponder()
		{
			public synchronized void processPdu(CommandResponderEvent e)
			{
				PDU command = e.getPDU();
				if (command != null)
				{
//					saveToFile(command, "/home/magut/" + UUID.randomUUID().toString());
					System.out.println(command.toString());
				}
				else System.out.println("nullp");
			}
		};
		snmp.addCommandResponder(trapPrinter);
		transport.listen();
		snmp.listen();
		System.out.println("Listening on " + targetAddress);
	}

	void saveToFile(final PDU trap, final String fileName)
	{
		final ByteArrayOutputStream out = new ByteArrayOutputStream(512);
		try
		{
			trap.encodeBER(out);
			final OutputStream file = new FileOutputStream(fileName);
			try { file.write(out.toByteArray()); }
			finally { file.close(); }
		}
		catch (final IOException e) { e.printStackTrace(); }
	}
}
