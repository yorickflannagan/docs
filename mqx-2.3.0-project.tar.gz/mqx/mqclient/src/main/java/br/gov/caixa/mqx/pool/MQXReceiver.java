package br.gov.caixa.mqx.pool;

import org.crypthing.things.appservice.config.ConnectorConfig;
import org.crypthing.things.appservice.config.QueueConfig;
import org.crypthing.things.snmp.EncodableString;
import org.crypthing.things.snmp.ErrorBean;
import org.crypthing.things.snmp.LifecycleEvent;
import org.crypthing.things.snmp.LogTrapperListener;
import org.crypthing.things.snmp.ProcessingEvent;
import org.crypthing.things.snmp.LifecycleEvent.LifecycleEventType;
import org.crypthing.things.snmp.ProcessingEvent.ProcessingEventType;
import org.crypthing.things.messaging.MQXConnection;
import org.crypthing.things.messaging.MQXConnectionException;
import org.crypthing.things.messaging.MQXException;
import org.crypthing.things.messaging.MQXIllegalArgumentException;
import org.crypthing.things.messaging.MQXIllegalStateException;
import org.crypthing.things.messaging.MQXMessage;
import org.crypthing.things.messaging.MQXQueue;

import br.gov.caixa.mqx.MQXConnectionBrokenException;

final class MQXReceiver implements Runnable, Controllable
{
	private final ConnectorConfig config;
	private final QueueConfig queueCfg;
	private final int timeout;
	private boolean running = true;
	private int okCounter, failCounter;
	private final Object lock = new Object();
	private MQXMessageContainer message = null;
	private final LogTrapperListener trapper;

	MQXReceiver(final ConnectorConfig config, final String qName, final LogTrapperListener trapper) throws MQXException
	{
		this.trapper = trapper;
		this.config = config;
		queueCfg = config.get(qName);
		if (queueCfg == null) throw new MQXException("Queue name not found");
		if (!Boolean.parseBoolean(queueCfg.getProperty("br.gov.caixa.mqx.input"))) throw new MQXException("Configuration must refers to an input queue");
		try { timeout = Integer.parseInt(queueCfg.getProperty("br.gov.caixa.mqx.get.timeout", "4000")); }
		catch (final NumberFormatException e) { throw new MQXException("Invalid br.gov.caixa.mqx.get.timeout configuration entry", e); }
	}

	@Override
	public void run()
	{
		MQXMessageContainer local;
		MQXConnection mqConn = null;
		MQXQueue mqQueue = null;
		boolean restart = true;
		trapper.start(new LifecycleEvent(LifecycleEventType.start, new EncodableString("MQXReceiver thread " + Thread.currentThread().getId() + " started")));
		while (running)
		{
			if (restart)
			{
				try
				{
					if (mqConn != null)
					{
						try { mqConn.close(); }
						catch (final Throwable e) {}
					}
					mqConn = (MQXConnection) Class.forName(config.getDriver()).newInstance();
					mqConn.initConnection(config.getContext());
					mqQueue = mqConn.openQueue(queueCfg);
					restart = false;
					trapper.work(new LifecycleEvent(LifecycleEventType.work, new EncodableString("MQXReceiver has created a new connection to MQSeries")));
				}
				catch (final InstantiationException | IllegalAccessException | ClassNotFoundException | MQXException e)
				{
					trapper.error(new ProcessingEvent(ProcessingEventType.error, "Could not create MQXConnection", e));
					break;
				}
			}
			try
			{
				synchronized (lock)
				{
					while (message == null && running)
					{
						try { lock.wait(); }
						catch (final InterruptedException e) {}
					}
					if (!running)
					{
						if (message != null) message.notifyAll();
						break;
					}
					local = message;
					message = null;
				}
				synchronized (local)
				{
					try
					{
						final MQXMessage out = mqQueue.receive(local.in, timeout);
						okCounter++;
						local.out = out;
					}
					catch (final MQXIllegalStateException | MQXIllegalArgumentException | MQXConnectionException ex)
					{
						if (ex instanceof MQXConnectionBrokenException) restart = true; 
						failCounter++;
						local.exception = ex;
					}
					finally { local.notifyAll(); }
				}
			}
			catch (final Throwable e)
			{
				trapper.error(new ProcessingEvent(ProcessingEventType.error, (new ErrorBean("MQX", "An unexpected error has been received", e)).encode()));
				running = false;
			}
		}
		trapper.stop(new LifecycleEvent(LifecycleEventType.stop, new EncodableString("MQXReceiver has stopped its thread " + Thread.currentThread().getId())));
		try { mqQueue.close(); mqConn.close(); }
		catch (final MQXIllegalStateException | MQXConnectionException e) { trapper.error(new ProcessingEvent(ProcessingEventType.error, "Could not close MQXConnection", e)); }
	}
	void get(final MQXMessageContainer container)
	{
		if (container == null) throw new NullPointerException("Argument must not be null");
		synchronized (lock)
		{
			if (message == null) message = container;
			else throw new IllegalMonitorStateException();
			lock.notifyAll();
		}
	}
	@Override public boolean isRunning() { return running; }
	@Override public void stop() { running = false; }
	@Override public int getOkCounter() { return okCounter; }
	@Override public int getFailCounter() { return failCounter; }
}
