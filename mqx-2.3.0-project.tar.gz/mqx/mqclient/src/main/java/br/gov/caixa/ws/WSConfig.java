package br.gov.caixa.ws;

import java.io.Serializable;

import org.crypthing.things.config.Config;
import org.crypthing.things.config.ConfigException;
import org.crypthing.things.config.ConvertToFloat;
import org.crypthing.things.config.ConvertToInt;
import org.w3c.dom.Node;
import org.crypthing.things.appservice.config.ConfigProperties;

public final class WSConfig implements Serializable
{
	private static final long serialVersionUID = -4192670964667748176L;
	private int xmlSize;
	private float failureIndicator;
	private ConfigProperties snmp;
	public WSConfig(final Config xml) throws ConfigException
	{
		final Node n = xml.getNodeValue("config");
		xmlSize = xml.getValue("./xml-size", n, new ConvertToInt(-1));
		failureIndicator = xml.getValue("./xml-size", n, new ConvertToFloat(-1));
		snmp = new ConfigProperties(xml, xml.getNodeValue("/config/snmp"));
	}

	public int getXmlSize() { return xmlSize; }
	public void setXmlSize(int xmlSize) { this.xmlSize = xmlSize; }
	public float getFailureIndicator() { return failureIndicator; }
	public void setFailureIndicator(float failureIndicator) { this.failureIndicator = failureIndicator; }
	public ConfigProperties getSnmp() { return snmp; }
	public void setSnmp(ConfigProperties snmp) { this.snmp = snmp; }
	@Override
	public String toString()
	{
		final StringBuilder builder = new StringBuilder();
		builder.append("xml-size=")
			.append(xmlSize)
			.append("\n")
			.append("failure-indicator=")
			.append(failureIndicator)
			.append("\n");
		if (snmp != null) builder.append("snmp={").append(snmp.toString()).append("}\n");
		return builder.toString();
	}
}
