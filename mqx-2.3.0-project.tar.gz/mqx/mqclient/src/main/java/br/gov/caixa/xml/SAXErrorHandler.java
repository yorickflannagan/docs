package br.gov.caixa.xml;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class SAXErrorHandler implements ErrorHandler
{
	@Override public void warning(final SAXParseException e) throws SAXException {}
	@Override public void error(final SAXParseException e) throws SAXException { throw new SAXException(e.getMessage() + " (col=" + e.getColumnNumber() + ", line=" + e.getLineNumber() + ")", e); }
	@Override public void fatalError(SAXParseException e) throws SAXException { throw new SAXException(e.getMessage() + " (col=" + e.getColumnNumber() + ", line=" + e.getLineNumber() + ")", e); }
}
