package br.gov.caixa.soap;

import java.io.IOException;
import java.io.Serializable;
import java.io.Writer;

public  class SOAPElement implements Cloneable, Serializable
{
	private static final long serialVersionUID = 1872559320885635795L;
	public static enum XSDType
	{
		xsString,
		xsDecimal,
		xsInteger,
		xsBoolean,
		xsBinary;
	}

	protected String name;
	protected String data;
	protected XSDType dataType;
	protected boolean optional;

	public SOAPElement() { this(null); }
	public SOAPElement(final String name) { this(name, null); }
	public SOAPElement(final String name, final String data) { this(name, data, XSDType.xsString); }
	public SOAPElement(final String name, final String data, final XSDType dataType) { this(name, data, dataType, false); }
	public SOAPElement(final String name, final String data, final XSDType dataType, final boolean optional)
	{
		this.name = name;
		this.data = data;
		this.dataType = dataType;
		this.optional = optional;
	}

	public String getName() { return name; }
	public void setName(final String name) { this.name = name; } 
	public String getData() { return data; }
	public void setData(final String data) { this.data = data; }
	public XSDType getDataType() { return dataType; }
	public void setDataType(final XSDType dataType) { this.dataType = dataType; }
	public boolean isOptional() { return optional; }
	public void setOptional(final boolean optional) { this.optional = optional; }
	@Override public SOAPElement clone() { return new SOAPElement(name, data, dataType, optional); }
	@Override
	public String toString()
	{
		final StringBuilder builder = new StringBuilder(512);
		builder.append("SOAPElement=\n{\n");
		builder.append("dataType=").append(dataType).append("\n");
		if (name != null) builder.append("name=").append(name).append("\n");
		if (data != null) builder.append("data=").append(data).append("\n");
		builder.append("optional=").append(optional).append("\n");
		return builder.append("}").toString();
	}

	protected static final String START_ELEMENT = "<";
	protected static final String END_ELEMENT = ">";
	public void writeTo(final Writer writer) throws IOException
	{
		// TODO: if (dataType == XSDType.xsBinary)
		if (data != null && name != null)
		{
			writer.write(START_ELEMENT);
			writer.write(name);
			writer.write(END_ELEMENT);
			writer.write(data);
			writer.write(START_ELEMENT);
			writer.write('/');
			writer.write(name);
			writer.write(END_ELEMENT);
		}
	}
	public int size()
	{
		int size = 0;
		if (data != null && name != null)
		{
			size += (START_ELEMENT).length();
			size += (name).length();
			size += (END_ELEMENT).length();
			size += (data).length();
			size += (START_ELEMENT).length();
			size += 1;
			size += (name).length();
			size += (END_ELEMENT).length();
		}
		return size;
	}
}
