package br.gov.caixa.mqx.pool;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.Name;
import javax.naming.spi.ObjectFactory;

public class PoolFactory implements ObjectFactory
{
	private static final String CONTEXT = "java:global/MQXConnectors/";
	private static final int CONTEXT_LEN = CONTEXT.length();
	@Override
	public Object getObjectInstance(final Object obj, final Name name, final Context nameCtx, final Hashtable<?, ?> environment) throws Exception
	{
		if (obj instanceof String)
		{
			final String lookup = (String) obj;
			if (lookup.startsWith(CONTEXT)) return PooledMQXConnection.getInstance(lookup.substring(CONTEXT_LEN));
		}
		return null;
	}

}
