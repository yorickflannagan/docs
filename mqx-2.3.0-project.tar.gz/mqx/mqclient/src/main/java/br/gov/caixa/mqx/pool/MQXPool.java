package br.gov.caixa.mqx.pool;

import java.util.Iterator;

public final class MQXPool extends LenientLimitedDeque<MQXReceiver> implements Controllable
{
	private static final long serialVersionUID = -4532771053797241441L;

	private boolean mustStop = false;
	public MQXPool(final int maxWaterlevel) { super(maxWaterlevel); }
	@Override public boolean isRunning() { return (waterlevel > 0); }
	@Override
	public void stop()
	{
		mustStop = true;
		MQXReceiver item;
		while ((item = poll()) != null)
		{
			item.stop();
			decrementWaterLevel();
		}
	}

	@Override
	public int getOkCounter()
	{
		int counter = 0;
		final Iterator<MQXReceiver> items = iterator();
		while (items.hasNext()) counter += items.next().getOkCounter();
		return counter;
	}
	@Override
	public int getFailCounter()
	{
		int counter = 0;
		final Iterator<MQXReceiver> items = iterator();
		while (items.hasNext()) counter += items.next().getFailCounter();
		return counter;
	}
	@Override
	public MQXReceiver borrow(final long timeout)
	{
		if (mustStop) return null;
		return super.borrow(timeout);
	}
	@Override
	public void giveBack(final MQXReceiver e)
	{
		if (mustStop || !super.giveBackWithoutOverflow(e)) e.stop(); else decrementWaterLevel();
	}
}
