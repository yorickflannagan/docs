package br.gov.caixa.db;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.concurrent.locks.ReentrantLock;

public abstract class DBReader implements Serializable
{
	private static final long serialVersionUID = -7007919385542574761L;

	protected final Connection conn;
	protected PreparedStatement stm;
	protected final String sql;
	private ReentrantLock mutex;
	private long lastRecord = 0;
	private boolean segmented = false;
	
	
	protected DBReader(final Connection conn, final String loadSQL) throws SQLException
	{
		if (conn == null || loadSQL == null) throw new NullPointerException("Arguments must not be null");
		this.conn = conn;
		sql = loadSQL;
		stm = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
		//TODO: a forma bonita não é garantida por causa de falta de permissão.
		try{ stm.setLong(1, lastRecord); segmented = true;}catch(SQLException e){}
	}

	public ResultSet readCursor() throws SQLException
	{
		final ReentrantLock _mutex = mutex;
		if(_mutex != null) _mutex.lock();
		try
		{
			if (stm == null) stm = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
			if(segmented) { stm.setLong(1, lastRecord);}
			ResultSet retorno = stm.executeQuery();
			return retorno;
		}
		finally
		{
			if(_mutex != null) _mutex.unlock();
		}
	}

	public DBRow readRow(final ResultSet cursor) throws SQLException
	{
		final ReentrantLock _mutex = mutex;
		if(_mutex != null) _mutex.lock();
		try
		{
			final DBRow row = new DBRow(this);
			final ResultSetMetaData metaData = cursor.getMetaData();
			final int colunas = metaData.getColumnCount();
			if(segmented && colunas > 0){ lastRecord = cursor.getLong(1);}
			for (int i = 1; i <= colunas; i++)
			{
				final String col = metaData.getColumnName(i);
				final String data = cursor.getString(col);
				row.setProperty(col, data == null ? "" : data );
			}
			return row;
		}
		finally
		{
			if(_mutex != null) _mutex.unlock();
		}
	}

	public void release()
	{
		final ReentrantLock _mutex = mutex;
		if(_mutex != null) _mutex.lock();
		try
		{
			if(stm == null ) return;
			try { stm.close(); }
			catch (SQLException e) {}
			stm = null;
		}
		finally
		{
			if(_mutex != null) _mutex.unlock();
		}
	}

	public void setMutex(final ReentrantLock mutex)
	{
		this.mutex = mutex;
	}
	
	public abstract void setDone(DBRow row, DBReaderArgument args) throws SQLException;
}
