package br.gov.caixa.ws.server;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

import javax.management.ObjectName;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.soap.SOAPException;
import javax.xml.stream.XMLStreamException;

import org.crypthing.things.config.Config;
import org.crypthing.things.snmp.ErrorBean;
import org.crypthing.things.snmp.LogTrapperListener;
import org.crypthing.things.snmp.ProcessingEvent;
import org.crypthing.things.snmp.SNMPBridge;
import org.crypthing.things.snmp.ProcessingEvent.ProcessingEventType;

import br.gov.caixa.soap.SOAPEnvelope;
import br.gov.caixa.soap.SOAPParser;
import br.gov.caixa.ws.WSConfig;
import br.gov.caixa.ws.WSConfigException;
import br.gov.caixa.ws.WSMethods;
import br.gov.caixa.ws.WSSignature;

public final class WebService extends HttpServlet implements WebServiceMBean
{
	private static final long serialVersionUID = 1489692453457416854L;
	private int _xmlSize;
	private float _failIdx;
	private long _okCount = 0;
	private long _failCount = 0;
	private boolean _initError;
	private LogTrapperListener _trap;
	private Map<String, ServiceHandler> _services;
	private ObjectName _mbName;
	private WSConfig cfg;
	@Override
	public void init(final ServletConfig config) throws ServletException
	{
		super.init(config);
		try
		{
			final String cFilePath = config.getInitParameter("config-file");
			if (cFilePath == null) throw new ServletException("config-file parameter entry must exist in web.xml");
			cfg = new WSConfig(new Config(new FileInputStream(config.getInitParameter("config-file")), WebService.class.getResourceAsStream("config.xsd")));
			_xmlSize = cfg.getXmlSize();
			_failIdx = cfg.getFailureIndicator();
			SNMPBridge bridge = SNMPBridge.newInstance
			(
				cfg.getSnmp().getProperty("org.crypthing.things.SNMPTrap"),
				cfg.getSnmp().getProperty("org.crypthing.things.batch.udpAddress"),
				cfg.getSnmp().getProperty("org.crypthing.things.batch.rootOID")
			);

			_trap = new LogTrapperListener(Logger.getLogger(this.getClass().getName()), bridge);

			_services = new ConcurrentHashMap<String, ServiceHandler>();
			final Enumeration<String> entries = config.getInitParameterNames();
			while (entries.hasMoreElements())
			{
				final String entry = entries.nextElement();
				if (entry.startsWith("/"))
				{
					final WSMethods service = WSMethods.getServiceConfig(config.getInitParameter(entry));
					final ServiceHandler handler = (ServiceHandler) Thread.currentThread().getContextClassLoader().loadClass(service.getImplementation()).newInstance();
					handler.setService(service);
					handler.setWsdl(getWSDL(service.getWsdlLocation(), service.getWsdlUri()));
					handler.init(new LogTrapperListener(Logger.getLogger(handler.getClass().getName()), bridge), service.getProperties());
					_services.put(entry, handler);
				}
			}
			ManagementFactory.getPlatformMBeanServer().registerMBean
			(
				this,
				_mbName = new ObjectName
				(
					(new StringBuilder(256))
					.append("br.gov.caixa.ws.server:type=WebService,name=")
					.append(ManagementFactory.getRuntimeMXBean().getName())
					.append(",servlet=")
					.append(config.getServletName())
					.append(",context=")
					.append(config.getServletContext().getContextPath())
					.toString()
				)
			);
			_initError = false;
		}
		catch (final Throwable e)
		{
			_initError = true;
			if (_trap != null) _trap.error(new ProcessingEvent(ProcessingEventType.error, (new ErrorBean("MQX", "Could not initialize web service", e)).encode()));
			else log("Could not initialize web service", e);
			//TODO: não deveria lançar um erro para indicar ao servidor que não pode continuar?
		}
	}

	private byte[] getWSDL(final String entry, final String uri) throws WSConfigException
	{
		if (entry == null) throw new WSConfigException("WSDL file name must not be null");
		InputStream in;
		try
		{
			in = new FileInputStream(entry);
			try
			{
				final byte[] buffer = new byte[1024];
				final ByteArrayOutputStream out = new ByteArrayOutputStream(2048);
				int i;
				while ((i = in.read(buffer)) > 0) out.write(buffer, 0, i);
				final String template = (new String(out.toByteArray(), StandardCharsets.UTF_8));
				final String wsdl = template.replace("__WSDL_URI__", uri);
				if (wsdl.equals(template)) throw new WSConfigException("Invalid WSDL file");
				return wsdl.getBytes();
			}
			finally { in.close(); }
		}
		catch (final IOException e) { throw new WSConfigException("Could not load WSDL", e); }
	}

	@Override
	public void destroy()
	{
		if (_services != null)
		{
			final Iterator<String> it = _services.keySet().iterator();
			while (it.hasNext())
			{
				final ServiceHandler handler = _services.get(it.next());
				if (handler != null) handler.destroy();
			}
		}
		try { if (_mbName != null) ManagementFactory.getPlatformMBeanServer().unregisterMBean(_mbName); }
		catch (final Exception e) { if (_trap != null) _trap.error(new ProcessingEvent(ProcessingEventType.error, "Could not unregister MBean", e)); }
	}

	@Override
	protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException
	{
		final ServiceHandler handler = getHandler(request, response);
		if (handler == null) return;
		final Enumeration<String> e = request.getParameterNames();
		while (e.hasMoreElements())
		{
			if ("wsdl".equals(e.nextElement()))
			{
				handler.writeWSDLTo(response);
				return;
			}
		}
		writeResponse(HttpURLConnection.HTTP_BAD_REQUEST, response);
	}

	@Override
	protected void doPost (final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException
	{
		ServiceHandler handler;
		if ((handler = getHandler(request, response)) == null) return;
		final WSMethods methods = handler.getService();
		SOAPEnvelope call = null;
		try
		{
			call = SOAPParser.parseRequest(request.getInputStream(), _xmlSize);
			call.validate(methods);
		}
		catch (final XMLStreamException | SOAPException e)
		{
			writeFault(false, "Malformed SOAP request", methods.getMethod(call != null ? call.getName() : null), response);
			return;
		}
		final String soapAction = request.getHeader("SOAPAction");
		final String actionBlueprint = methods.getMethod(call.getName()).getSoapAction();
		if (soapAction == null || (actionBlueprint != null && soapAction.length() > 0 && !soapAction.equalsIgnoreCase(actionBlueprint)))
		{
			writeFault(false, "Invalid SOAPAction HTTP header", methods.getMethod(call != null ? call.getName() : null), response);
			return;
		}
		final SOAPEnvelope webResponse = methods.getMethod(call.getName()).getWebResponse().clone();
		webResponse.setVersion(call.getVersion());
		webResponse.setBodyNamespace(call.getBodyNamespace());
		try
		{
			handler.invoke(call, webResponse, request.getUserPrincipal());
			handler.writeResponseTo(response, webResponse);
			_okCount++;
		}
		catch (final SOAPException e) { writeFault(false, e.getMessage(), methods.getMethod(call.getName()), response); }
		catch (final Throwable e)
		{
			_failCount++;
			writeFault(true, "Internal server error", methods.getMethod(call.getName()), response);
			_trap.error(new ProcessingEvent(ProcessingEventType.error, (new ErrorBean("MQX", "Web service handler processing error", e)).encode()));
		}
	}
	private ServiceHandler getHandler(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException
	{
		String msg;
		if (!_initError)
		{
			final String path = request.getServletPath();
			if (path != null && path.length() > 0)
			{
				final ServiceHandler handler = _services.get(path);
				if (handler != null) return handler;
				else msg = "Web service handler for this path not found";
			}
			else msg = "Incorrect servlet mapping";
		}
		else msg = "Web service not initialized";
		
		_failCount++;
		writeResponse(HttpURLConnection.HTTP_INTERNAL_ERROR, response);
		if (_trap != null) _trap.error(new ProcessingEvent(ProcessingEventType.error, msg));
		return null;
	}
	private void writeResponse(final int status, final HttpServletResponse response)
	{
		response.setStatus(status);
		if (status >= 400) response.setHeader("Connection", "close");
	}
	private void writeFault(final boolean isServer, final String faultstring, final WSSignature sig, final HttpServletResponse response)
	{
		writeResponse(HttpURLConnection.HTTP_INTERNAL_ERROR, response);
		if (sig != null && sig.getWebResponse().getName() != null)
		{
			response.setContentType("text/xml;charset=UTF-8");
			try 
			{
				final SOAPEnvelope out = new SOAPEnvelope();
				out.setSOAPFault(isServer, faultstring);
				out.writeTo(response.getWriter());
			}
			catch (IOException e)
			{
				if (_trap != null) _trap.error(new ProcessingEvent(ProcessingEventType.error, "Could not write to response output stream", e));
				else log("Could not write to response output stream", e);
				_failCount++;
			}
		}
	}

	@Override
	public boolean isHealthy()
	{
		if (_initError) return false;
		long ok = _okCount, fail = _failCount;
		return ((ok + fail) * _failIdx) > fail;
	}
	@Override public long success() { return _okCount; }
	@Override public long failure() { return _failCount; }
}
