package br.gov.caixa.mqx;

class MQResponse
{
	long hConn;
	long hObj;
	byte[] msgId;
	byte[] correlId;
	byte[] message;
	byte[] msgDescriptor;
}
