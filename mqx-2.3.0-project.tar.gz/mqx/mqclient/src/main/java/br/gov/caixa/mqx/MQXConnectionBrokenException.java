package br.gov.caixa.mqx;


public final class MQXConnectionBrokenException extends MQXSeriesConnectionException
{
	private static final long serialVersionUID = -3663414544485167167L;
	public MQXConnectionBrokenException(String message) { super(message); }
	public MQXConnectionBrokenException(Throwable cause) { super(cause); }
	public MQXConnectionBrokenException(String message, Throwable cause) { super(message, cause); }
	public MQXConnectionBrokenException(String message, int reason) { super(message, reason); }
	public MQXConnectionBrokenException(String message, Throwable cause, int reason) { super(message, cause, reason);}
}
