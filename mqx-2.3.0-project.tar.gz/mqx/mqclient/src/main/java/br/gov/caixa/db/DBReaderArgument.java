package br.gov.caixa.db;

public interface DBReaderArgument {}
