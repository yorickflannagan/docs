package br.gov.caixa.mqx.pool;

final class ImplementationContainer
{
	final boolean input;
	final Controllable implementation;
	ImplementationContainer(final boolean input, final Controllable implementation) { this.input = input; this.implementation = implementation; }
}
