package br.gov.caixa.xml;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Reader;
import java.io.Serializable;

import org.w3c.dom.ls.LSInput;

public class DOMInputSource implements LSInput, Serializable
{
	private static final long serialVersionUID = 8479206522160817236L;
	private final byte[] source;
	public DOMInputSource(final byte[] source)
	{
		if (source == null || source.length == 0) throw new NullPointerException("Array argument must not be null nor empty");
		this.source = source;
	}
	@Override
	public Reader getCharacterStream() { return null; }
	@Override public void setCharacterStream(Reader characterStream) {}
	@Override public void setByteStream(InputStream byteStream) {}
	@Override public String getStringData() { return null; }
	@Override public void setStringData(String stringData) {}
	@Override public String getSystemId() { return null; }
	@Override public void setSystemId(String systemId) {}
	@Override public String getPublicId() { return null; }
	@Override public void setPublicId(String publicId) {}
	@Override public String getBaseURI() { return null; }
	@Override public void setBaseURI(String baseURI) {}
	@Override public String getEncoding() { return null; }
	@Override public void setEncoding(String encoding) {}
	@Override public boolean getCertifiedText() { return false; }
	@Override public void setCertifiedText(boolean certifiedText) {}
	@Override public InputStream getByteStream() { return new ByteArrayInputStream(source); }
}
