package br.gov.caixa.soap;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

public class SOAPElementSequence extends SOAPElement {

    private static final long serialVersionUID = -2611547052567234706L;
    final List<SOAPElement> elems = new ArrayList<>();


    public SOAPElementSequence() {}
    public SOAPElementSequence(String name) { super(name); }    

    public void addElement(final SOAPElement elem) { elems.add(elem); }
    public boolean removeElement(final SOAPElement elem) { return elems.remove(elem); }

	@Override
	public String toString()
	{
		final StringBuilder builder = new StringBuilder(512);
		builder.append("SOAPElement=\n{\n");
		builder.append("dataType=").append(dataType).append("\n");
		if (name != null) builder.append("name=").append(name).append("\n");
        if (data != null) builder.append("data=");
        for(SOAPElement elem : elems)
        {
            builder.append("[").append(elem).append("]\n");
        }
        builder.append("\n");
		builder.append("optional=").append(optional).append("\n");
		return builder.append("}").toString();
	}

	public void writeTo(final Writer writer) throws IOException
	{
		if (name != null)
		{
			writer.write(START_ELEMENT);
			writer.write(name);
			writer.write(END_ELEMENT);
            for(SOAPElement elem : elems)
            {
                elem.writeTo(writer);;
            }
            writer.write(START_ELEMENT);
			writer.write('/');
			writer.write(name);
			writer.write(END_ELEMENT);
		}

	}
	public int size()
	{
		int size = 0;
		if (data != null && name != null)
		{
			size += (START_ELEMENT).length();
			size += (name).length();
			size += (END_ELEMENT).length();
            for(SOAPElement elem : elems)
            {
                size += elem.size();
            }
			size += (START_ELEMENT).length();
			size += 1;
			size += (name).length();
			size += (END_ELEMENT).length();
		}
		return size;

	}    
    
}