package br.gov.caixa.mqx.ibm;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import org.crypthing.things.messaging.MQXConnection;
import org.crypthing.things.messaging.MQXConnectionException;
import org.crypthing.things.messaging.MQXIllegalArgumentException;
import org.crypthing.things.messaging.MQXIllegalStateException;
import org.crypthing.things.messaging.MQXMessage;
import org.crypthing.things.messaging.MQXQueue;

import br.gov.caixa.mqx.MQSeries;
import br.gov.caixa.mqx.MQXSeriesConnectionException;

import com.ibm.mq.MQEnvironment;
import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.MQSimpleConnectionManager;
import com.ibm.mq.constants.MQConstants;

/**
 * MQXIBMConnectionImpl
 */
public class MQXIBMConnectionImpl implements MQXConnection 
{

    private boolean syncpoint;
    private static MQSimpleConnectionManager cmgr = new MQSimpleConnectionManager();
    static{
        // cmgr.setMaxConnections(0);  0 é sem limite.
        cmgr.setTimeout(15000); // Conexão não usada fecha em 15 segundos
        cmgr.setMaxUnusedConnections(5); // Máximo de 5 conexões sem dono.
        MQEnvironment.setDefaultConnectionManager(cmgr);
        /* TODO: estudar melhor as opções:
            Na verdade não é pra sobrar conexão não utilizada, ao fechar a conexão não haverá disconnect()
            O limite em 0 é o default, que significa que não há limites de conexões
            Não coloquei timeout e unused em 0 pois não sei a reação.
         */
    }

    private MQQueueManager qm;
    private boolean bind = false;
    private boolean ebcdic;
    @Override
    public void initConnection(Properties props) throws MQXIllegalArgumentException 
    {
            try{ qm = new MQQueueManager(props.getProperty("br.gov.caixa.mqx.manager"),props);  } 
            catch (final Throwable e) { throw new MQXIllegalArgumentException("Could not open connection to MQSeries", e); }
            bind = MQConstants.TRANSPORT_MQSERIES_BINDINGS.equals(MQEnvironment.properties.get(MQConstants.TRANSPORT_PROPERTY));
            ebcdic=System.getProperty("file.encoding").startsWith("IBM");
    }

    @Override
    public void close() throws MQXIllegalStateException, MQXConnectionException 
    {
        if(qm == null || !qm.isConnected()) { throw new MQXIllegalStateException("Not Connected" + qm); }
        try {
            try {
                for(String queue : queues.keySet()) { try{ if(queues.get(queue) != null)queues.get(queue).internalClose(); } catch(Exception e) {} }
            }
            finally {
                qm.close();
                qm = null;
            }
        } catch (MQException e) { throw new MQXConnectionException(e); }
    }

	private final Map<String, MQXQueueImpl> queues = new ConcurrentHashMap<String, MQXQueueImpl>();

    @Override
	public MQXQueue openQueue(final Properties props) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException
	{
        if(qm == null || !qm.isConnected()) { throw new MQXIllegalStateException("Not Connected" + qm); }
		int getTimeout, expiry;
		try { getTimeout = Integer.parseInt(props.getProperty("br.gov.caixa.mqx.get.timeout")); }
		catch (final NumberFormatException e) { getTimeout = 0; }
		try { expiry = Integer.parseInt(props.getProperty("br.gov.caixa.mqx.put.expire")); }
		catch (final NumberFormatException e) { expiry = 0; }
		return openQueue
		(
			props.getProperty("br.gov.caixa.mqx.object"), 
			Boolean.parseBoolean(props.getProperty("br.gov.caixa.mqx.convert")),
			Boolean.parseBoolean(props.getProperty("br.gov.caixa.mqx.convertMsgId")),
			Boolean.parseBoolean(props.getProperty("br.gov.caixa.mqx.convertCorrelId")),
			getTimeout,
			expiry
		);
    }
    
	private MQXQueue openQueue
	(
		final String qName,
		final boolean convert,
		final boolean convertMsgId,
		final boolean convertCorrelId,
		final int getTimeout,
		final int expiry
	)	throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException
	{
        if(qm == null || !qm.isConnected()) { throw new MQXIllegalStateException("Not Connected" + qm); }
		MQXQueueImpl queue;
        queue = (MQXQueueImpl)openQueue(qName);
        if (queue == null)
        {
            if
            (
                qName == null ||
                qName.length() == 0 ||
                qName.length() > MQSeries.MQ_Q_NAME_LENGTH
            )	throw new MQXIllegalArgumentException("Invalid argument length");
            
            queue = new MQXQueueImpl(qName, convert, convertMsgId, convertCorrelId, getTimeout, expiry);
            queues.put(qName, queue);
        }
		return queue;
	}

	@Override public MQXQueue openQueue(final String name) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException
	{
        if(qm == null || !qm.isConnected()) { throw new MQXIllegalStateException("Not Connected" + qm); }
		if (name == null || name.length() == 0) throw new MQXIllegalArgumentException("Queue name must not be null or empty");
        return  queues.get(name);
	}




    @Override
    public void begin() throws MQXConnectionException 
    {
        if(qm == null || !qm.isConnected()) { throw new MQXConnectionException("Not Connected" + qm); }
        if(syncpoint) throw new MQXConnectionException("already in transaction");
        if(bind) 
        {
            try { qm.begin(); } 
            catch (MQException e)  { 
                throw new MQXSeriesConnectionException("Could not start transaction.", e, e.getReason()); 
            }
        }
        syncpoint = true;
    }

    @Override
    public void commit() throws MQXConnectionException 
    {
        if(qm == null || !qm.isConnected()) { throw new MQXConnectionException("Not Connected" + qm); }
        if(!syncpoint) throw new MQXConnectionException("Can't commit. Not in transaction");
        try { qm.commit(); } 
        catch (MQException e) {
            throw new MQXSeriesConnectionException("Could not commit.", e, e.getReason());
        }
        syncpoint = false;
    }

    @Override
    public void back() throws MQXConnectionException 
    {
        if(qm == null || !qm.isConnected()) { throw new MQXConnectionException("Not Connected" + qm); }
        if(!syncpoint) throw new MQXConnectionException("Can't rollback. Not in transaction");
        try { qm.backout(); } 
        catch (MQException e) {
            throw new MQXSeriesConnectionException("Could not commit.", e, e.getReason());
        }
        syncpoint = false;

    }

    @Override
    public MQXMessage call(String putQueue, String getQueue, MQXMessage msg)
            throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException 
    {
        if(qm == null || !qm.isConnected()) { throw new MQXIllegalStateException("Not Connected" + qm); }
        if (msg == null || msg.getMessage() == null) throw new MQXIllegalArgumentException("Request message must not be null");
        final MQXQueue out = queues.get(putQueue);
        final MQXQueue in = queues.get(getQueue);
        if (out == null) throw new MQXIllegalArgumentException("Output queue name not found: " + putQueue);
        if (in == null)  throw new MQXIllegalArgumentException("Input queue name not found: " + getQueue);
        final MQXMessage fMsg = out.send(msg);
        fMsg.setCorrelId(fMsg.getMsgId());
        fMsg.setMsgId(null);
        fMsg.setMessage(null);
        return in.receive(fMsg);
    }

    @Override public boolean isValid()  { return (qm != null &&  qm.isConnected()); }
    @Override public boolean isTransaction()  { return isValid() && syncpoint; }

    public class MQXQueueImpl implements MQXQueue
    {

        private MQQueue queue;
		private final int defaultGetTimeout;
        private final int defaultExpiry;
        private final boolean convert;
        private final boolean convertMsgId;
        private final boolean convertCorrelId;
        private final String name;


		private MQXQueueImpl
		(
			final String queue,
			final boolean convert,
			final boolean convertMsgId,
			final boolean convertCorrelId,
			final int getTimeout,
			final int expiry
		)	throws MQXConnectionException
		{
            this.convert = convert;
            this.name = queue;
            this.convertMsgId = convertMsgId;
            this.convertCorrelId = convertCorrelId;
			defaultGetTimeout = getTimeout;
            defaultExpiry = expiry;
            try {
                this.queue = qm.accessQueue(name, MQConstants.MQOO_OUTPUT | MQConstants.MQOO_INPUT_SHARED);
            } catch (MQException e) {
                throw new MQXSeriesConnectionException("Could not open queue.[" + queue + "]", e, e.getReason());
            }
        }

        @Override
        public void close() throws MQXIllegalStateException, MQXConnectionException {}

        private void internalClose() throws MQXConnectionException
		{
            if(qm == null || !qm.isConnected()) { throw new MQXConnectionException("Not Connected" + qm); }
            if(queue == null || !queue.isOpen()) { throw new MQXConnectionException("Queue not open" + queue); }
            try {
                queue.close();
            } catch (MQException e) {
                throw new MQXSeriesConnectionException("Could not close queue." + queue, e, e.getReason());
            }
        }

        @Override
        public MQXMessage send(MQXMessage msg)
                throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException 
        {
            return send(msg,defaultExpiry);
        }

        @Override
        public MQXMessage send(MQXMessage msg, int expire)
                throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException 
        {
            if(qm == null || !qm.isConnected()) { throw new MQXIllegalStateException("Not Connected" + qm); }
            MQPutMessageOptions put = new MQPutMessageOptions();
            put.options = (syncpoint ? MQConstants.MQPMO_SYNCPOINT : MQConstants.MQPMO_NO_SYNCPOINT);
            MQMessage message = new MQMessage();

            message.format = convert ? MQConstants.MQFMT_STRING : MQConstants.MQFMT_NONE;  


            if(msg.getMsgId() != null)
            {
                message.messageId = convertMsgId ? ebcdic ? Convert.MQX_ebcdic_to_utf8(msg.getMsgId()) : Convert.MQX_utf8_to_ebcdic(msg.getMsgId()) : msg.getMsgId();
                // convertMsgId ? ebcdic ? seus pobremas se acabaram! o ultra mega MQX resolve tudo, e não é só isso!.
            } else {
                put.options |= MQConstants.MQPMO_NEW_MSG_ID;
            }
            if(msg.getCorrelId() != null)
            {
                message.correlationId = convertCorrelId ? ebcdic ? Convert.MQX_ebcdic_to_utf8(msg.getCorrelId()) : Convert.MQX_utf8_to_ebcdic(msg.getCorrelId()) : msg.getCorrelId();
            }

            message.expiry = expire;
            try{
                message.write(msg.getMessage());
                queue.put(message, put);
                return  new MQXMessage(msg.getMessage(), message.messageId, message.correlationId);
            }
            catch(MQException e)
            {
                throw new MQXSeriesConnectionException("Could not put message.", e, e.getReason());
            }
            catch(IOException e)
            {
                throw new MQXIllegalStateException("Could not write message buffer.", e);
            }
        }

        @Override
        public MQXMessage receive(MQXMessage msg)
                throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException 
        {
            return receive(msg, defaultGetTimeout);
        }

        @Override
        public MQXMessage receive(MQXMessage msg, int timeout)
                throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException 
        {
                    
            if(qm == null || !qm.isConnected()) { throw new MQXIllegalStateException("Not Connected" + qm); }
            MQGetMessageOptions get = new MQGetMessageOptions();
            get.options = MQConstants.MQGMO_WAIT;
            get.options |= (syncpoint ? MQConstants.MQGMO_SYNCPOINT : MQConstants.MQGMO_NO_SYNCPOINT);
            if(convert) get.options |= MQConstants.MQGMO_CONVERT;  
            get.waitInterval = timeout;
            // TODO Ver se o getoptions é reaproveitável ou não.

            MQMessage message = new MQMessage();

            if(msg.getMsgId() != null)
            {
                message.messageId = convertMsgId ? Convert.MQX_ebcdic_to_utf8(msg.getMsgId()) : msg.getMsgId();
                get.matchOptions |= MQConstants.MQMO_MATCH_MSG_ID;
            }
            if(msg.getCorrelId() != null)
            {
                message.correlationId = convertCorrelId ? Convert.MQX_ebcdic_to_utf8(message.correlationId) : msg.getCorrelId();
                get.matchOptions |= MQConstants.MQMO_MATCH_CORREL_ID;
            }

            try {
                queue.get(message, get);
                final byte[]  buf = new byte[message.getDataLength()];
                message.readFully(buf);
                final byte msgid[] = (msg.getMsgId()==null && convertMsgId) ? Convert.MQX_utf8_to_ebcdic(message.messageId) :message.messageId;
                final byte correl[] = (msg.getCorrelId()==null && convertCorrelId) ? Convert.MQX_utf8_to_ebcdic(message.correlationId) :message.correlationId;
                return  new MQXMessage(buf, msgid , correl);
            } catch (MQException e) { 
                if(e.getReason() != MQConstants.MQRC_NO_MSG_AVAILABLE) throw new MQXSeriesConnectionException("Could not receive message.", e, e.getReason());
                return new MQXMessage();
            } 
            catch(IOException e){ throw new MQXIllegalStateException("Could not read message buffer.", e); }
        }
    } 
}