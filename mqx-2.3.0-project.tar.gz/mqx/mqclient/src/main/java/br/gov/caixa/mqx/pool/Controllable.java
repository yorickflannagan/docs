package br.gov.caixa.mqx.pool;

public interface Controllable
{
	boolean isRunning();
	void stop();
	int getOkCounter();
	int getFailCounter();
}
