package br.gov.caixa.xml;

import java.io.IOException;
import java.io.Reader;

public final class XMLFragmentReader extends Reader
{
	public static final String XML_INSTRUCTION = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
	private static final int XML_INSTRUCTION_LEN = XML_INSTRUCTION.length();
	private final String _source;
	private final char[] _source_chars;
	private int _offset;
	private int _mark;
	private boolean _isClosed;
	private final int _length;
	public XMLFragmentReader(final String source)
	{
		if (source == null) throw new NullPointerException("Argument must not be null");
		_source = source;
		_source_chars = null;
		_offset = 0;
		_mark = 0;
		_length = XML_INSTRUCTION_LEN + source.length();
	}

	public XMLFragmentReader(final char[] source)
	{
		if (source == null) throw new NullPointerException("Argument must not be null");
		_source = null;
		_source_chars = source;
		_offset = 0;
		_mark = 0;
		_length = XML_INSTRUCTION_LEN + source.length;
	}




	@Override
	public int read(char[] cbuf, int off, int len) throws IOException
	{
		if (_isClosed) throw new IOException("Reader already closed");
		if (_offset >= _length) return -1;
		final int read = Math.min(_length - _offset, len);
		if (_offset > XML_INSTRUCTION_LEN)
		{
			final int srcBegin = _offset - XML_INSTRUCTION_LEN;
			if(_source !=null) _source.getChars(srcBegin, srcBegin + read, cbuf, off);
			else System.arraycopy(_source_chars, srcBegin, cbuf, off, read);
		}
		else
		{
			if (_offset + len < XML_INSTRUCTION_LEN) XML_INSTRUCTION.getChars(_offset, _offset + read, cbuf, off);
			else
			{
				XML_INSTRUCTION.getChars(_offset, XML_INSTRUCTION_LEN, cbuf, off);
				int already = XML_INSTRUCTION_LEN -_offset;
				if(_source !=null) _source.getChars(0, read - already, cbuf, off + already);
				else System.arraycopy(_source_chars, 0, cbuf, off + already, read - already);
			}
		}
		_offset += read;
		return read;
	}

	@Override public boolean markSupported() { return true; }
	@Override
	public void mark(int readAheadLimit) throws IOException
	{
		if (_isClosed) throw new IOException("Reader already closed");
		_mark = _offset;
	}
	@Override
	public void reset() throws IOException
	{
		if (_isClosed) throw new IOException("Reader already closed");
		_offset = _mark;
		_mark = 0;
	}
	@Override public void close() { _isClosed = true; }

	@Override
	public int read() throws IOException
	{
		if (_isClosed) throw new IOException("Reader already closed");
		if (_offset >= _length) return -1;
		if (_offset < XML_INSTRUCTION_LEN) return XML_INSTRUCTION.charAt(_offset++);
		if(_source !=null) return _source.charAt(_offset++ - XML_INSTRUCTION_LEN);
		else return _source_chars[_offset++ - XML_INSTRUCTION_LEN];
	}

	@Override
	public long skip(long n) throws IOException
	{
		if (_isClosed) throw new IOException("Reader already closed");
		if (_offset >= _length) return -1;
		long ret;
		if(_offset + n > _length)
		{
			ret = _length - _offset;
			_offset = _length;
		}
		else
		{
			ret = n;
			_offset += n;
		}
		return ret;
	}
	@Override public boolean ready() throws IOException
	{
		if (_isClosed) throw new IOException("Reader already closed");
		return true;
	}
}
