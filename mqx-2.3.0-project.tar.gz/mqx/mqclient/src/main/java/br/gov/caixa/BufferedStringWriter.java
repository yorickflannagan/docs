package br.gov.caixa;

import java.io.Writer;

public final class BufferedStringWriter extends Writer
{
	private final StringBuilder internal;
	public BufferedStringWriter() { this(0); }
	public BufferedStringWriter(int capacity)
	{
		if (capacity == 0) capacity = 4096;
		internal = new StringBuilder(capacity);
	}
	@Override public void write(char[] cbuf, int off, int len) { internal.append(cbuf, off, len); }
	@Override public void flush() {}
	@Override public void close() { internal.setLength(0); }
	@Override public void write(int c) { internal.append((char) c); }
	@Override public void write(char cbuf[]) { internal.append(cbuf); }
	@Override public void write(String str) { internal.append(str); }
	@Override public void write(String str, int off, int len) { internal.append(str, off, off + len); }
	@Override public Writer append(CharSequence csq) { internal.append(csq); return this; }
	@Override public Writer append(CharSequence csq, int start, int end) { internal.append(csq, start, end); return this; }
	@Override public Writer append(char c) { internal.append(c); return this; }
	@Override public String toString() { return internal.toString(); }
}
