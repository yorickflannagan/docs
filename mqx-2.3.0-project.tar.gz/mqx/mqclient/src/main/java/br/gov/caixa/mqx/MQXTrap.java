package br.gov.caixa.mqx;

import java.io.IOException;

import org.crypthing.things.snmp.EncodableString;
import org.crypthing.things.snmp.Event;
import org.crypthing.things.snmp.Trap;
import org.snmp4j.PDU;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;
//import MQXSeriesConnectionException
public class MQXTrap extends Trap
{
	private static final long serialVersionUID = 3193065837447027011L;
	private static final String MQ_REASON_OID = ".1.6";
	private final OID MQREASON_OID;
	public MQXTrap(String udpAddress, String oidRoot) throws IOException
	{
		super(udpAddress, oidRoot);
		MQREASON_OID = new OID(oidRoot + MQ_REASON_OID);
	}

	protected PDU addEventBindings(final PDU pdu, final String evtOID, final String message, final Throwable e)
	{
		PDU mqPDU = addEventBindings(pdu, new Event().setData(new EncodableString(message)).setRelativeOID(evtOID));
		if
		(
			e instanceof MQXSeriesConnectionException
		)	mqPDU.add
			(
				new VariableBinding
				(
					MQREASON_OID,
					new Integer32(((MQXSeriesConnectionException) e).getReason())
				)
		);
		return mqPDU;
	}

}
