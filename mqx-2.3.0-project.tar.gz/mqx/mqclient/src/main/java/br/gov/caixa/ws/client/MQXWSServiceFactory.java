package br.gov.caixa.ws.client;

import java.net.MalformedURLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.crypthing.things.appservice.ReleaseResourceEventDispatcher;
import org.crypthing.things.appservice.ServicesFactory;
import org.crypthing.things.config.ConfigException;
import org.crypthing.things.appservice.config.RunnerConfig;
import org.crypthing.things.snmp.ProcessingEventListener;

import br.gov.caixa.ws.WSConfigException;
import br.gov.caixa.ws.WSMethods;
import br.gov.caixa.ws.WSSignature;

public class MQXWSServiceFactory extends ServicesFactory
{
	@Override
	public void bind(final RunnerConfig cfg, final ReleaseResourceEventDispatcher subscriber, final ProcessingEventListener trap) throws ConfigException, NamingException
	{
		super.bind(cfg, subscriber, trap);
		try
		{
			final WSMethods config = WSMethods.getServiceConfig(cfg.getJndi().getProperty("ws-client-config"), true);
			final String uri = config.getWsdlUri();
			final InitialContext context = new InitialContext();
			for (final WSSignature sig : config.getMethods())
			{
				final String method = sig.getWebMethod().getName();
				if (method != null) context.bind("java:ws/" + method, new WebClient(uri, sig));
			}
		}
		catch (final WSConfigException | MalformedURLException e) { throw new ConfigException(e); }
	}
}
