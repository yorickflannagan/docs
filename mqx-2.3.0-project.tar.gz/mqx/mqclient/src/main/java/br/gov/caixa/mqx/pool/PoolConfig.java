package br.gov.caixa.mqx.pool;

import org.crypthing.things.appservice.config.ConfigProperties;
import org.crypthing.things.appservice.config.ConnectorsConfig;

public class PoolConfig
{
	private ConfigProperties snmp;
	private ConnectorsConfig connectors;
	public ConfigProperties getSnmp() { return snmp; }
	public void setSnmp(final ConfigProperties snmp) { this.snmp = snmp; }
	public ConnectorsConfig getConnectors() { return connectors; }
	public void setConnectors(final ConnectorsConfig connectors) { this.connectors = connectors; }
}
