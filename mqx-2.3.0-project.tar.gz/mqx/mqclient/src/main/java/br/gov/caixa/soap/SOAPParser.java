package br.gov.caixa.soap;

import java.io.InputStream;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPException;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

import br.gov.caixa.BufferedStringWriter;

public final class SOAPParser
{
	public static final String SOAP11_NAMESPACE = "http://schemas.xmlsoap.org/soap/envelope/";
	public static final String SOAP12_NAMESPACE = "http://www.w3.org/2003/05/soap-envelope/";
	public static enum SOAPVersion
	{
		SOAP11(SOAP11_NAMESPACE),
		SOAP12(SOAP12_NAMESPACE);
		private final String namespace;
		private SOAPVersion(final String namespace) { this.namespace = namespace; }
		public String getNamespace() { return namespace; }
	}

	private enum SOAPParts
	{
		Start(0, ""),
		StartDocument(0, ""),
		StartEnvelope(1, "Envelope"),
		StartHeader(2, "Header"),
		EndHeader(2, "Header"),
		StartBody(2, "Body"),
		StartMethod(3, ""),
		StartParameter(4, ""),
		EndParameter(4, ""),
		EndMethod(3, ""),
		EndBody(2, "Body"),
		EndEnvelope(1, "Envelope"),
		EndDocument(0, "");
		private final int level;
		private final String tag;
		private SOAPParts(int level, String tag) { this.level = level; this.tag = tag; }
		private int getLevel() { return level; }
		private String getTag() { return tag; }
		private SOAPParts nextState()
		{
			switch (this)
			{
			case EndMethod: return EndBody;
			case EndBody: return EndEnvelope;
			case EndEnvelope: return EndDocument;
			default: return null;
			}
		}
	}

	public static SOAPEnvelope parseRequest(final InputStream in, final int buffSize) throws XMLStreamException, SOAPException
	{
		SOAPEnvelope ret = null;
		SOAPParts state = SOAPParts.Start;
		int level = -1;
		final XMLInputFactory xmlf = XMLInputFactory.newInstance();
		final BufferedStringWriter writer = new BufferedStringWriter(buffSize);
		xmlf.setProperty(XMLInputFactory.IS_COALESCING, true);
		xmlf.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, false);
		xmlf.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
        xmlf.setProperty("com.ctc.wstx.inputBufferLength",buffSize);
		final XMLEventReader reader = xmlf.createXMLEventReader(in);
		SOAPElement current = null;
		try
		{
			while (reader.hasNext())
			{
				final XMLEvent e = reader.nextEvent();
				switch (state)
				{
				case Start: 
					if (!e.isStartDocument()) throw new SOAPException("Malformed XML document");
					level++;
					state = SOAPParts.StartDocument;
					break;
				case StartDocument:
					if (e.isStartElement())
					{
						final QName name = e.asStartElement().getName();
						if (SOAPParts.StartEnvelope.getTag().equals(name.getLocalPart()))
						{
							level++;
							state = SOAPParts.StartEnvelope;
							
							ret = SOAP12_NAMESPACE.equals(name.getNamespaceURI()) ?
								new SOAPEnvelope(SOAPVersion.SOAP12) :
								new SOAPEnvelope(SOAPVersion.SOAP11);
						}
						else throw new SOAPException("Envelope element not found");
					}
					break;
				case StartEnvelope:
					if (e.isStartElement())
					{
						final String name = e.asStartElement().getName().getLocalPart();
						if (SOAPParts.StartBody.getTag().equals(name)) state = SOAPParts.StartBody;
						else if (SOAPParts.StartHeader.getTag().equals(name)) state = SOAPParts.StartHeader;
						else throw new SOAPException("Body element not found");
						level++;
					}
					else if (e.isEndElement()) throw new SOAPException("Envelope element must not be empty");
					break;
				case StartHeader:
					if (e.isStartElement()) level++;
					else if (e.isEndElement())
					{
						if (level == SOAPParts.EndHeader.getLevel()) state = SOAPParts.EndHeader;
						level--;
					}
					break;
				case EndHeader:
					if (e.isStartElement())
					{
						level++;
						if (SOAPParts.StartBody.getTag().equals(e.asStartElement().getName().getLocalPart())) state = SOAPParts.StartBody;
						else throw new SOAPException("SOAP envelope must not have expurious elements");
					}
					else if (e.isEndElement()) throw new SOAPException("SOAP message without a body");
					break;
				case StartBody:
					if (e.isStartElement())
					{
						final QName name = e.asStartElement().getName();
						ret.setName(name.getLocalPart());
						ret.setBodyNamespace(name.getNamespaceURI());
						state = SOAPParts.StartMethod;
						level++;
					}
					else if (e.isEndElement()) throw new SOAPException("Body element must not be empty");
					break;
				case StartMethod:
				case EndParameter:
					if (e.isStartElement())
					{
						current = new SOAPElement(e.asStartElement().getName().getLocalPart());
						ret.add(current);
						state = SOAPParts.StartParameter;
						level++;
					}
					else if (e.isEndElement())
					{
						state = SOAPParts.EndMethod;
						level--;
					}
					break;
				case StartParameter:
					if (e.isStartElement()) level++;
					else if (e.isEndElement())
					{
						if (level == SOAPParts.EndParameter.getLevel()) 
						{
							state = SOAPParts.EndParameter;
							current.setData(writer.toString());
							writer.close();
							level--;
							continue;
						}
						level--;
					}
					e.writeAsEncodedUnicode(writer);
					break;
				case EndMethod:
				case EndBody:
				case EndEnvelope:
					if (e.isEndElement()) state = state.nextState();
					else if (e.isStartElement()) throw new SOAPException("Invalid SOAP message");
				default:
				}
			}
		}
		finally { reader.close(); }
		return ret;
	}
}
