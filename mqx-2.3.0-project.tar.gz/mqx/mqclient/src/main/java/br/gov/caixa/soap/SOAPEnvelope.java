package br.gov.caixa.soap;

import java.io.IOException;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import javax.xml.soap.SOAPException;

import br.gov.caixa.soap.SOAPParser.SOAPVersion;
import br.gov.caixa.ws.WSMethods;
import br.gov.caixa.ws.WSSignature;

public final class SOAPEnvelope implements Cloneable, Serializable
{
	private static final long serialVersionUID = -2201289677261384450L;
	private SOAPVersion version;
	private String name;
	private final ArrayList<SOAPElement> elements;
	private String bodyNamespace;
	private final String soapEnvelope;

	private static final String SOAP_HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:soap=\"";
	private static final String XML_NAMESPACE = "\" xmlns:xml=\"http://www.w3.org/XML/1998/namespace\">";
	public SOAPEnvelope() { this(SOAPVersion.SOAP11); }
	public SOAPEnvelope(final SOAPVersion version) { this(version, null); }
	public SOAPEnvelope(final SOAPVersion version, final String name) { this(version, name, null); }
	public SOAPEnvelope(final SOAPVersion version, final String name, final String namespace) { this(version, name, namespace, new ArrayList<SOAPElement>()); }
	public SOAPEnvelope(final SOAPVersion version, final String name, final String namespace, final ArrayList<SOAPElement> elements)
	{
		this.version = version;
		this.name = name;
		bodyNamespace = namespace;
		this.elements = elements;
		StringBuilder builder = new StringBuilder(256);
		builder.append(SOAP_HEADER).append(version.getNamespace()).append(XML_NAMESPACE);
		soapEnvelope = builder.toString();
	}

	public String getName() { return name; }
	public void setName(final String name) { this.name = name; }
	public SOAPVersion getVersion() { return version; }
	public void setVersion(SOAPVersion version) { this.version = version; }
	public String getBodyNamespace() { return bodyNamespace; }
	public void setBodyNamespace(String bodyNamespace) { this.bodyNamespace = bodyNamespace; }
	public void add(final SOAPElement element) { elements.add(element); }
	public SOAPElement get(final String name)
	{
		if (name != null) for (final SOAPElement element : elements) if (name.equals(element.getName())) return element;
		return null;
	}
	public List<SOAPElement> getElements() { return elements; }
	@Override public SOAPEnvelope clone() { return new SOAPEnvelope(version, name, bodyNamespace, elements); }
	@Override
	public String toString()
	{
		final StringBuilder builder = new StringBuilder(512);
		builder.append("SOAPBody=\n{\n");
		builder.append("version=").append(version.getNamespace()).append("\n");
		if (name != null) builder.append("name=").append(name).append("\n");
		if (bodyNamespace != null) builder.append("bodyNamespace=").append(bodyNamespace).append("\n");
		for (final SOAPElement element : elements) builder.append(element.toString());
		return builder.append("\n}").toString();
	}

	private static final String FAULT_ELEMENT = "soap:Fault";
	private static final String FAULT11_CODE_ELEMENT = "faultcode";
	private static final String FAULT11_CLIENT_CODE = "soap:Client";
	private static final String FAULT11_SERVER_CODE = "soap:Server";
	private static final String FAULT11_REASON_ELEMENT = "faultstring";
	private static final String FAULT12_CODE_ELEMENT = "soap:Code";
	private static final String FAULT12_CLIENT_CODE = "<soap:Value>soap:Sender</soap:Value>";
	private static final String FAULT12_SERVER_CODE = "<soap:Value>soap:Receiver</soap:Value>";
	private static final String FAULT12_REASON_ELEMENT = "soap:Reason";
	private static final String FAULT12_REASON_PREFIX = "<soap:Text xml:lang=\"en\">";
	private static final String FAULT12_REASON_SUFIX = "</soap:Text>";
	
	private static final String SOAP_ENVELOPE_END = "</soap:Envelope>";
	private static final String SOAP_BODY = "soap:Body";
	private static final String START_ELEMENT = "<";
	private static final String END_ELEMENT = ">";
	public void setSOAPFault(final boolean isServer, final String error)
	{
		name = FAULT_ELEMENT;
		elements.clear();
		if (version == SOAPVersion.SOAP11)
		{
			add(new SOAPElement(FAULT11_CODE_ELEMENT, isServer ? FAULT11_SERVER_CODE : FAULT11_CLIENT_CODE));
			add(new SOAPElement(FAULT11_REASON_ELEMENT, error));
		}
		else
		{
			add(new SOAPElement(FAULT12_CODE_ELEMENT, isServer ? FAULT12_SERVER_CODE : FAULT12_CLIENT_CODE));
			add(new SOAPElement(FAULT12_REASON_ELEMENT, FAULT12_REASON_PREFIX + error + FAULT12_REASON_SUFIX));
		}
	}
	public void writeTo(final Writer writer) throws IOException
	{
		if (name != null)
		{
			writer.write(soapEnvelope);
			writer.write(START_ELEMENT);
			writer.write(SOAP_BODY);
			writer.write(END_ELEMENT);
			writer.write(START_ELEMENT);
			writer.write(name);
			if (bodyNamespace != null)
			{
				writer.write(" xmlns=\"");
				writer.write(bodyNamespace);
				writer.write('"');
			}
			writer.write(END_ELEMENT);
			for (final SOAPElement element : elements) element.writeTo(writer);
			writer.write(START_ELEMENT);
			writer.write('/');
			writer.write(name);
			writer.write(END_ELEMENT);
			writer.write(START_ELEMENT);
			writer.write('/');
			writer.write(SOAP_BODY);
			writer.write(END_ELEMENT);
			writer.write(SOAP_ENVELOPE_END);
		}
	}
	public int size()
	{
		int size = 0;
		if (name != null)
		{
			size += (soapEnvelope).length();
			size += (START_ELEMENT).length();
			size += (SOAP_BODY).length();
			size += (END_ELEMENT).length();
			size += (START_ELEMENT).length();
			size += (name).length();
			if (bodyNamespace != null)
			{
				size += (" xmlns=\"").length();
				size += (bodyNamespace).length();
				size += 1;
			}
			size += (END_ELEMENT).length();
			for (final SOAPElement element : elements) size += element.size();
			size += (START_ELEMENT).length();
			size += 1;
			size += (name).length();
			size += (END_ELEMENT).length();
			size += (START_ELEMENT).length();
			size += 1;
			size += (SOAP_BODY).length();
			size += (END_ELEMENT).length();
			size += (SOAP_ENVELOPE_END).length();
		}
		return size;
	}
	public void validate(final WSMethods methods) throws SOAPException
	{
		final WSSignature signature = methods.getMethod(name);
		if (signature == null) throw new SOAPException("Invalid service method");
		final String namespace = signature.getWebMethod().getBodyNamespace();
		if ((namespace != null && !namespace.equals(bodyNamespace)) || (namespace == null && bodyNamespace != null)) throw new SOAPException("Invalid call namespace");
		final List<SOAPElement> call = signature.getWebMethod().getElements();
		if (call.size() < elements.size()) throw new SOAPException("Invalid number of parameters");
		for (int i = 0, j = 0; i < call.size(); i++)
		{
			final SOAPElement bPrint = call.get(i);
			final SOAPElement elem = j < elements.size() ? elements.get(j) : null;
			if (elem != null && bPrint.getName().equals(elem.getName())) j++;
			else if (!bPrint.isOptional()) throw new SOAPException("Non-optional parameter not received");
		}
	}
	public String faultToString()
	{
		String ret = null;
		if ("Fault".equals(name) || FAULT_ELEMENT.equals(name))
		{
			for (final SOAPElement e : elements)
			{
				if ("faultstring".equals(e.getName()))
				{
					ret = e.getData();
					break;
				}
				if ("Reason".equals(e.getName()))
				{
					final String reason = e.getData();
					int i = reason.indexOf(">");
					if (i > -1)
					{
						int j = reason.indexOf("<", i);
						if (j > i) ret = reason.substring(i + 1, j);
					}
					if (ret == null) ret = reason;
					break;
				}
			}
		}
		return ret;
	}
}
