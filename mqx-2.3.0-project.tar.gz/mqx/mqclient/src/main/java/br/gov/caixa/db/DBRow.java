package br.gov.caixa.db;

import java.sql.SQLException;
import java.util.Properties;

public class DBRow extends Properties
{
	private static final long serialVersionUID = 373660529174918902L;

	protected final DBReader reader;

	public DBRow(final DBReader reader)
	{
		if (reader == null) throw new NullPointerException("DBReader must not be null");
		this.reader = reader;
	}

	public void commit(final DBReaderArgument args) throws SQLException { reader.setDone(this, args); }
}
