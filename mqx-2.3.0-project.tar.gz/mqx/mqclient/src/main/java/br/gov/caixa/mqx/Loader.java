package br.gov.caixa.mqx;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;


public class Loader
{
	private static Map<String, String> loaded = new HashMap<>();
	private static String ERROR_SO_NOT_FOUND = "Library not found: ";
	private static String ERROR_SO_NOT_SUPPORTED = "Operational System not supported: ";
	private static String ERROR_ARCH_NOT_SUPPORTED = "Architeture not supported: ";
	private static String ERROR_LOAD_SO = "Error while loading: ";

	private static String search(String libName, String path, String separator)
	{
		String ret = null;
		String[] items = path.split(separator);
		int i = 0;
		while (ret == null && i < items.length)
		{
			File parent = new File(items[i]);
			if (parent.isDirectory())
			{
				File target = new File(parent, libName);
				if (target.isFile()) ret = target.getAbsolutePath();
			}
			i++;
		}
		return ret;
	}
	public static synchronized String load(String libID, Map<String,Map<String, String>> resource, Class<?> at, String systemOverride)
	{
		File libFile = null;
		try
		{
			String name = null;
			if(loaded.get(libID) != null) return loaded.get(libID);
			if(System.getProperty(systemOverride) != null)
			{
				libFile = new File(System.getProperty(systemOverride));
				name = libFile.getAbsolutePath();
				System.load(name);
				loaded.put(libID, name);
				return name;
			}

			String os = System.getProperty("os.name");
			Map<String, String> archMap = resource.get(os);
			if(archMap ==null) 
			{
				for(String ospat : resource.keySet())
				{
					if(Pattern.matches(ospat, os))
					{
						archMap = resource.get(ospat);
						break;
					}
				}
			}
			if(archMap ==null) throw new UnsatisfiedLinkError(ERROR_SO_NOT_SUPPORTED);
			String lib = archMap.get(System.getProperty("os.arch"));
			if(lib == null) throw new UnsatisfiedLinkError(ERROR_ARCH_NOT_SUPPORTED);
			String sep = os.equalsIgnoreCase("Linux") ? ":" : ";";
			String libname = search(lib, System.getProperty("java.class.path"), sep);
			if (libname == null)
			{
				File target = new File(System.getenv("MQX_DIST"), "libmqx.so");
				if (target.isFile()) libname = target.getAbsolutePath();
			}
			if (libname == null) throw new UnsatisfiedLinkError(ERROR_SO_NOT_FOUND);
			System.load(libname);
			loaded.put(libID, libname);
			return libname;
		}
		catch (final Throwable f)
		{
			try
			{
				System.loadLibrary(libID); 
				loaded.put(libID, libID);
				return libID;
			}
			catch(Throwable e)
			{
				UnsatisfiedLinkError g = new UnsatisfiedLinkError(ERROR_LOAD_SO + e.getMessage() + " ==> after ==> " + f.getMessage());
				g.initCause(f);
				throw g;
			}
		}
	}

/*
FROM: http://lopica.sourceforge.net/os.html 

os.name			os.version		os.arch
Linux			2.0.31			x86
Linux			(*)				i386
Linux			(*)				x86_64
Linux			(*)				sparc
Linux			(*)				ppc	
Linux			(*)				armv41	
Linux			(*)				i686	
Linux			(*)				ppc64	
Mac OS			7.5.1			PowerPC	
Mac OS			8.1				PowerPC	
Mac OS			9.0, 9.2.2		PowerPC
Mac OS X		10.1.3			ppc
Mac OS X		10.2.6			ppc
Mac OS X		10.2.8			ppc
Mac OS X		10.3.1-4		ppc
Mac OS X		10.3.8			ppc
Windows 95		4.0				x86
Windows 98		4.10			x86
Windows Me		4.90			x86
Windows NT		4.0				x86
Windows 2000	5.0				x86
Windows XP		5.1				x86
Windows 2003	5.2				x86
Windows CE		3.0 build 11171	arm
Windows 8						x86  => manual, 8.1 also says something like this
OS/2			20.40			x86	
Solaris			2.x				sparc
SunOS			5.7				sparc
SunOS			5.8				sparc
SunOS			5.9				sparc
MPE/iX			C.55.00			PA-RISC
HP-UX			B.10.20			PA-RISC
HP-UX			B.11.00			PA-RISC
HP-UX			B.11.11			PA-RISC
HP-UX			B.11.11			PA_RISC
HP-UX			B.11.00			PA_RISC
HP-UX			B.11.23			IA64N
HP-UX			B.11.11			PA_RISC2.0
HP-UX			B.11.11			PA_RISC
HP-UX			B.11.11			PA-RISC
AIX				5.2				ppc64
AIX				4.3				Power
AIX				4.1				POWER_RS	
OS/390			390				02.10.00
FreeBSD			2.2.2-RELEASE	x86
Irix			6.3				mips
Digital Unix	4.0				alpha
NetWare 4.11	4.11			x86	
OSF1			V5.1			alpha
OpenVMS			V7.2-1			alpha

*/

	public static void main(String[] args)
	{
		File target = new File(System.getenv("MQX_DIST"), "libmqx.so");
		if (target.isFile()) 
		{
			String libname = target.getAbsolutePath();
			System.out.println(libname);
		}
	}

}