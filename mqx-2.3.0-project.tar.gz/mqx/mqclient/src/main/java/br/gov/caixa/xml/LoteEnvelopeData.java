package br.gov.caixa.xml;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.SequenceInputStream;
import java.nio.charset.StandardCharsets;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

import br.gov.caixa.BufferedStringWriter;
import br.gov.caixa.xml.XMLFragmentReader;

public class LoteEnvelopeData {


	private static final String TP_INSC = "tpInsc";
	private static final String NR_INSC = "nrInsc";
	private static final byte[] XML_INSTRUCTION = XMLFragmentReader.XML_INSTRUCTION.getBytes(StandardCharsets.UTF_8);


	private enum DocParts
	{
        Start(0, ""),
		StartDocument(0, ""),
		StartRoot(1, "eSocial"),
		StartBatch(2, "envioLoteEventos"),
        StartEmpregador(3, "ideEmpregador"),
		StartTransmissor(3, "ideTransmissor");
		

		private final int level;
		private final String tag;
		private DocParts(int level, String tag) { this.level = level; this.tag = tag; }
		private int getLevel() { return level; }
		private String getTag() { return tag; }
    }

    private String tpInscEmpregador;
    private String nrInscEmpregador;
    private String tpInscTransmissor;
    private String nrInscTransmissor;



    public LoteEnvelopeData(byte[] xml) throws XMLStreamException
    {
        final InputStreamReader read = new InputStreamReader(new SequenceInputStream(new ByteArrayInputStream(XML_INSTRUCTION),new ByteArrayInputStream(xml)), StandardCharsets.UTF_8);
		parse(factory().createXMLEventReader(read), 64);
    }

	private void parse(final XMLEventReader reader, final int buffSize) throws XMLStreamException
	{
		final BufferedStringWriter writer = new BufferedStringWriter(buffSize);
		int level = -1;
		DocParts state = DocParts.Start;
		boolean end = false;
		try
		{
			while (!end && reader.hasNext())
			{
				final XMLEvent e = reader.nextEvent();
				switch (state)
				{
				case Start:
					if (!e.isStartDocument()) throw new XMLStreamException("Malformed XML document");
					level++;
					state = DocParts.StartDocument;
					break;
				case StartDocument:
					if (e.isStartElement())
					{
						if (DocParts.StartRoot.getTag().equals(e.asStartElement().getName().getLocalPart()))
						{
							level++;
							state = DocParts.StartRoot;
						}
						else throw new XMLStreamException("Document root element not found");
					}
					break;
				case StartRoot:
					if (e.isStartElement())
					{
						if (DocParts.StartBatch.getTag().equals(e.asStartElement().getName().getLocalPart()))
						{
							level++;
							state = DocParts.StartBatch;
						}
						else throw new XMLStreamException("Document element not found");
					}
					break;
				case StartBatch:
					if (e.isStartElement())
					{
						String part = e.asStartElement().getName().getLocalPart();
						if(DocParts.StartEmpregador.getTag().equals(part))
						{
							state = DocParts.StartEmpregador;
						}	
						else if(DocParts.StartTransmissor.getTag().equals(part)){
							state = DocParts.StartTransmissor;
						}
						level++;
					}
					else if (e.isEndElement()) level--;
					break;
				case StartTransmissor:
				case StartEmpregador:
					if(e.isCharacters())
					{
						e.writeAsEncodedUnicode(writer);
					}
					else if (e.isStartElement())
					{
						level++;
					}
					else if(e.isEndElement())
					{
						String part = e.asEndElement().getName().getLocalPart();
						if (TP_INSC.equals(part))
						{
							if(state == DocParts.StartTransmissor) tpInscTransmissor = writer.toString();
							else tpInscEmpregador = writer.toString();
						}
						else if(NR_INSC.equals(part))
						{
							if(state == DocParts.StartTransmissor) nrInscTransmissor = writer.toString();
							else nrInscEmpregador = writer.toString();
						}
						writer.close();
						level--;
						if(level == DocParts.StartBatch.getLevel())
						{
							if(state == DocParts.StartEmpregador){state = DocParts.StartBatch;}
							else{end = true;}
							continue;
						}
					}
					break;
				default:
				}
			}
		}
		finally { reader.close(); }
    }

	private static XMLInputFactory factory()
	{
		final XMLInputFactory xmlf = XMLInputFactory.newInstance();
		xmlf.setProperty(XMLInputFactory.IS_COALESCING, true);
		xmlf.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, false);
		xmlf.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
		return xmlf;
	}

	public String getTpInscEmpregador() {
		return tpInscEmpregador;
	}
	public String getNrInscEmpregador() {
		return nrInscEmpregador;
	}
	public String getTpInscTransmissor() {
		return tpInscTransmissor;
	}
	public String getNrInscTransmissor() {
		return nrInscTransmissor;
	}
}