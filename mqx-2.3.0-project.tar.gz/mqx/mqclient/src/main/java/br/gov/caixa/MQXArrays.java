package br.gov.caixa;

import java.nio.charset.StandardCharsets;


public class MQXArrays
{
	public static int match(final byte[] source, final byte[] key)
	{
		return match(source, 0, source.length - 1, key);
	}
	public static int match(final byte[] source, final int srcStart, final int srcEnd, final byte[] key)
	{
		return match(source, srcStart, srcEnd, key, 0, key.length - 1);
	}
	public static int match(final byte[] source, final int srcStart, final int srcEnd, final byte[] key, final int keyStart, final int keyEnd)
	{
		if (source == null || key == null) throw new NullPointerException();
		if (srcEnd >= source.length || keyEnd >= key.length || srcStart < 0 || keyStart < 0) throw new IllegalArgumentException();
		int srcLen = srcEnd - srcStart + 1;
		int keyLen = keyEnd - keyStart + 1;
		if (srcLen < 1 || keyLen < 1) throw new IllegalArgumentException();
		if (keyLen > srcLen) return -1;

		int srcOffset = srcStart;
		while (srcOffset <= srcEnd)
		{
			int keyOffset = keyStart;
			while(srcOffset <= srcEnd && source[srcOffset] != key[keyOffset] ) srcOffset++;
			while(srcOffset <= srcEnd && keyOffset <= keyEnd && source[srcOffset] == key[keyOffset])
			{
				srcOffset++;
				keyOffset++;
			}
			if (keyOffset == keyStart + keyLen) return srcOffset - keyOffset + keyStart ;
			srcOffset = srcOffset - (keyOffset - keyStart) + 1;
		}
		return -1;
	}

	public static void main(String[] args)
	{
		String src = "aaabcsdlfgklsdfj";
		
		String[] test =  {
				"abc",
				"sdl",
				"dfj",
				"fj",
				"aa",
				"bca"
		};
		
		
		for(String key : test)
		{
			int posindex = src.indexOf(key);
			int posmatch = match(src.getBytes(StandardCharsets.UTF_8), key.getBytes(StandardCharsets.UTF_8));
			System.out.println("====================================");
			System.out.println("Key:["+ key+ "] in [" + src + "]");
			System.out.print("String.indexOf: " + posindex + " == ");
			if(posindex >= 0) System.out.println("[" + src.substring(posindex, posindex+key.length()) +  "]");
			else System.out.println("Not Found!");
			System.out.print("Arrays.match  : " + posmatch + " == ");			
			if(posmatch >= 0) System.out.println("[" + src.substring(posmatch, posmatch+key.length()) +  "]");
			else System.out.println("Not Found!");
		}
		System.out.println("====================================");
		
		int newpos = src.length();
		src = src + src;
		for(String key : test)
		{
			int posindex = src.indexOf(key, newpos);
			int posmatch = match(src.getBytes(StandardCharsets.UTF_8), newpos, src.length() -1, key.getBytes(StandardCharsets.UTF_8));
			System.out.println("====================================");
			System.out.println("Key:["+ key+ "] in [" + src + "]");
			System.out.print("String.indexOf: " + posindex + " == ");
			if(posindex >= 0) System.out.println("[" + src.substring(posindex, posindex+key.length()) +  "]");
			else System.out.println("Not Found!");
			System.out.print("Arrays.match  : " + posmatch + " == ");			
			if(posmatch >= 0) System.out.println("[" + src.substring(posmatch, posmatch+key.length()) +  "]");
			else System.out.println("Not Found!");
		}
		System.out.println("====================================");
		
		
		for(String key : test)
		{
			int newkeypos = key.length();
			String newkey = key + key;
			int posindex = src.indexOf(key, newpos);
			int posmatch = match(src.getBytes(StandardCharsets.UTF_8), newpos, src.length() -1, newkey.getBytes(StandardCharsets.UTF_8), newkeypos, newkey.length() -1);
			System.out.println("====================================");
			System.out.println("Key:["+ newkey+ "] in [" + src + "]");
			System.out.print("String.indexOf: " + posindex + " == ");
			if(posindex >= 0) System.out.println("[" + src.substring(posindex, posindex+newkey.length() - newkeypos) +  "]");
			else System.out.println("Not Found!");
			System.out.print("Arrays.match  : " + posmatch + " == ");			
			if(posmatch >= 0) System.out.println("[" + src.substring(posmatch, posmatch+newkey.length()- newkeypos) +  "]");
			else System.out.println("Not Found!");
		}
		System.out.println("====================================");
		
		
	}
	
}
