package br.gov.caixa.ws.server;

public interface WebServiceMBean
{
	boolean isHealthy();
	long success();
	long failure();
}
