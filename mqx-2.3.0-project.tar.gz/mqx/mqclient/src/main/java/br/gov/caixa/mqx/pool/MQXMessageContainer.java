package br.gov.caixa.mqx.pool;

import org.crypthing.things.messaging.MQXMessage;

class MQXMessageContainer
{
	final MQXMessage in;
	MQXMessage out;
	Throwable exception;
	MQXMessageContainer(final MQXMessage in) { this.in = in; }
}
