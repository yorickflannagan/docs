package br.gov.caixa.ws.server;

import java.io.IOException;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.security.Principal;
import java.util.Properties;

import javax.servlet.http.HttpServletResponse;
import javax.xml.soap.SOAPException;

import org.crypthing.things.snmp.ProcessingEventListener;

import br.gov.caixa.soap.SOAPEnvelope;
import br.gov.caixa.ws.WSMethods;

public abstract class ServiceHandler implements Serializable
{
	private static final long serialVersionUID = -3483712529476301276L;
	private WSMethods service;
	private byte[] wsdl;

	WSMethods getService() { return service; }
	void setService(final WSMethods service) { this.service = service; }
	byte[] getWsdl() { return wsdl; }
	void setWsdl(final byte[] wsdl) { this.wsdl = wsdl; }
	void writeWSDLTo(final HttpServletResponse response) throws IOException
	{
		response.setStatus(HttpURLConnection.HTTP_OK);
		response.setContentType("text/xml;charset=UTF-8");
		response.getOutputStream().write(wsdl);
	}

	void writeResponseTo(final HttpServletResponse response, final SOAPEnvelope ret) throws IOException
	{
		response.setStatus(HttpURLConnection.HTTP_OK);
		if (ret.getName() != null)
		{
			response.setContentType("text/xml;charset=UTF-8");
			ret.writeTo(response.getWriter());
		}
	}

	public abstract void init(ProcessingEventListener listener, Properties config);
	public abstract void destroy();
	public abstract void invoke(SOAPEnvelope call, SOAPEnvelope response, Principal credentials) throws SOAPException;
}
