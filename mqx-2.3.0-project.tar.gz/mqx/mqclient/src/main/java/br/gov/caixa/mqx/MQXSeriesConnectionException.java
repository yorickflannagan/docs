package br.gov.caixa.mqx;

import org.crypthing.things.messaging.MQXConnectionException;

public class MQXSeriesConnectionException extends MQXConnectionException
{
	private static final long serialVersionUID = -730021099248988325L;
	int _reason;
	public MQXSeriesConnectionException(String message) { super(message); }
	public MQXSeriesConnectionException(Throwable cause) { super(cause);  }
	public MQXSeriesConnectionException(String message, Throwable cause) { super(message, cause); }
	public MQXSeriesConnectionException(String message, int reason) { this(message, null, reason); }
	public MQXSeriesConnectionException(String message, Throwable cause, int reason)
	{
		super(message + "; reason code=" + reason, cause);
		_reason = reason;
	}
	public int getReason() { return _reason; }
}
