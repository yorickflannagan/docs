package br.gov.caixa.mqx.pool;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class LenientLimitedDeque<E> extends LinkedBlockingDeque<E>
{
	private static final long serialVersionUID = -6395971474990591580L;
	protected final int maxWaterlevel;
	protected int waterlevel = 0;
	public LenientLimitedDeque(final int maxWaterlevel) { this.maxWaterlevel = maxWaterlevel; }
	public void decrementWaterLevel()
	{
		final ReentrantLock lock = this.lock;
		lock.lock();
		try { waterlevel--; }
		finally { lock.unlock(); }
	}
	public void incrementWaterLevel()
	{
		final ReentrantLock lock = this.lock;
		lock.lock();
		try { waterlevel++; }
		finally { lock.unlock(); }
	}
	public boolean isFull()
	{
		final ReentrantLock lock = this.lock;
		lock.lock();
		try { return waterlevel >= maxWaterlevel; }
		finally { lock.unlock(); }
	}
	public E borrow(final long timeout)
	{
		long nanos = TimeUnit.MILLISECONDS.toNanos(timeout);
		final ReentrantLock lock = this.lock;
		try
		{
			lock.lockInterruptibly();
			try
			{
				E x;
				while ((x = unlinkFirst()) == null)
				{
					if (nanos <= 0) return null;
					nanos = notEmpty.awaitNanos(nanos);
				}
				return x;
			}
			finally { lock.unlock(); }
		}
		catch (final InterruptedException e) { return null; }
	}
	public void giveBack(final E e)
	{
		if (e == null) throw new NullPointerException();
		final Node<E> node = new Node<E>(e);
		final ReentrantLock lock = this.lock;
		lock.lock();
		try { linkLast(node); }
		finally { lock.unlock(); }
	}
	protected boolean giveBackWithoutOverflow(final E e)
	{
		boolean ret = false;
		if (e == null) throw new NullPointerException();
		final ReentrantLock lock = this.lock;
		lock.lock();
		try
		{
			if (count < maxWaterlevel)
			{
				final Node<E> node = new Node<E>(e);
				linkLast(node);
				ret = true;
			}
		}
		finally { lock.unlock(); }
		return ret;
	}
}
