package br.gov.caixa.ws;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.crypthing.things.appservice.config.ConfigProperties;
import org.crypthing.things.appservice.config.Property;
import org.crypthing.things.config.Config;
import org.crypthing.things.config.ConfigException;
import org.crypthing.things.config.Converter;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import br.gov.caixa.soap.SOAPElement;
import br.gov.caixa.soap.SOAPEnvelope;

public final class WSMethods
{
	private String wsdlLocation;
	private String wsdlUri;
	private String implementation;
	private ConfigProperties properties;
	private final Map<String, WSSignature> methods = new HashMap<String, WSSignature>();
	public String getWsdlLocation() { return wsdlLocation; }
	public void setWsdlLocation(final String wsdlLocation) { this.wsdlLocation = wsdlLocation; }
	public String getWsdlUri() { return wsdlUri; }
	public void setWsdlUri(final String wsdlUri) { this.wsdlUri = wsdlUri; }
	public String getImplementation() { return implementation; }
	public void setImplementation(final String implementation) { this.implementation = implementation; }
	public Properties getProperties() { return properties; }
	public void setProperties(final ConfigProperties properties) { this.properties = properties; }
	public void add(final WSSignature method) { methods.put(method.getWebMethod().getName(), method); }
	public WSSignature getMethod(final String name) { return methods.get(name); }
	public void validate() throws WSConfigException
	{
		if ( wsdlLocation == null || wsdlUri == null || implementation == null ) throw new WSConfigException("Invalid WebService configuration");
		for (final WSSignature sig : methods.values()) sig.validate();
	}
	public Collection<WSSignature> getMethods() { return methods.values(); }
	@Override
	public String toString()
	{
		final StringBuilder builder = new StringBuilder(512);
		builder.append("WSMethods=\n{\n");
		for (final WSSignature sig : methods.values()) builder.append(sig.toString());
		return builder.append("}").toString();
	}

	public static WSMethods getServiceConfig(final String entry, final boolean absolute) throws WSConfigException
	{
		if (entry == null) throw new WSConfigException("Service configuration file name must not be null");
		InputStream cfgFile = null;
		if (absolute)
		{
			try { cfgFile = new FileInputStream(entry); }
			catch (final FileNotFoundException e) { throw new WSConfigException("Service configuration file not found " + entry, e); }
		}
		else cfgFile = Thread.currentThread().getContextClassLoader().getResourceAsStream(entry);
		
		if (cfgFile == null) throw new WSConfigException("Service configuration file not found " + entry);
		WSMethods ret = null;
		try
		{
			final Config cfg = new Config(cfgFile, WSMethods.class.getResourceAsStream("methods.xsd"));
			final Node n = cfg.getNodeValue("service-config");
			ret = new WSMethods();
			ret.setImplementation(cfg.getValue("./implementation", n));
			ret.setWsdlLocation(cfg.getValue("./wsdl-location", n));
			ret.setWsdlUri(cfg.getValue("./wsdl-uri", n));

			final Node m = cfg.getNodeValue("./web-methods", n);
			final Iterator<WSSignature> it = cfg.getValueCollection("./web-method", m, new Converter<WSSignature>()
			{
				@Override
				public WSSignature convert(Object value) throws ClassCastException
				{
					try { 
						return new WSSignature(cfg, (Node) value); 
					}
					catch (final ConfigException e) { throw (ClassCastException)(new ClassCastException(e.getMessage())).initCause(e); }
				}
				
			}).iterator();
			while (it.hasNext())ret.add(it.next());
			final Node n2 = cfg.getNodeValue("properties", n);
			ret.setProperties(new ConfigProperties(cfg,n2));
		}
		catch (final ConfigException e) { throw new WSConfigException("Service configuration file parsing error", e); }
		ret.validate();
		return ret;
	}
	public static WSMethods getServiceConfig(final String entry) throws WSConfigException { return getServiceConfig(entry, false); }

	public static void main(String[] args) throws Exception
	{
		WSMethods me = WSMethods.getServiceConfig("./docs/xml/sincronizar-lote.xml", true);
		System.out.println(me);

	}

}
