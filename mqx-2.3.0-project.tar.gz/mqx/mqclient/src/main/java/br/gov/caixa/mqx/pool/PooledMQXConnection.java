package br.gov.caixa.mqx.pool;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Logger;

import javax.naming.InitialContext;
import javax.naming.NameNotFoundException;

import org.crypthing.things.appservice.Bootstrap;
import org.crypthing.things.appservice.config.ConnectorConfig;
import org.crypthing.things.appservice.config.QueueConfig;
import org.crypthing.things.appservice.config.RunnerConfig;
import org.crypthing.things.config.Config;
import org.crypthing.things.snmp.EncodableString;
import org.crypthing.things.snmp.LifecycleEvent;
import org.crypthing.things.snmp.LogTrapperListener;
import org.crypthing.things.snmp.LifecycleEvent.LifecycleEventType;
import org.crypthing.things.snmp.ProcessingEvent;
import org.crypthing.things.snmp.SNMPBridge;
import org.crypthing.things.snmp.ProcessingEvent.ProcessingEventType;
import org.crypthing.things.messaging.MQXConnection;
import org.crypthing.things.messaging.MQXConnectionException;
import org.crypthing.things.messaging.MQXException;
import org.crypthing.things.messaging.MQXIllegalArgumentException;
import org.crypthing.things.messaging.MQXIllegalStateException;
import org.crypthing.things.messaging.MQXMessage;
import org.crypthing.things.messaging.MQXQueue;

public final class PooledMQXConnection implements MQXConnection, Controllable
{

	
	private static final Map<String, PooledMQXConnection> connections;
	static
	{
		try
		{
			final InitialContext ctx = new InitialContext();
			String config = null;
			try { config =  (String) ctx.lookup("java:global/MQXConnectors"); }
			catch (final NameNotFoundException tryagain) { config = System.getProperty("br.gov.caixa.mqx.pool.MQXConnectors"); }
			InputStream schema = Bootstrap.getSchema();
			
			final RunnerConfig cfg = new RunnerConfig(new Config(new FileInputStream(new File(config)), schema));
			connections = new ConcurrentHashMap<String, PooledMQXConnection>();
			Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() { @Override public void run() { destroy(); }}));
			final Properties snmpCfg = cfg.getSnmp();
			final Iterator<ConnectorConfig> items = cfg.getConnectors().values().iterator();
			while (items.hasNext())
			{
				final ConnectorConfig it = items.next();
				final String name = it.getName();
				if (!connections.containsKey(name)) connections.put(name, new PooledMQXConnection(it, snmpCfg));
			}

		}
		catch (final Throwable e)
		{
			throw new RuntimeException(e);
		}
	}
	static synchronized void destroy()
	{
		final Iterator<PooledMQXConnection> items = connections.values().iterator();
		while (items.hasNext()) items.next().stop();
		connections.clear();
	}
	static MQXConnection getInstance(final String cName) throws MQXIllegalArgumentException
	{
		final PooledMQXConnection ret = connections.get(cName);
		if (ret == null) throw new MQXIllegalArgumentException("Unknown connection name " + cName);
		return ret;
	}


	private final Map<String, ImplementationContainer> workers = new ConcurrentHashMap<String, ImplementationContainer>();
	private final ConnectorConfig config;
	final LogTrapperListener trapper;
	private PooledMQXConnection(final ConnectorConfig config, final Properties snmpCfg) throws IOException
	{
		SNMPBridge bridge = null;
		if (snmpCfg != null) {
			bridge = SNMPBridge.newInstance(
							snmpCfg.getProperty("org.crypthing.things.SNMPTrap","org.crypthing.things.snmp.SNMPTrap"),
							snmpCfg.getProperty("org.crypthing.things.batch.udpAddress", "127.0.0.1/6333"),
							snmpCfg.getProperty("org.crypthing.things.batch.rootOID", "0.5.1.17.1")
					);
		}
		trapper = new LogTrapperListener(Logger.getLogger(PooledMQXConnection.class.getName()), bridge);
		this.config = config;
	}


	@Override public boolean isRunning() { return (workers.size() > 0); }
	@Override
	public void stop()
	{
		trapper.start(new LifecycleEvent(LifecycleEventType.start, new EncodableString("PooledMQXConnection instance stopping...")));
		final Iterator<ImplementationContainer> items = workers.values().iterator();
		while (items.hasNext()) items.next().implementation.stop();
		workers.clear();
	}
	@Override
	public int getOkCounter()
	{
		int counter = 0;
		final Iterator<ImplementationContainer> items = workers.values().iterator();
		while (items.hasNext()) counter += items.next().implementation.getOkCounter();
		return counter;
	}
	@Override
	public int getFailCounter()
	{
		int counter = 0;
		final Iterator<ImplementationContainer> items = workers.values().iterator();
		while (items.hasNext()) counter += items.next().implementation.getFailCounter();
		return counter;
	}
	
	@Override
	public MQXQueue openQueue(String name) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException
	{
		if (config.get(name) == null) throw new MQXIllegalArgumentException("Unknown queue name " + name);
		ImplementationContainer container = workers.get(name);
		try
		{
			if (container == null) container = newContainer(name);
			if (container.input) return new InputMQXQueue(config, name, (MQXPool) container.implementation);
			if (!((MQXSender) container.implementation).isRunning()) container = newContainer(name);
			return new OutputMQXQueue(config, name, ((MQXSender) container.implementation).getQueue());
		}
		catch (final MQXException e) { throw new MQXConnectionException("Could not instantiate MQX implementation", e); }
	}
	private ImplementationContainer newContainer(final String qName) throws MQXException
	{
		ImplementationContainer ret = null;
		final QueueConfig queue = config.get(qName);
		if (!Boolean.parseBoolean(queue.getProperty("br.gov.caixa.mqx.input")))
		{
			final MQXSender sender = new MQXSender(config, queue.getName(), new LinkedBlockingQueue<MQXMessageContainer>(), trapper);
			final Thread t = new Thread(sender);
			t.setDaemon(true);
			t.start();
			ret = new ImplementationContainer(false, sender);
		}
		else
		{
			int size = 5;
			try { size = Integer.parseInt(queue.getProperty("br.gov.caixa.mqx.pool.size", "5")); }
			catch (final NumberFormatException e) {}
			ret = new  ImplementationContainer(true, new MQXPool(size));
		}
		workers.put(qName, ret);
		return ret;
	}
	@Override
	public MQXMessage call(final String putQueue, final String getQueue, final MQXMessage msg) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException
	{
		if (msg == null || msg.getMessage() == null) throw new MQXIllegalArgumentException("Request message must not be null");
		final MQXQueue out = openQueue(putQueue);
		if (!(out instanceof OutputMQXQueue)) throw new MQXIllegalArgumentException(putQueue + " must be an output queue");
		final MQXQueue in = openQueue(getQueue);
		if (!(in instanceof InputMQXQueue)) throw new MQXIllegalArgumentException(getQueue + " must be an input queue");
		final MQXMessage fMsg = out.send(msg);
		fMsg.setCorrelId(fMsg.getMsgId());
		fMsg.setMsgId(null);
		fMsg.setMessage(null);
		return in.receive(fMsg);
	}

	@Override public boolean isValid() { return true; }
	@Override public void close() throws MQXIllegalStateException, MQXConnectionException {}
	@Override public void initConnection(Properties props) throws MQXIllegalArgumentException { throw new UnsupportedOperationException(); }
	@Override public MQXQueue openQueue(Properties props) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException { throw new UnsupportedOperationException();}
	@Override public void begin() throws MQXConnectionException { throw new UnsupportedOperationException(); }
	@Override public void commit() throws MQXConnectionException { throw new UnsupportedOperationException(); }
	@Override public void back() throws MQXConnectionException { throw new UnsupportedOperationException(); }
	@Override public boolean isTransaction() { throw new UnsupportedOperationException();  }


	public class InputMQXQueue implements MQXQueue
	{
		private final ConnectorConfig config;
		private final QueueConfig qConfig;
		private final MQXPool pool;
		private final int pTimeout;
		private final int getTimeout;
		private InputMQXQueue(final ConnectorConfig config, final String qName, final MQXPool pool) throws MQXException
		{
			this.config = config;
			this.pool = pool;
			if ((qConfig = config.get(qName)) == null) throw new MQXException("Invalid configuration for queue name " + qName);
			try
			{
				pTimeout = Integer.parseInt(qConfig.getProperty("br.gov.caixa.mqx.pool.timeout", "4000"));
				getTimeout = Integer.parseInt(qConfig.getProperty("br.gov.caixa.mqx.get.timeout", "4000"));
			}
			catch (final NumberFormatException e) { throw new MQXException("Invalid timeout configuration entry"); }
		}
		@Override public MQXMessage send(final MQXMessage msg) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException { throw new UnsupportedOperationException(); }
		@Override public MQXMessage send(MQXMessage msg, int expire) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException { throw new UnsupportedOperationException(); }
		@Override public void close() throws MQXIllegalStateException, MQXConnectionException {}
		@Override public MQXMessage receive(final MQXMessage msg) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException { return receive(msg, getTimeout); }
		@Override
		public MQXMessage receive(MQXMessage msg, int timeout) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException
		{
			final MQXReceiver receiver = getReceiver();
			if (receiver == null) throw new MQXConnectionException("Could not receive message because pool is full");
			if (timeout <= 0) throw new MQXIllegalArgumentException("Timeout must be greater than 0");
			try
			{
				final MQXMessageContainer container = new MQXMessageContainer(msg);
				synchronized (container)
				{
					receiver.get(container);
					if (container.out == null && container.exception == null)
					{
						try { container.wait(timeout); }
						catch (final InterruptedException e) { throw new MQXIllegalStateException(e); }
					}
				}
				if (container.exception != null) throw new MQXConnectionException("Could not receive message due to following error", container.exception);
				if (container.out == null) throw new MQXIllegalStateException("Could not receive message due to thread timeout");
				return container.out;
			}
			finally { pool.giveBack(receiver); }
		}
		private MQXReceiver getReceiver() throws MQXIllegalStateException
		{
			MQXReceiver ret = null;
			try
			{
				if(pool.size() != 0) ret = pool.borrow(pTimeout);
				if (ret == null)
				{
					if (pool.isFull()) trapper.warning(new ProcessingEvent(ProcessingEventType.warning, "MQX receiving pool overflow"));
					ret = newReceiver();
					pool.incrementWaterLevel();
				}
				else if (!ret.isRunning()) ret = newReceiver();
			}
			catch (final MQXException e) { throw new MQXIllegalStateException(e); }
			return ret;
		}
		private MQXReceiver newReceiver() throws MQXException
		{
			final MQXReceiver ret = new MQXReceiver(config, qConfig.getName(), trapper);
			final Thread t = new Thread(ret);
			t.setDaemon(true);
			t.start();
			return ret;
		}
	}


	public class OutputMQXQueue implements MQXQueue
	{
		private final int expiry;
		private final int timeout;
		private final LinkedBlockingQueue<MQXMessageContainer> queue;
		private OutputMQXQueue(final ConnectorConfig config, final String qName, final LinkedBlockingQueue<MQXMessageContainer> queue) throws MQXException
		{
			final QueueConfig cfg = config.get(qName);
			if (cfg == null) throw new MQXException("Configuration for queue not found for name " + qName);
			try
			{
				timeout = Integer.parseInt(cfg.getProperty("br.gov.caixa.mqx.put.timeout", "4000"));
				expiry = Integer.parseInt(cfg.getProperty("br.gov.caixa.mqx.put.expire", "0"));
			}
			catch (final NumberFormatException e) { throw new MQXException("Invalid integer configuration entry"); }
			this.queue = queue;
		}
		@Override public void close() throws MQXIllegalStateException, MQXConnectionException {}
		@Override public MQXMessage receive(MQXMessage msg) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException { throw new UnsupportedOperationException(); }
		@Override public MQXMessage receive(MQXMessage msg, int timeout) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException { throw new UnsupportedOperationException(); }
		@Override public MQXMessage send(final MQXMessage msg) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException { return send(msg, expiry); }
		@Override
		public MQXMessage send(final MQXMessage msg, final int expire) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException
		{
			if (msg == null) throw new MQXIllegalArgumentException("Message must not be null");
			final MQXMessageContainer container = new MQXMessageContainer(msg);
			if (!queue.offer(container)) throw new MQXConnectionException("Could not send message because internal queue failed");
			try { synchronized (container) { if (container.out == null) container.wait(timeout); } }
			catch (final InterruptedException e) { throw new MQXIllegalStateException("Could not send message due to following error", e); }
			if (container.exception != null) throw new MQXConnectionException("Could not send message due to following error", container.exception);
			if (container.out == null) throw new MQXConnectionException("Could not send message due to timeout");
			return container.out;
		}
	}


}
