package br.gov.caixa.db;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.locks.ReentrantLock;

public final class SingletonCursor implements Serializable
{
	private static SingletonCursor instance = null;
	private static int refCount = 0;

	public static synchronized void init(final DBReader reader) throws SQLException
	{
		if (instance == null) instance = new SingletonCursor(reader);
		refCount++;
	}
	public static synchronized void release() { 
		if (instance != null && (--refCount) == 0) {instance.free();}
	}

	public static SingletonCursor getInstance()
	{
		if (instance == null) throw new IllegalStateException("SingletonCursor was not initialized");
		return instance;
	}

	private static final long serialVersionUID = -164630985417149988L;

	private final ReentrantLock mutex = new ReentrantLock();
	private final DBReader reader;

	private ResultSet result = null;
	private boolean mustRefresh = true;

	private SingletonCursor(final DBReader reader) throws SQLException {
		if (reader == null) throw new NullPointerException("DBReader must not be null");
		this.reader = reader;
		this.reader.setMutex(mutex);
		refresh();
	}

	public void refresh() throws SQLException
	{
		final ReentrantLock _mutex = this.mutex;
		_mutex.lock();
		try {
			if (mustRefresh)
			{
				if (result != null) result.close();
				result = reader.readCursor();
				mustRefresh = false;
			}
		}
		finally { _mutex.unlock(); }
	}

	public DBRow next() throws SQLException
	{
		final ReentrantLock _mutex = this.mutex;
		_mutex.lock();
		DBRow row = null;
		try {
			if (mustRefresh) return row;
			if (!result.isClosed() && result.next()) row = reader.readRow(result);
			else mustRefresh = true;
		}
		finally { _mutex.unlock(); }
		return row;
	}

	private void free() { reader.release(); }
}
