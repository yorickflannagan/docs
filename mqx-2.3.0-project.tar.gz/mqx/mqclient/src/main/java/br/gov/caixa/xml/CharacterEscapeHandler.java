package br.gov.caixa.xml;

import java.io.IOException;
import java.io.Serializable;
import java.io.Writer;

public final class CharacterEscapeHandler implements Serializable
{
	private static final long serialVersionUID = -6006980130926203722L;
	private final boolean isStrict;
	public CharacterEscapeHandler() { this(false); }
	public CharacterEscapeHandler(final boolean strict) { isStrict = strict; }

	public void escape(final char[] ch, final int offset, final int length, final Writer out) throws IOException
	{
		int limit = offset + length;
		for (int i = offset; i < limit; i++)
		{
			switch (ch[i])
			{
			case '&':
				out.write("&amp;");
				break;
			case '<':
				out.write("&lt;");
				break;
			case '>':
				out.write("&gt;");
				break;
			case '"':
				out.write("&quot;");
				break;
			case '\'':
				if (!isStrict) out.write("&#39;");
				break;
			default:
				out.write(ch[i]);
			}
		}
	}
}
