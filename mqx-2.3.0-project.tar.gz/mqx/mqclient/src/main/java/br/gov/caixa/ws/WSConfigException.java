package br.gov.caixa.ws;

public final class WSConfigException extends Exception
{
	private static final long serialVersionUID = 7966123194569206196L;
	public WSConfigException() {}
	public WSConfigException(String message) { super(message); }
	public WSConfigException(Throwable cause) { super(cause); }
	public WSConfigException(String message, Throwable cause) { super(message, cause); }
}
