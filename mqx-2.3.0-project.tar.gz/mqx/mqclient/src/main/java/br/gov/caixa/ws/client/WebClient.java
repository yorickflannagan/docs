package br.gov.caixa.ws.client;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import javax.xml.soap.SOAPException;
import javax.xml.stream.XMLStreamException;

import br.gov.caixa.soap.SOAPElement;
import br.gov.caixa.soap.SOAPEnvelope;
import br.gov.caixa.soap.SOAPParser;
import br.gov.caixa.ws.WSSignature;

public final class WebClient
{
	private final WSSignature _bluePrint;
	private final URL _uri;
	public  WebClient(final String uri, final WSSignature bluePrint) throws MalformedURLException
	{
		if (bluePrint == null || uri == null) throw new NullPointerException("Arguments must not be null");
		_uri = new URL(uri);
		_bluePrint = bluePrint;
	}
	public SOAPEnvelope send(final String... arguments) throws SOAPException, IOException
	{
		final SOAPEnvelope call = newEnvelope();
		final List<SOAPElement> elems = call.getElements();
		if (arguments.length > elems.size()) throw new SOAPException("Too many arguments!");
		for (int i = 0; i < arguments.length; i++) { elems.get(i).setData(arguments[i]); }
		return send(call);
	}
	public SOAPEnvelope send(final SOAPEnvelope call) throws SOAPException, IOException
	{
		String action = "\"\"";
		SOAPEnvelope ret = null;
		final List<SOAPElement> elems = call.getElements();
		for (final SOAPElement e : elems) if (!e.isOptional() && e.getData() == null) throw new SOAPException("Argument is not optional: " + e.getName());
		final URLConnection conn = _uri.openConnection();
		if (!(conn instanceof HttpURLConnection)) throw new SOAPException("Unsupported SOAP transport protocol");
		((HttpURLConnection) conn).setRequestMethod("POST");
		conn.setDoOutput(true);
		conn.setRequestProperty("Accept", "text/xml, multipart/related");
		conn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
		if (_bluePrint.getSoapAction() != null) action = _bluePrint.getSoapAction();
		conn.setRequestProperty("SOAPAction", action);
		conn.setRequestProperty("User-Agent", "MQX 2.1.2");
		conn.setRequestProperty("Content-Length", Integer.toString(call.size()));
		final OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
		try
		{
			call.writeTo(writer);
			writer.flush();
			final InputStream response = conn.getInputStream();
			try
			{
				if (_bluePrint.getWebResponse().getElements().size() > 0)
				{
					final int size = conn.getContentLength();
					ret = SOAPParser.parseRequest(response, size == -1 ? 4096 : size);
//					final String namespace = _bluePrint.getWebMethod().getBodyNamespace();
//					if ((namespace != null && !namespace.equals(ret.getBodyNamespace())) || (namespace == null && ret.getBodyNamespace() != null)) throw new SOAPException("Unexpected response namespace: " + ret.getBodyNamespace());
				}
			}
			catch (final XMLStreamException e1) { throw new SOAPException("Malformed SOAP response", e1); }
			finally { response.close(); }
		}
		catch (final IOException e)
		{
			final InputStream err = ((HttpURLConnection) conn).getErrorStream();
			if (err != null && _bluePrint.getWebResponse().getName() != null)
			{
				try
				{
					throw new IOException(SOAPParser.parseRequest(err, conn.getContentLength() == -1 ? 2048 : conn.getContentLength()).faultToString(), e);
				}
				catch (final SOAPException e1) { throw new SOAPException(e1.getMessage(), e); }
				catch (final Exception e1) { throw new IOException(e1.getMessage(), e); }
			}
			throw e;
		}
		finally { writer.close(); }
		return ret;
	}
	public void sendForDebug(final SOAPEnvelope call, Writer writer) throws SOAPException, IOException
	{
		String action = "\"\"";
		final List<SOAPElement> elems = call.getElements();
		for (final SOAPElement e : elems) if (!e.isOptional() && e.getData() == null) throw new SOAPException("Argument is not optional: " + e.getName());
		writer.write("POST " + _uri.getQuery() + " HTTP/1.1\r\n");
		writer.write("Accept: text/xml, multipart/related\r\n");
		writer.write("Content-Type: text/xml; charset=utf-8\r\n");
		if (_bluePrint.getSoapAction() != null) action = _bluePrint.getSoapAction();
		writer.write("SOAPAction: " + action + "\r\n");
		writer.write("User-Agent: MQX 2.1.2\r\n");
		writer.write("Content-Length: " + Integer.toString(call.size()) + "\r\n");
		writer.write("\r\n");
		call.writeTo(writer);
		writer.flush();
	}
	public SOAPEnvelope newEnvelope() { return _bluePrint.getWebMethod().clone(); }

	public byte[] sendRaw(final SOAPEnvelope call) throws SOAPException, IOException
	{
		byte[] ret = {};
		String action = "\"\"";
		final List<SOAPElement> elems = call.getElements();
		for (final SOAPElement e : elems) if (!e.isOptional() && e.getData() == null) throw new SOAPException("Argument is not optional: " + e.getName());
		final URLConnection conn = _uri.openConnection();
		if (!(conn instanceof HttpURLConnection)) throw new SOAPException("Unsupported SOAP transport protocol");
		((HttpURLConnection) conn).setRequestMethod("POST");
		conn.setDoOutput(true);
		conn.setRequestProperty("Accept", "text/xml, multipart/related");
		conn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
		if (_bluePrint.getSoapAction() != null) action = _bluePrint.getSoapAction();
		conn.setRequestProperty("SOAPAction", action);
		conn.setRequestProperty("User-Agent", "MQX 2.1.2");
		conn.setRequestProperty("Content-Length", Integer.toString(call.size()));
		final OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
		try
		{
			call.writeTo(writer);
			writer.flush();
			final InputStream response = conn.getInputStream();
			try
			{
				final ByteArrayOutputStream out = new ByteArrayOutputStream();
				final byte[] buffer = new byte[1024];
				int read;
				while ((read = response.read(buffer)) > 0) out.write(buffer, 0, read);
				ret = out.toByteArray();
			}
			finally { response.close(); }
		}
		finally { writer.close(); }
		return ret;
	}
}
