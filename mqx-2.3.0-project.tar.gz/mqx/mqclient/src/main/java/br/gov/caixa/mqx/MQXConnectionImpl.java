package br.gov.caixa.mqx;

import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

import org.crypthing.things.messaging.MQXConnection;
import org.crypthing.things.messaging.MQXConnectionException;
import org.crypthing.things.messaging.MQXIllegalArgumentException;
import org.crypthing.things.messaging.MQXIllegalStateException;
import org.crypthing.things.messaging.MQXMessage;
import org.crypthing.things.messaging.MQXQueue;


public final class MQXConnectionImpl implements MQXConnection
{
	private void writeObject(ObjectOutputStream stream) throws IOException { throw new NotSerializableException(); }
	private void readObject(java.io.ObjectInputStream stream) throws IOException, ClassNotFoundException { throw new NotSerializableException(); }
	private void readObjectNoData() throws ObjectStreamException { throw new NotSerializableException(); }

	private static native int mqxNewConnection(String address, String channel, String manager, String userID, String password, MQResponse ret);
	private static native int mqxReleaseConnection(long hConn);
	private static native int mqxOpenQueue(long hConn, String queue, boolean input, boolean convert, boolean convertMsgId, boolean convertCorrelId, int maxMsgLen, MQResponse ret);
	private static native int mqxCloseQueue(long hConn, long hObj);
	private static native int mqxSend(long hConn, long hObj, byte[] msgId, byte[] correlId, byte[] msg, MQResponse ret);
	private static native int mqxSendExpire(long hConn, long hObj, int expire, byte[] msgId, byte[] correlId, byte[] msg, MQResponse ret);
	private static native int mqxReceive(long hConn, long hObj, byte[] msgId, byte[] correlId, int timeout, MQResponse ret);
	private static native int mqxBegin(long hConn);
	private static native int mqxCommit(long hConn);
	private static native int mqxBack(long hConn);
	private static native int mqxQueueDepth(long hConn, String queue, int[] depth);
	private static native boolean mqxIsTransaction(long hConn);

	static { 
		Map<String, Map<String,String>> resource = new HashMap<>();
		Map<String,String> windows = new HashMap<>();
		Map<String,String> linux = new HashMap<>();
		linux.put("x86_64", "libmqx.so");
		linux.put("amd64", "libmqx.so");
		windows.put("x86", "mqx.dll");
		resource.put("Windows.*", windows);
		resource.put("Linux", linux);
		Loader.load("mqx", resource, MQXConnectionImpl.class, "br.gov.caixa.mqx.Lib");	
	}

	private long hConn = 0;
	private boolean valid = true;
	private final Map<String, MQXQueueImpl> inputQueues = new ConcurrentHashMap<String, MQXQueueImpl>();
	private final Map<String, MQXQueueImpl> outputQueues = new ConcurrentHashMap<String, MQXQueueImpl>();
	private final ReentrantLock mutex = new ReentrantLock();

	@Override
	public boolean isTransaction()
	{
		if (hConn == 0) return false;
		return mqxIsTransaction(hConn);
	}

	private static final String MQX_NO_AUTH = "_*_*_*_*_*";
	@Override
	public void initConnection(final Properties props) throws MQXIllegalArgumentException
	{
		open
		(
			props.getProperty("br.gov.caixa.mqx.address"),
			props.getProperty("br.gov.caixa.mqx.channel"),
			props.getProperty("br.gov.caixa.mqx.manager"),
			props.getProperty("br.gov.caixa.mqx.userid", MQX_NO_AUTH),
			props.getProperty("br.gov.caixa.mqx.password", MQX_NO_AUTH)
		);
	}

	void open(final String address, final String channel, final String manager, final String userID, final String password)  throws MQXIllegalArgumentException
	{
		if
		(
			address == null ||
			address.length() == 0 ||
			address.length() > MQSeries.MQ_CONN_NAME_LENGTH ||
			channel == null ||
			channel.length() == 0 ||
			channel.length() > MQSeries.MQ_CHANNEL_NAME_LENGTH ||
			manager == null ||
			manager.length() == 0 ||
			manager.length() > MQSeries.MQ_Q_MGR_NAME_LENGTH ||
			userID == null || password == null
		)	throw new MQXIllegalArgumentException("Invalid arguments length");
		final MQResponse ret = new MQResponse();
		try
		{
			int reason = mqxNewConnection(address, channel, manager, userID, password, ret);
			if (reason != MQSeries.MQRC_NONE) throw new MQXSeriesConnectionException("Could not connect to queue manager", reason);
			hConn = ret.hConn;
		}
		catch (final Throwable e) { throw new MQXIllegalArgumentException("Could not open connection to MQSeries", e); }
	}

	@Override
	public void close() throws MQXIllegalStateException, MQXConnectionException
	{
		if (hConn == 0) throw new MQXIllegalStateException("Connection already closed");
		final Iterator<String> it = inputQueues.keySet().iterator();
		while (it.hasNext())
		{
			final MQXQueueImpl queue = inputQueues.get(it.next());
			if (queue != null) queue.internalClose();
		}
		inputQueues.clear();
		try
		{
			int reason = mqxReleaseConnection(hConn);
			if (reason != MQSeries.MQRC_NONE) throw new MQXSeriesConnectionException("Could not disconnect from queue manager", reason);
			hConn = 0;
		}
		catch (final Throwable e) { throw new MQXConnectionException("Could not disconnect from queue manager", e); }
	}

	public int queueDepth(final String qName) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException
	{
		int[] ret = { 0 };
		if (hConn == 0) throw new MQXIllegalStateException("Connection already closed");
		if (qName == null || qName.length() == 0) throw new MQXIllegalArgumentException("Queue name must not be null");
		int reason = mqxQueueDepth(hConn, qName, ret);
		checkReason(reason);
		return ret[0];
	}

	MQXQueue openQueue
	(
		final String qName,
		final boolean input,
		final boolean convert,
		final boolean convertMsgId,
		final boolean convertCorrelId,
		final int maxMsgLen,
		final int getTimeout,
		final int expiry
	)	throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException
	{
		if (hConn == 0) throw new MQXIllegalStateException("Connection already closed");
		if (qName == null || qName.length() == 0) throw new MQXIllegalArgumentException("Queue name must not be null");
		MQXQueueImpl queue;
		final ReentrantLock mutex = this.mutex;
		mutex.lock();
		try
		{
			queue = input ? inputQueues.get(qName) : outputQueues.get(qName);
			if (queue == null)
			{
				if (input && maxMsgLen <= 0) throw new MQXIllegalArgumentException("Input queue must have a positive maxMsgLen argment");
				if (!input && getTimeout > 0) throw new MQXIllegalArgumentException("Output queue must not have a default get timeout");
				if (input && expiry > 0) throw new MQXIllegalArgumentException("Input queue must not have a default put expiry");
				if
				(
					qName == null ||
					qName.length() == 0 ||
					qName.length() > MQSeries.MQ_Q_NAME_LENGTH
				)	throw new MQXIllegalArgumentException("Invalid argument length");
				queue = new MQXQueueImpl(qName, input, convert, convertMsgId, convertCorrelId, maxMsgLen, getTimeout, expiry);
				if (input) inputQueues.put(qName, queue);
				else outputQueues.put(qName, queue);
			}
		}
		finally { mutex.unlock(); }
		return queue;
	}
	@Override
	public MQXQueue openQueue(final Properties props) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException
	{
		int maxLen, getTimeout, expiry;
		try { maxLen = Integer.parseInt(props.getProperty("br.gov.caixa.mqx.msgMaxLen")); }
		catch (final NumberFormatException e) { maxLen = 0; }
		try { getTimeout = Integer.parseInt(props.getProperty("br.gov.caixa.mqx.get.timeout")); }
		catch (final NumberFormatException e) { getTimeout = 0; }
		try { expiry = Integer.parseInt(props.getProperty("br.gov.caixa.mqx.put.expire")); }
		catch (final NumberFormatException e) { expiry = 0; }
		return openQueue
		(
			props.getProperty("br.gov.caixa.mqx.object"), 
			Boolean.parseBoolean(props.getProperty("br.gov.caixa.mqx.input")),
			Boolean.parseBoolean(props.getProperty("br.gov.caixa.mqx.convert")),
			Boolean.parseBoolean(props.getProperty("br.gov.caixa.mqx.convertMsgId")),
			Boolean.parseBoolean(props.getProperty("br.gov.caixa.mqx.convertCorrelId")),
			maxLen,
			getTimeout,
			expiry
		);
	}
	@Override public MQXQueue openQueue(final String name) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException
	{
		throw new MQXIllegalArgumentException("Unsupported operation");
	}

	private enum Stage { BEGIN, COMMIT, ROLLBACK }
	private void transaction(final Stage stage) throws MQXConnectionBrokenException, MQXShutDownException, MQXConnectionException
	{
		int reason;
		try
		{
			switch (stage)
			{
			case BEGIN:
				reason = mqxBegin(hConn);
				break;
			case COMMIT:
				reason = mqxCommit(hConn);
				break;
			default:
				reason = mqxBack(hConn);
			}
		}
		catch (final Throwable e) { throw new MQXConnectionException("Could not stage transaction", e); }
		checkReason(reason);
	}

	@Override public void begin()  throws MQXConnectionException { transaction(Stage.BEGIN);  }
	@Override public void commit() throws MQXConnectionException { transaction(Stage.COMMIT); }
	@Override public void back() throws MQXConnectionException { transaction(Stage.ROLLBACK); }

	@Override
	public boolean isValid() { return valid; }
	private void checkReason
	(
		final int reason
	)	throws MQXConnectionBrokenException, MQXShutDownException, MQXConnectionException
	{
		switch (reason)
		{
		case MQSeries.MQRC_NONE:
		case MQSeries.MQRC_NO_MSG_AVAILABLE:
			break;
		case MQSeries.MQRC_CONNECTION_BROKEN:
		case MQSeries.MQRC_HCONN_ERROR:
			valid = false;
			throw new MQXConnectionBrokenException("MQSeries connection error", reason);
		case MQSeries.MQRC_CONNECTION_QUIESCING:
		case MQSeries.MQRC_CONNECTION_STOPPING:
			valid = false;
			throw new MQXShutDownException("MQSeries server is shuting down", reason);
		default: throw new MQXSeriesConnectionException("Could not complete due to following reason code: " + reason, reason);
		}
	}
	@Override public MQXMessage call(final String putQueue, final String getQueue, final MQXMessage msg)  throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException
	{
		if (msg == null || msg.getMessage() == null) throw new MQXIllegalArgumentException("Request message must not be null");
		final MQXQueue out = outputQueues.get(putQueue);
		final MQXQueue in = inputQueues.get(getQueue);
		if (out == null) throw new MQXIllegalArgumentException("Output queue name not found: " + putQueue);
		if (in == null)  throw new MQXIllegalArgumentException("Input queue name not found: " + getQueue);
		final MQXMessage fMsg = out.send(msg);
		fMsg.setCorrelId(fMsg.getMsgId());
		fMsg.setMsgId(null);
		fMsg.setMessage(null);
		return in.receive(fMsg);
	}

	public class MQXQueueImpl implements MQXQueue
	{
		private long hObj = 0;
		private final String mySelf;
		private final int defaultGetTimeout;
		private final int defaultExpiry;
		private MQXQueueImpl
		(
			final String queue,
			final boolean input,
			final boolean convert,
			final boolean convertMsgId,
			final boolean convertCorrelId,
			final int maxMsgLen,
			final int getTimeout,
			final int expiry
		)	throws MQXConnectionException
		{
			defaultGetTimeout = getTimeout;
			defaultExpiry = expiry;
			mySelf = queue;
			final MQResponse ret = new MQResponse();
			try
			{
				int reason = mqxOpenQueue(hConn, queue, input, convert, convertMsgId, convertCorrelId, maxMsgLen, ret);
				checkReason(reason);
				hObj = ret.hObj;
			}
			catch (final Throwable e) { throw new MQXConnectionException("Could not open queue", e); }
		}

		private MQXMessage transmit
		(
			final MQXMessage msg,
			final boolean send,
			final int timeout,
			final int expire
		)	throws	MQXIllegalStateException,
					MQXIllegalArgumentException,
					MQXConnectionBrokenException,
					MQXShutDownException,
					MQXConnectionException
		{
			if (hConn == 0 || hObj == 0) throw new MQXIllegalStateException("MQSeries resource already closed");
			if (send && msg == null) throw new MQXIllegalArgumentException("Message must not be null");
			if (!send && expire > 0) throw new MQXIllegalArgumentException("Only sended messages can expire");
			byte[] msgId = msg != null && msg.getMsgId() != null ? msg.getMsgId() : new byte[MQSeries.MQ_MSG_ID_LENGTH];
			byte[] correlId = msg != null && msg.getCorrelId() != null ? msg.getCorrelId() : new byte[MQSeries.MQ_CORREL_ID_LENGTH];
			byte[] message = msg != null ? msg.getMessage() : null;
			if
			(
				msgId.length != MQSeries.MQ_MSG_ID_LENGTH ||
				correlId.length != MQSeries.MQ_CORREL_ID_LENGTH
			)	throw new MQXIllegalArgumentException("Invalid message attribute length");
			if (send && message == null) throw new MQXIllegalArgumentException("Method requires a message to send");
			final MQResponse ret = new MQResponse();
			try
			{
				int reason =
					send ?
					(
						expire == 0 ?
						mqxSend(hConn, hObj, msgId, correlId, message, ret) :
						mqxSendExpire(hConn, hObj, expire, msgId, correlId, message, ret)
					) :
					mqxReceive(hConn, hObj, msgId, correlId, timeout, ret);
				checkReason(reason);
				return new MQXMessage(ret.message, ret.msgId, ret.correlId);
			}
			catch (final MQXConnectionException e) { throw e; }
			catch (final Throwable e) { throw new MQXConnectionException("Could not complete request to MQSeries", e); }
		}

		private void internalClose() throws MQXConnectionException
		{
			if (hConn == 0 || hObj == 0) return;
			final ReentrantLock lock = mutex;
			lock.lock();
			try
			{
				final MQXQueue me = inputQueues.get(mySelf);
				if (me != null) inputQueues.remove(mySelf);
				try
				{
					int reason = mqxCloseQueue(hConn, hObj);
					checkReason(reason);
					hObj = 0;
				}
				catch (final Throwable e) { throw new MQXConnectionException("Could not close queue",e); }
			}
			finally { lock.unlock(); }
		}

		@Override public void close() throws MQXConnectionException {}
		@Override public MQXMessage send(MQXMessage msg) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException { return send(msg, defaultExpiry); }
		@Override public MQXMessage send(MQXMessage msg, int expire) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException { return transmit(msg, true, 0, expire); }
		@Override public MQXMessage receive(MQXMessage msg) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException { return receive(msg, defaultGetTimeout); }
		@Override public MQXMessage receive(MQXMessage msg, int timeout) throws MQXIllegalStateException, MQXIllegalArgumentException, MQXConnectionException { return transmit(msg, false, timeout, 0); }
	}
}
