package br.gov.caixa.xml;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.SequenceInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;
import javax.xml.crypto.dsig.XMLValidateContext;

import br.gov.caixa.BufferedStringWriter;

public class LoteEventosParser
{
	private enum DocParts
	{
		Start(0, ""),
		StartDocument(0, ""),
		StartRoot(1, "eSocial"),
		StartBatch(2, "envioLoteEventos"),
		StartEvents(3, "eventos"),
		StartEvent(4, "evento"),
		EndEvent(4, "evento"),
		EndEvents(3, "eventos"),
		EndBatch(2, "envioLoteEventos"),
		EndRoot(1, "eSocial"),
		EndDocument(0, "");
		private final int level;
		private final String tag;
		private DocParts(int level, String tag) { this.level = level; this.tag = tag; }
		private int getLevel() { return level; }
		private String getTag() { return tag; }
		private DocParts nextState()
		{
			switch (this)
			{
			case EndEvents: return EndBatch;
			case EndBatch: return EndRoot;
			case EndRoot: return EndDocument;
			default: return null;
			}
		}
	}

	public static final byte[] XML_INSTRUCTION = XMLFragmentReader.XML_INSTRUCTION.getBytes(StandardCharsets.UTF_8);

	public static List<String> parse(final byte[] fragment, final int buffSize) throws XMLStreamException
	{
		return parse(fragment,buffSize,null);
	}

	public static List<String> parse(final byte[] fragment, final int buffSize, List<XMLValidateContext> signature) throws XMLStreamException
	{
		final InputStreamReader read = new InputStreamReader(new SequenceInputStream(new ByteArrayInputStream(XML_INSTRUCTION),new ByteArrayInputStream(fragment)), StandardCharsets.UTF_8);
		return parse(factory().createXMLEventReader(read), buffSize, signature);
	}

	public static List<String> parse(final String fragment, final int buffSize) throws XMLStreamException
	{
		return parse(fragment,buffSize,null);
	}

	public static List<String> parse(final String fragment, final int buffSize, List<XMLValidateContext> signature) throws XMLStreamException
	{
		return parse(factory().createXMLEventReader(new XMLFragmentReader(fragment)), buffSize, signature);
	}

	public static List<String> parse(final char[] fragment, final int buffSize) throws XMLStreamException
	{
		return parse(fragment,buffSize,null);
	}
	
	public static List<String> parse(final char[] fragment, final int buffSize, List<XMLValidateContext> signature) throws XMLStreamException
	{
		return parse(factory().createXMLEventReader(new XMLFragmentReader(fragment)), buffSize, signature);
	}
	
	private static XMLInputFactory factory()
	{
		final XMLInputFactory xmlf = XMLInputFactory.newInstance();
		xmlf.setProperty(XMLInputFactory.IS_COALESCING, true);
		xmlf.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, false);
		xmlf.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
		return xmlf;
	}

	private static List<String> parse(final XMLEventReader reader, final int buffSize, List<XMLValidateContext> signature) throws XMLStreamException
	{
		final List<String> ret = new ArrayList<String>(16);
		final BufferedStringWriter writer = new BufferedStringWriter(buffSize);
		int level = -1;
		DocParts state = DocParts.Start;
		try
		{
			while (reader.hasNext())
			{
				final XMLEvent e = reader.nextEvent();
				switch (state)
				{
				case Start:
					if (!e.isStartDocument()) throw new XMLStreamException("Malformed XML document");
					level++;
					state = DocParts.StartDocument;
					break;
				case StartDocument:
					if (e.isStartElement())
					{
						if (DocParts.StartRoot.getTag().equals(e.asStartElement().getName().getLocalPart()))
						{
							level++;
							state = DocParts.StartRoot;
						}
						else throw new XMLStreamException("Document root element not found");
					}
					break;
				case StartRoot:
					if (e.isStartElement())
					{
						if (DocParts.StartBatch.getTag().equals(e.asStartElement().getName().getLocalPart()))
						{
							level++;
							state = DocParts.StartBatch;
						}
						else throw new XMLStreamException("Document element not found");
					}
					break;
				case StartBatch:
					if (e.isStartElement())
					{
						if
						(
							DocParts.StartEvents.getTag().equals(e.asStartElement().getName().getLocalPart())
						)	state = DocParts.StartEvents;
						level++;
					}
					else if (e.isEndElement()) level--;
					break;
				case StartEvents:
				case EndEvent:
					if (e.isStartElement())
					{
						if (DocParts.StartEvent.getTag().equals(e.asStartElement().getName().getLocalPart()))
						{
							level++;
							state = DocParts.StartEvent;
						}
						else throw new XMLStreamException("Event element not found");
					}
					break;
				case StartEvent:
					if (e.isStartElement()) 
					{
						level++;
					}
					else if (e.isEndElement())
					{
						if (level == DocParts.EndEvent.getLevel())
						{
							state = DocParts.EndEvent;
							final String value = writer.toString();
							if (value.length() > 0) ret.add(value);
							writer.close();
							level--;
							continue;
						}
						level--;
					}
					e.writeAsEncodedUnicode(writer);
					break;
				case EndEvents:
				case EndBatch:
				case EndRoot:
				case EndDocument:
					if (e.isEndElement()) state = state.nextState();
					else if (e.isStartElement()) throw new XMLStreamException("Invalid XML document");
					break;
				default:
				}
			}
		}
		finally { reader.close(); }
		return ret;
	}


	private enum SignedDocument
	{
		Start(""),
		StartDocument(""),
		StartRoot("eSocial"),
		StartSignature("Signature"),
		EndSignature("Signature"),
		EndRoot("eSocial"),
		EndDocument("");
		private final String tag;
		private SignedDocument(String tag) { this.tag = tag; }
		private String getTag() { return tag; }
	}
	public static String removeSignature(final String event, final int buffSize) throws XMLStreamException
	{
		final BufferedStringWriter writer = new BufferedStringWriter(buffSize);
		SignedDocument state = SignedDocument.StartDocument;
		final XMLInputFactory xmlf = XMLInputFactory.newInstance();
		xmlf.setProperty(XMLInputFactory.IS_COALESCING, true);
		xmlf.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, false);
		xmlf.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
		final XMLEventReader reader = xmlf.createXMLEventReader(new XMLFragmentReader(event));
		try
		{
			while (reader.hasNext())
			{
				final XMLEvent e = reader.nextEvent();
				switch (state)
				{
				case StartDocument:
					if (e.isStartElement())
					{
						if
						(
							SignedDocument.StartRoot.getTag().equals(e.asStartElement().getName().getLocalPart())
						)	state = SignedDocument.StartRoot;
						else throw new XMLStreamException("Document root element not found");
					}
					continue;
				case StartRoot:
					if (e.isStartElement())
					{
						if (SignedDocument.StartSignature.getTag().equals(e.asStartElement().getName().getLocalPart()))
						{
							state = SignedDocument.StartSignature;
							continue;
						}
					}
					break;
				case StartSignature:
					if
					(
						e.isEndElement() &&
						SignedDocument.EndSignature.getTag().equals(e.asEndElement().getName().getLocalPart())
					)	state = SignedDocument.EndSignature;
				case EndSignature:
					continue;
				default:
				}
				e.writeAsEncodedUnicode(writer);
			}
		}
		finally { reader.close(); }
		return writer.toString();
	}
}
