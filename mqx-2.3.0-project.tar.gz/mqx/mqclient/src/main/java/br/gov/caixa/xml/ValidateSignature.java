package br.gov.caixa.xml;

import java.security.Key;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.List;

import javax.xml.crypto.AlgorithmMethod;
import javax.xml.crypto.KeySelector;
import javax.xml.crypto.KeySelectorException;
import javax.xml.crypto.KeySelectorResult;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.X509Data;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class ValidateSignature {
	private final InnerKeySelector ks = new InnerKeySelector();
	private X509Certificate cert;

	public enum SignatureStatus
	{
		ValidSignature,
		InvalidSignature,
		NoSignature,
		TooManySignatures,
		ErrorValidating
	}


	public ValidateSignature(){};


	public X509Certificate getCertificate()
	{
		return cert;
	}

	public SignatureStatus validate(Document xml)
	{
        NodeList nl = xml.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
        if (nl.getLength() == 0) {
            return SignatureStatus.NoSignature;
		}
		if(nl.getLength() > 1)
		{
			return SignatureStatus.TooManySignatures;
		}
		try{
			XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM");
			DOMValidateContext valContext = new DOMValidateContext(ks, nl.item(0));
			XMLSignature signature = fac.unmarshalXMLSignature(valContext);
			return signature.validate(valContext) ? SignatureStatus.ValidSignature 
												  : SignatureStatus.InvalidSignature;
		}
		catch (Exception e)
		{
			cert = null;
			return SignatureStatus.ErrorValidating;
		}
	}




	private class InnerKeySelector extends KeySelector
	{

		@Override
		public KeySelectorResult select(KeyInfo ki, Purpose pu, AlgorithmMethod me, XMLCryptoContext ctx) throws KeySelectorException
		{
			if (ki == null) {
				throw new KeySelectorException("Null KeyInfo object!");
			}
			List<?> list = ki.getContent();

			for (Object o : list) {
				if (o instanceof X509Data) {
					X509Data x = (X509Data)o;
					List<?> content = x.getContent();
					for(Object b : content)
					{
						if (b instanceof X509Certificate) {
							cert = ((X509Certificate)b);
							PublicKey pk =cert.getPublicKey();
							return new KeyResult(pk);
						}
					}
				}
			}
			cert = null;
			throw new KeySelectorException("No KeyValue element found!");
		}
	}

	private class KeyResult implements KeySelectorResult
	{
        private PublicKey pk;
        KeyResult(PublicKey pk) {
            this.pk = pk;
    	}
		public Key getKey() { return pk; }
	}

}
