package br.gov.caixa.ws;

import java.io.Serializable;
import java.util.Iterator;

import org.crypthing.things.config.Config;
import org.crypthing.things.config.ConfigException;
import org.crypthing.things.config.Converter;
import org.w3c.dom.Node;

import br.gov.caixa.soap.SOAPEnvelope;
import br.gov.caixa.soap.SOAPElement.XSDType;
import br.gov.caixa.soap.SOAPElement;

public final class WSSignature implements Serializable
{
	private static final long serialVersionUID = 1759873273111284365L;
	private String soapAction;
	private SOAPEnvelope webMethod;
	private SOAPEnvelope webResponse;
	
	public WSSignature(final Config cfg, Node value) throws ConfigException {
		soapAction = cfg.getValue("./soap-action", value);
		{
			final Node call = cfg.getNodeValue("./web-call", value);
			webMethod = new SOAPEnvelope();
			webMethod.setName(cfg.getValue("./name", call));
			webMethod.setBodyNamespace(cfg.getValue("./namespace", call));
			final Node web_params = cfg.getNodeValue("./web-params", call);
			final Iterator<SOAPElement> it = cfg.getValueCollection("./wb-param", web_params , new EnvelopeConverter(cfg) ).iterator();
			while (it.hasNext())webMethod.add(it.next());
		}
		{
			final Node response = cfg.getNodeValue("./web-response", value);
			webResponse = new SOAPEnvelope();
			webResponse.setName(cfg.getValue("./name", response));
			final Node web_result = cfg.getNodeValue("./web-result", response);
			final Iterator<SOAPElement> it = cfg.getValueCollection("./return", web_result, new EnvelopeConverter(cfg) ).iterator();
			while (it.hasNext())webResponse.add(it.next());
		}
	}

	private static class EnvelopeConverter implements Converter<SOAPElement> 
	{
		private final Config cfg;
		public EnvelopeConverter(final Config cfg)
		{
			this.cfg = cfg;
		}
		@Override
		public SOAPElement convert(Object value) throws ClassCastException
		{
			return new SOAPElement(	cfg.getValue("./name", (Node) value),
									null, 
									XSDType.xsString,
									Boolean.parseBoolean(cfg.getValue("./optional", (Node) value ))
								);
		}
	}


	public String getSoapAction() { return soapAction; }
	public void setSoapAction(final String soapAction) { this.soapAction = "\"" + soapAction + "\""; }
	public SOAPEnvelope getWebMethod() { return webMethod; }
	public void setWebMethod(final SOAPEnvelope webMethod) { this.webMethod = webMethod; }
	public SOAPEnvelope getWebResponse() { return webResponse; }
	public void setWebResponse(final SOAPEnvelope webResponse) { this.webResponse = webResponse; }

	public void validate() throws WSConfigException { if ( webMethod == null || webResponse == null ) throw new WSConfigException("Invalid method signature configuration"); }
	@Override
	public String toString()
	{
		final StringBuilder builder = new StringBuilder(512);
		builder.append("WSSignature=\n{\n");
		if (webMethod != null) builder.append("web-method={\n").append(webMethod.toString()).append("}");
		if (webResponse != null) builder.append("web-response={\n").append(webResponse.toString()).append("}");
		return builder.append("}").toString();
	}
}
