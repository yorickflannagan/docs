package br.gov.caixa.cnscx.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

public class Example extends HttpServlet
{
	private static final long serialVersionUID = -8059946418877016169L;
	private static final String KEYSTORE_ENTRY = "javax.net.ssl.keyStore";
	private static final int DEVICE_FOUND = 0;		// Dispositivo encontrado
	private static final int ID_NOT_FOUND = 1;		// Identificador do usuário não encontrado (requer download do token)
	private static final int DEVICE_NOT_FOUND = 2;		// Dispositivo não associado ao usuário (requer download do token)
	private static final int FINGERPRINT_UPDATED = 3;	// Dispositivo encontrado, fingerprint atualizado
	private static final int GUID_UPDATED = 4;		// Dispositivo envontrado, guid atualizado (requer download do token)

	class DatabaseEntry implements Serializable
	{
		private static final long serialVersionUID = 3050663161517303387L;
		String fingerprint;
		String guid;
	}
	private ConcurrentHashMap<String, ArrayList<DatabaseEntry>> _database = new ConcurrentHashMap<>();


	@Override
	public void init() throws ServletException
	{
		final String entry = getServletConfig().getInitParameter(KEYSTORE_ENTRY);
		if (entry == null) throw new ServletException("Configuracao invalida para o CNS");
		final Properties props = new Properties();
		props.setProperty(KEYSTORE_ENTRY, entry);
		props.setProperty("javax.net.ssl.keyStorePassword", "secret");
		props.setProperty("javax.net.ssl.keyStoreType", "pkcs12");
		props.setProperty("br.gov.caixa.cns.keyalias", "signer");
		try { JWT.init(props); }
		catch (final InitException e) { throw new ServletException("Falha na iniciacao do facade JWT", e); }
	}
	@Override
	protected void doPost(final HttpServletRequest req, final HttpServletResponse resp) throws ServletException, IOException
	{
		final String json = readBody(req);
		try
		{
			final JSONObject ob = new JSONObject(json);
			final String id = ob.getString("id");
			final String fingerprint = ob.getString("fingerprint");
			int tokens = ob.getInt("tokens");
			String token = ob.has("jwt") ? ob.getString("jwt") : null;
			String guid;
			String jsonToken = null;
			if (token == null)
			{
				guid = UUID.randomUUID().toString();
				jsonToken = JWTFacade.issueToken(id, guid);
			}
			else
			{
				final JWTFacade.TokenSEFIP tok = JWTFacade.validate(json);
				guid = tok.getGUID();
			}
			final int db = findInDatabase(id, fingerprint, guid);
			int status = HttpURLConnection.HTTP_OK;
			if (db == ID_NOT_FOUND || db == DEVICE_NOT_FOUND)
			{
				if (tokens < 5) addDevice(id, fingerprint, guid);
				else
				{
					status = HttpURLConnection.HTTP_BAD_METHOD;
					jsonToken = null;
				}
			}
			resp.setStatus(status);
			if (jsonToken != null)
			{
				resp.setHeader("Content-Type", "application/json; charset=utf-8");
				resp.getWriter().write(jsonToken);
			}
		}
		catch (final JSONException | GeneralSecurityException e)
		{
			resp.setStatus(HttpURLConnection.HTTP_BAD_REQUEST);
			e.printStackTrace();
		}
	}
	private String readBody(final HttpServletRequest req) throws IOException
	{
		final BufferedReader reader = req.getReader();
		final char[] buffer = new char[1024];
		final StringBuilder writer = new StringBuilder(2048);
		int i;
		while ((i = reader.read(buffer)) != -1) writer.append(buffer, 0, i);
		return writer.toString();
	}
	private int findInDatabase(final String id, final String fingerprint, final String guid)
	{
		int ret = ID_NOT_FOUND;
		boolean fpFound = false, gdFound = false;
		ArrayList<DatabaseEntry> entries =_database.get(id);
		if (entries != null)
		{
			ret = DEVICE_NOT_FOUND;
			final Iterator<DatabaseEntry> it =  entries.iterator();
			while (it.hasNext() && ret == DEVICE_NOT_FOUND)
			{
				final DatabaseEntry entry = it.next();
				fpFound = entry.fingerprint.equalsIgnoreCase(fingerprint);
				gdFound = entry.guid.equalsIgnoreCase(guid);
				if (fpFound && gdFound) ret = DEVICE_FOUND;
				else if (fpFound)
				{
					ret = GUID_UPDATED;
					entry.guid = guid;
				}
				else if (gdFound)
				{
					ret = FINGERPRINT_UPDATED;
					entry.fingerprint = fingerprint;
				}
			}
		}
		return ret;
	}
	private void addDevice(final String id, final String fingerprint, final String guid)
	{
		DatabaseEntry entry = new DatabaseEntry();
		entry.fingerprint = fingerprint;
		entry.guid = guid;
		ArrayList<DatabaseEntry> entries = _database.get(id);
		if (entries == null)
		{
			entries = new ArrayList<>();
			_database.put(id, entries);
		}
		entries.add(entry);
	}
}