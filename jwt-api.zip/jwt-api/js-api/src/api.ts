'use strict';

import browserFP from "fingerprintjs2";

/**
 * Header JWT
 */
class JWTHeader
{
	static readonly TOKEN_TYPE = "JOSE";
	typ: string = "";
	alg: string = "";
	jwk: string = "";
	static typeOf(ob: any | null) { return ob && ob.typ && ob.alg && ob.jwk && JWTHeader.TOKEN_TYPE.localeCompare(ob.typ, "en", { sensitivity: "base" }) == 0; }
}
/**
 * Payload JWT requerido pelo SEFIP
 */
class JWTPayload
{
	iss: string  = "";
	sub: string  = "";
	aud: string  = "";
	iat: number  = 0;
	exp: number  = 0;
	jti: string  = "";
	name: string = "";
	static readonly CNS_ISSUER	= "http://cns.caixa.gov.br";
	static readonly CNS_SUBJECT	= "ACP-5003473-95.2017.4.04.7102/RS";
	static readonly CNS_AUDIENCE	= "SEFIP";
	static typeOf(payload: any | null): boolean
	{
		return (
			payload &&
			JWTPayload.CNS_ISSUER.localeCompare(payload.iss,   "pt", { sensitivity: "base" }) == 0 &&
			JWTPayload.CNS_SUBJECT.localeCompare(payload.sub,  "pt", { sensitivity: "base" }) == 0 &&
			JWTPayload.CNS_AUDIENCE.localeCompare(payload.aud, "pt", { sensitivity: "base" }) == 0 &&
			payload.iat && payload.exp && payload.jti && payload.name
		);
	}
}
/**
 * Token JWT
 */
class JWTToken
{
	private _payload: JWTPayload;
	constructor(token: string)
	{
		if (!token) throw "Token must not be null";
		let parts: string[] = token.split(".");
		if (parts.length != 3) throw "Token is not correctly encoded";
		let ob = JSON.parse(Buffer.from(parts[0], "base64").toString());
		if (!JWTHeader.typeOf(ob)) throw "Invalid JWT header";
		ob = JSON.parse(Buffer.from(parts[1], "base64").toString());
		if (!JWTPayload.typeOf(ob)) throw "Invalid JWT payload";
		this._payload = ob;
	}
	getPayload(): JWTPayload { return this._payload; }
}
/**
 * Token emitido pelo CNS serializado num documento JSON
 */
class DeviceToken
{
	static readonly SUCCESS		= 0;	// Operação bem sucedida
	static readonly INVALID_JWT	= 1;	// Token JWT malformado
	static readonly STORAGE_FULL	= 2;	// Quota do storage local excedida
	static readonly SAVE_ERROR	= 3;	// Falha ao gravar (provável falta de permissão)
	key: string;				// Chave de acesso ao storage local
	jwt: string;				// Valor a ser armazenado no storage local
	constructor(token: string)
	{
		let ob = JSON.parse(token)
		if (!ob.key || !ob.jwt) throw "Invalid token";
		let jwt = new JWTToken(ob.jwt);
		if (ob.key.localeCompare(jwt.getPayload().name, "pt") != 0) throw "Invalid token";
		this.key = ob.key;
		this.jwt = ob.jwt;
	}
}
/**
 * Identificação do dispositivo
 */
class DeviceId
{
	id: string = "";			// Identificador do usuário
	fingerprint: string = "";	// Impressão digital do navegador
	tokens: number = 0;		// Quantidade de tokens armazenados no storage local
	jwt: string | undefined;	// Token JWT, se armazenado no storage local
}
/**
 * Post enviado ao serviço CNS com a identificação do dispositivo
 */
class IdPost
{
	static readonly SUCCESS				= 0;	// Operação bem sucedida
	static readonly TOKEN_NOT_FOUND		= 1;	// CNPJ não encontrado no storage
	static readonly INVALID_TOKEN			= 2;	// Valor encontrado não é um Token JWT válido para o SEFIP
	static readonly UNKNOWN_TOKEN			= 3;	// Claim name do token não corresponde à chave do storage
	static readonly EXPIRED_TOKEN			= 4;	// Token expirado
	result: number = 0;					// Status da obtenção do Token
	device: DeviceId = { id: "", fingerprint: "", tokens: 0, jwt: undefined}
}
/**
 * Implementação da identificação do navegador
 */
class BrowserIdentifier
{
	/**
	 * Obtem o objeto JSON a ser enviado ao CNS, com a identificação do dispositivo
	 * @param name string chave de acesso ao storage local (CNPJ do usuário)
	 * @returns    IdPost a identificação do dispositivo e o status do token
	 */
	identifyDevice(name: string): Promise<IdPost>
	{
		if (!name) throw "Argument must not be null";
		return new Promise<IdPost>((resolve, reject) => {
			browserFP.get(function(components) {
				let ret: IdPost = new IdPost();
				ret.device.id = name;
				ret.device.fingerprint = browserFP.x64hash128(components.map(function (pair) { return pair.value }).join(), 31);
				ret.device.tokens = window.localStorage.length;
				let token: string | null = window.localStorage.getItem(name);
				if (token)
				{
					try
					{
						let jwt: JWTToken = new JWTToken(token);
						let payload: JWTPayload = jwt.getPayload();
						if (name.localeCompare(payload.name, "pt") == 0)
						{
							if ((Date.now() / 1000) < payload.exp)
							{
								ret.device.jwt = token;
								ret.result = IdPost.SUCCESS;
							}
							else ret.result = IdPost.EXPIRED_TOKEN;
						}
						else ret.result = IdPost.UNKNOWN_TOKEN;
					}
					catch (e)
					{
						console.log("Erro ao decodificar o token JWT: " + e);
						ret.result = IdPost.INVALID_TOKEN;
					}
					if (ret.result > IdPost.TOKEN_NOT_FOUND) window.localStorage.removeItem(name);
				}
				else ret.result = IdPost.TOKEN_NOT_FOUND;
				resolve(ret);
			});
		});
	}
	/**
	 * Armazena no storage local o token CNS recebido do serviço
	 * @param json string instância serializada de DeviceToken
	 * @returns    number resultado da operação
	 */
	storeToken(json: string): number
	{
		let ret: number = DeviceToken.SUCCESS;
		try
		{
			let token: DeviceToken = new DeviceToken(json);
			try { window.localStorage.setItem(token.key, token.jwt); }
			catch (e)
			{
				if
				(
					e instanceof DOMException && (
						e.code === 22 ||
						e.code === 1014 ||
						e.name === 'QuotaExceededError' ||
						e.name === 'NS_ERROR_DOM_QUOTA_REACHED'
					) &&
					localStorage.length !== 0
				)	ret = DeviceToken.STORAGE_FULL;
				else  ret = DeviceToken.SAVE_ERROR;
			}
		}
		catch (ex) { ret = DeviceToken.INVALID_JWT; }
		return ret;
	}
}
class JwtAPI
{
	BrowserIdentifier = BrowserIdentifier;
	DeviceId		= DeviceId;
	IdPost		= IdPost;
	DeviceToken		= DeviceToken;
}
export var jwtApi: JwtAPI = new JwtAPI();
