package br.gov.caixa.cnscx.api;

public class JWTException extends Exception
{
	private static final long serialVersionUID = 6577263648944078816L;
	public JWTException(final String message) { super(message); }
	public JWTException(final String message, final Throwable cause) { super(message, cause); }
}