package br.gov.caixa.cnscx.api;

import java.io.StringWriter;
import java.security.GeneralSecurityException;
import java.security.SignatureException;
import java.util.Properties;
import java.util.UUID;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONWriter;


/**
 * Facade para a implementação Java JWT da RFC 7519
 */
public class JWTFacade implements java.io.Serializable
{
	private static final long serialVersionUID = 7361071851604702610L;
	/**
	 * Verifica se o token de identificação de dispositivo especificado é valido.
	 * @param token String JSON serializado recebido da API javascript, que deve atender ao seguinte schema:
	 * <pre>
 	 *{
 	 *    "$schema": "http://json-schema.org/draft-07/schema",
 	 *    "$id": "http://cns.caixa.gov.br/device-id-post.json",
 	 *    "type": "object",
 	 *    "title": "Identificação do dispositivo",
 	 *    "description": "Conteúdo do post recebido da API javascript com os elementos utilizados para a identificação do dispositivo do usuário.",
 	 *    "default": {},
 	 *    "examples": [
 	 *        {
 	 *            "id": "34496454000117",
 	 *            "fingerprint": "f0239058556269f64f2c51748ec39b7f",
 	 *            "jwt": "yJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJBQ1AtNTAwMzQ3My05N.."
 	 *        }
 	 *    ],
 	 *    "required": [
 	 *        "id",
 	 *        "fingerprint"
 	 *    ],
 	 *    "additionalProperties": true,
 	 *    "properties": {
 	 *        "id": {
 	 *            "$id": "#/properties/id",
 	 *            "type": "string",
 	 *            "title": "Identificação do usuário",
 	 *            "description": "Chave de acesso ao storage local do navegador, implementado como um CNPJ.",
 	 *            "default": "",
 	 *            "examples": [
 	 *                "34496454000117"
 	 *            ]
 	 *        },
 	 *        "fingerprint": {
 	 *            "$id": "#/properties/fingerprint",
 	 *            "type": "string",
 	 *            "title": "Impressão digital do dispositivo",
 	 *            "description": "Hash SHA-1 das características distintivas do navegador, conforme definido em https://github.com/fingerprintjs/fingerprintjs2",
 	 *            "default": "",
 	 *            "examples": [
 	 *                "f0239058556269f64f2c51748ec39b7f"
 	 *            ]
 	 *        },
 	 *        "jwt": {
 	 *            "$id": "#/properties/jwt",
 	 *            "type": "string",
 	 *            "title": "Identificação do usuário",
 	 *            "description": "Token JWT utilizado para identificar inequivocamente o usuário do SEFIP e assinado pelo CNS, encodado como um BASE64URL nos termos da RFC 7519",
 	 *            "default": "",
 	 *            "examples": [
 	 *                "yJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJBQ1AtNTAwMzQ3My05N..."
 	 *            ]
 	 *        }
 	 *    }
       *
	 * }
	 * </pre>
	 * @return uma instância do TokenSEFIP
	 * @throws SignatureException em caso de falha. As seguintes validações são realizadas:
	 * <ul>
	 * 	<li>consistência do schema Identificação do dispositivo;</li>
	 * 	<li>se presentes os campos jwt e pubKey do objeto, são validados conforme @see verify()</li>
	 * 	<li> se o token JWT estiver presente:
	 * 		<ul>
	 * 			<li>é verificada a presença dos claims exigidos pelo SEFIP</li>
	 * 			<li>é verificado se o campo jti do token corresponde à identidade fornecida no documento JSON</li>
	 * 			<li>é verificada a data de expiração do Token JWT</li>
	 * 		</ul>
	 * 	</li>
	 * </ul>
	 */
	static public TokenSEFIP validate(final String token) throws SignatureException
	{
		try
		{
			final JSONObject json = new JSONObject(token);
			final String id = json.getString("id");
			final String fingerprint = json.getString("fingerprint");
			if (!json.has("jwt")) throw new JSONException("Objecto JSON nao consistente com um token SEFIP valido");
			return new TokenSEFIP(id, fingerprint, JWT.getDecoder().decode(json.getString("jwt"), id));
		}
		catch (final Exception e) { throw new SignatureException(e); }
	}
	static public class TokenSEFIP
	{
		private final String _id;
		private final String _fingerprint;
		private final String _guid;
		TokenSEFIP(final String id, final String fingerprint, final String guid)
		{
			_id = id;
			_fingerprint = fingerprint;
			_guid = guid;
		}
		public String getCNPJ() { return _id; }
		public String getFingerprint() { return _fingerprint; }
		public String getGUID() { return _guid; }
	}
	/**
	 * Emite um token de identificação do usuário para ser armazenado no dispositivo identificado
	 * @param name	String identidade civil do usuário (implementado como um CNPJ)
	 * @param id	String identificação global do dispositivo, implementado como um GUID
	 * @return		String objeto JSON serializado para armazenamento no storage local do navegador, atendendo ao seguinte schema:
	 * <pre>
	 * {
	 *     "$schema": "http://json-schema.org/draft-07/schema",
	 *     "$id": "http://cns.caixa.gov.br/user-id.json",
	 *     "type": "object",
	 *     "title": "Identificação do usuário",
	 *     "description": "Documento emitido pelo CNS para identificação do usuário de um dispositivo",
	 *     "default": {},
	 *     "examples": [
	 *         {
	 *             "key": "34496454000117",
	 *             "jwt": "yJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJBQ1AtNTAwMzQ3My05N.."
	 *         }
	 *     ],
	 *     "required": [
	 *         "key",
	 *         "jwt"
	 *     ],
	 *     "additionalProperties": true,
	 *     "properties": {
	 *         "key": {
	 *             "$id": "#/properties/key",
	 *             "type": "string",
	 *             "title": "Identificação",
	 *             "description": "Chave de acesso ao storage local do navegador.",
	 *             "default": "",
	 *             "examples": [
	 *                 "34496454000117"
	 *             ]
	 *         },
	 *          "jwt": {
	 *             "$id": "#/properties/token/properties/jwt",
	 *             "type": "string",
	 *             "title": "Token JWT",
	 *             "description": "O Token JWT assinado contendo os claims exigidos pelo SEFIP.",
	 *             "default": "",
	 *             "examples": [
	 *                 "yJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJBQ1AtNTAwMzQ3My05N.."
	 *             ]
	 *         }
	 *     }
	 * }
	 * 
	 * </pre>
	 * @throws GeneralSecurityException	caso a assinatura falhe
	 */
	static public String issueToken(final String name, final String id) throws GeneralSecurityException
	{
		final StringWriter writer = new StringWriter();
		(new JSONWriter(writer))
			.object()
			.key("key").value(name)
			.key("jwt").value(JWT.getEncoder().issue(name, id))
			.endObject();
		return writer.toString();
	}


	public static void main(String[] args) throws Exception
	{
		System.out.println("Realizando teste de unidade...");
		final Properties props = new Properties();
		props.setProperty(JWT.KEY_STORE_ENTRY, "src/main/resources/test.pfx");
		props.setProperty(JWT.KEY_STORE_TYPE_ENTRY, "pkcs12");
		props.setProperty(JWT.KEY_STORE_PWD_ENTRY, "secret");
		props.setProperty(JWT.KEY_ALIAS_ENTRY, "signer");
		JWT.init(props);
		
		final String cnpj = "34496454000117";
		final String guid = UUID.randomUUID().toString();
		final String jsonToken = JWTFacade.issueToken(cnpj, guid);
		System.out.println("DeviceToken: [" + jsonToken + "]");
		final JSONObject tokenSEFIP = new JSONObject(jsonToken);
		if (!cnpj.equalsIgnoreCase(tokenSEFIP.getString("key"))) throw new RuntimeException("Chave de acesso do token nao encontrada");
		final StringWriter writer = new StringWriter();
		final String fingerprint = "f0239058556269f64f2c51748ec39b7f";
		final JSONWriter post = new JSONWriter(writer);
		post.object()
			.key("id").value(cnpj)
			.key("fingerprint").value(fingerprint)
			.key("jwt").value(tokenSEFIP.getString("jwt"))
			.endObject();
		final String jsonPost = writer.toString();
		System.out.println("IdPost: [" + jsonPost + "]");
		final JWTFacade.TokenSEFIP tok = JWTFacade.validate(jsonPost);
		if (!cnpj.contentEquals(tok.getCNPJ())) throw new RuntimeException("CNPJ nao validado");
		if (!guid.contentEquals(tok.getGUID())) throw new RuntimeException("GUID nao validado");
		if (!fingerprint.contentEquals(tok.getFingerprint())) throw new RuntimeException("Fingerprint nao validado");
		System.out.println("Teste bem sucedido");
	}
}
