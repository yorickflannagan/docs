package br.gov.caixa.cnscx.api;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.io.StringWriter;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.RSAPublicKeySpec;
import java.util.Base64;
import java.util.Properties;
import java.util.UUID;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONWriter;

public class JWT implements Serializable
{
	static class JWTEncoder extends JWT
	{
		private static final long serialVersionUID = -3678264511991700713L;
		private final String _header;
		private final String _javaAlgorithm;
		private JWTEncoder(final String issuer, final String subject, final String audience, final String algorithm) throws NoSuchAlgorithmException
		{
			super(issuer, subject, audience);
			_javaAlgorithm = getJavaAlgorithm(algorithm);
			final StringWriter writer = new StringWriter(2048);
			(new JSONWriter(writer))
				.object()
				.key("typ").value("JOSE")
				.key("alg").value(algorithm)
				.key("jwk").value(_JWK_VALUE)
				.endObject();
			_header = new String (Base64.getUrlEncoder().encode(writer.toString().getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8).replace("=", "");
		}
		public String encodePayload(final String name, final String id)
		{
			if (id == null) throw new IllegalArgumentException("Argumento id nao pode ser nulo");
			final StringWriter writer = new StringWriter(1024);
			(new JSONWriter(writer))
				.object()
				.key("iss").value(_issuer)
				.key("sub").value(_subject)
				.key("aud").value(_audience)
				.key("iat").value(System.currentTimeMillis() / 1000)
				.key("exp").value(_EXPIRATION)
				.key("jti").value(id)
				.key("name").value(name)
				.endObject();
			return new String (Base64.getUrlEncoder().encode(writer.toString().getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8).replace("=", "");
		}
		public String sign(final String encodedPayload) throws GeneralSecurityException
		{
			final String plainText = (new StringBuilder(4096)).append(_header).append(".").append(encodedPayload).toString();
			final Signature signature = Signature.getInstance(_javaAlgorithm);
			signature.initSign(_PRIVKEY);
			signature.update(plainText.getBytes(StandardCharsets.UTF_8)); return new String(Base64.getUrlEncoder().encode(signature.sign()), StandardCharsets.UTF_8).replace("=", "");
		}
		public String issue(final String name, final String id) throws GeneralSecurityException
		{
			final String payload = encodePayload(name, id);
			final String signature = sign(payload);
			return (new StringBuilder(4096)).append(_header).append(".").append(payload).append(".").append(signature).toString();
		}
	}
	static class JWTDecoder extends JWT
	{
		private static final long serialVersionUID = 6724983881485833776L;
		private JWTDecoder(final String issuer, final String subject, final String audience) { super(issuer, subject, audience); }
		public JSONObject decodeHeader(final String header) throws JWTException
		{
			try
			{
				JSONObject json = new JSONObject(new String(Base64.getUrlDecoder().decode(header.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8));
				final String alg = json.getString("alg");
				if
				(
					!alg.equalsIgnoreCase("RS256") &&
					!alg.equalsIgnoreCase("RS384") &&
					!alg.equalsIgnoreCase("RS512")
				)	throw new JWTException("Algoritmo nao suportado: " + alg);
				if (!json.has("typ") || !json.has("jwk")) throw new JWTException("Argumento nao e um header valido");
				return json;
			}
			catch (final IllegalArgumentException e) { throw new JWTException("Argumento nao e um BASE64URL valido"); }
			catch (final JSONException e) { throw new JWTException("Campo algoritmo invalido", e); }
		}
		public JSONObject decodeJWK(final String jwk) throws JWTException, GeneralSecurityException
		{
			try
			{
				JSONObject json = new JSONObject(new String(Base64.getUrlDecoder().decode(jwk.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8));
				JSONArray set = json.getJSONArray("keys");
				JSONObject key = set.getJSONObject(0);
				if
				(
					!key.has("kty") ||
					!key.getString("kty").equalsIgnoreCase("RSA") ||
					!key.has("n") ||
					!key.has("e")
				)	throw new JWTException("Tipo de chave nao suportada");
				return key;
			}
			catch (final IllegalArgumentException e) { throw new JWTException("Argumento nao e um BASE64URL valido"); }
			catch (final JSONException e) { throw new JWTException("Argumento nao e um JSON valido", e); }
		}
		public JSONObject decodePayload(final String payload) throws JWTException
		{
			try
			{
				JSONObject json = new JSONObject(new String(Base64.getUrlDecoder().decode(payload.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8));
				if
				(
					!json.has("iss") ||
					!json.has("sub") ||
					!json.has("aud") ||
					!json.has("iat") ||
					!json.has("exp") ||
					!json.has("jti") ||
					!json.has("name")
				)	throw new JWTException( "Argumento nao e um payload JWT valido");
				final long expires = json.getLong("exp");
				if ((System.currentTimeMillis() / 1000) > expires) throw new JWTException("Token JWT expirado");
				return json;
			}
			catch (final IllegalArgumentException e) { throw new JWTException("Argumento nao e um BASE64URL valido"); }
			catch (final JSONException e) { throw new JWTException("Argumento nao e um JSON valido", e); }
		}
		public RSAPublicKey getRSAKey(final String n, final String e) throws GeneralSecurityException
		{
			final Decoder decoder = Base64.getUrlDecoder();
			try
			{
				final RSAPublicKeySpec spec = new RSAPublicKeySpec
				(
					new BigInteger(decoder.decode(n.getBytes(StandardCharsets.UTF_8))),
					new BigInteger(decoder.decode(e.getBytes(StandardCharsets.UTF_8)))
				);
				return (RSAPublicKey) KeyFactory.getInstance("RSA").generatePublic(spec);
			}
			catch (final RuntimeException ex) { throw new GeneralSecurityException("Argumentos nao sao uma chave RSA valida", ex); }
		}
		public void verify(final String header, final String payload, final String signature, final RSAPublicKey pubKey, final String alg) throws GeneralSecurityException
		{
			try
			{
				final Signature verifier = Signature.getInstance(getJavaAlgorithm(alg));
				verifier.initVerify(pubKey);
				verifier.update((new StringBuilder(4096)).append(header).append(".").append(payload).toString().getBytes(StandardCharsets.UTF_8));
				if (!verifier.verify(Base64.getUrlDecoder().decode(signature.getBytes(StandardCharsets.UTF_8)))) throw new SignatureException("Falha na verificacao da assinatura do Token JWT");
			}
			catch (final RuntimeException e) { throw new GeneralSecurityException("Argumento signature codificado incorretamente", e);  }
		}
		public String decode(final String jwt, final String name) throws JWTException, GeneralSecurityException
		{
			if (jwt == null) throw new IllegalArgumentException("Argumento nao pode ser nulo");
			final String[] parts = jwt.split("\\.");
			if (parts.length != 3) throw new JWTException("Argumento nao codificado em conformidade a RFC 7515");
			final JSONObject header = decodeHeader(parts[0]);
			final JSONObject key = decodeJWK(header.getString("jwk"));
			final JSONObject payload = decodePayload(parts[1]);
			if (!payload.getString("name").equalsIgnoreCase(name)) throw new JWTException("Argumento name nao coincide com o atributo assinado");
			if
			(
				!payload.getString("iss").equalsIgnoreCase(DEFAULT_ISSUER) ||
				!payload.getString("sub").equalsIgnoreCase(DEFAULT_SUBJECT) ||
				!payload.getString("aud").equalsIgnoreCase(JWT.DEFAULT_AUDIENCE) ||
				payload.getLong("iat") == 0L ||
				payload.getString("jti").isEmpty()
			) throw new JWTException( "Argumento nao e um payload JWT valido para o CNS");
			try { Long.parseLong(payload.getString("name")); }
			catch (final NumberFormatException e) { throw new JWTException("Atributo name nao e valido para o CNS", e); }
			verify(parts[0], parts[1], parts[2], getRSAKey(key.getString("n"), key.getString("e")), header.getString("alg"));
			return payload.getString("jti");
		}
	}



	private static final long serialVersionUID = 5248902389151522176L;

	public static final String DEFAULT_ISSUER		= "http://cns.caixa.gov.br";
	public static final String DEFAULT_SUBJECT	= "ACP-5003473-95.2017.4.04.7102/RS";
	public static final String DEFAULT_AUDIENCE	= "SEFIP";
	public static final String DEFAULT_ALGORITHM	= "RS256";

	/**
	 * Chaves para os campos requeridos no arquivo de propriedades
	 * Editar o arquivo já definido na rotina da obfuscação da senha e
	 * acrescentar a chave br.gov.caixa.cns.keyalias com o alias da 
	 * chave privada e certificado de assinatura do CNS
	 */
	public static final String KEY_STORE_ENTRY	= "javax.net.ssl.keyStore";
	public static final String KEY_STORE_PWD_ENTRY	= "javax.net.ssl.keyStorePassword";
	public static final String KEY_STORE_TYPE_ENTRY= "javax.net.ssl.keyStoreType";
	public static final String KEY_ALIAS_ENTRY	= "br.gov.caixa.cns.keyalias";
	
	static RSAPrivateKey _PRIVKEY = null;
	static Long _EXPIRATION = 0L;
	static RSAPublicKey _PUBKEY = null;
	static String _JWK_VALUE = null;
	/**
	 * Inicializa a implementação
	 * @param 	Properties		props arquivo de propriedades de configuração do CNS, com as informações requeridas
	 * 					para o carregamento do key store onde está armazenada a chave privada de assinatura
	 * 					do CNS e seu respectivo certificado. As seguintes entradas são requeridas:<br>
	 * 					<ul>
	 * 						<li> javax.net.ssl.keyStore: caminho para o arquivo de key store
	 * 						<li> javax.net.ssl.keyStoreType: tipo de key store (jks ou pkcs12)
	 * 						<li> javax.net.ssl.keyStorePassword: senha de acesso (ver o problema da obfuscação da senha)
	 * 						<li> br.gov.caixa.cns.keyalias: alias da chave privada. Deve coincidir com o alias do certificado de assinatura.
	 * 					</ul>
	 * @throws	InitException	ocorrendo falha na composição do arquivo de propriedades ou na carga do key store
	 */
	public static void init(final Properties props) throws InitException
	{
		final String loc = props.getProperty(KEY_STORE_ENTRY);
		final String pwd = props.getProperty(KEY_STORE_PWD_ENTRY);
		final String type = props.getProperty(KEY_STORE_TYPE_ENTRY);
		final String alias = props.getProperty(KEY_ALIAS_ENTRY);
		if (loc == null || pwd == null || type == null || alias == null) throw new ConfigurationException("Configuração de key store inválida");
		try
		{
			// Carrega o KeyStore do assinante
			final FileInputStream in = new FileInputStream(new File(loc));
			try
			{
				final KeyStore store = KeyStore.getInstance(type);
				store.load(in, pwd.toCharArray());
				_PRIVKEY = (RSAPrivateKey) store.getKey(alias, pwd.toCharArray());
				final X509Certificate cert = (X509Certificate) store.getCertificate(alias);
				_EXPIRATION = cert.getNotAfter().getTime() / 1000;
				_PUBKEY = (RSAPublicKey) cert.getPublicKey();
			}
			finally { in.close(); }

			// Gera o keyset JWS
			final Encoder encoder = Base64.getUrlEncoder();
			final StringWriter keyWriter = new StringWriter(2048);
			(new JSONWriter(keyWriter))
				.array()
				.object()
				.key("kty").value("RSA")
				.key("use").value("sig")
				.key("n").value((new String(encoder.encode(_PUBKEY.getModulus().toByteArray()), StandardCharsets.UTF_8)).replace("=", ""))
				.key("e").value((new String(encoder.encode(_PUBKEY.getPublicExponent().toByteArray()), StandardCharsets.UTF_8)).replace("=", ""))
				.endObject()
				.endArray();
			final StringWriter ksWriter = new StringWriter(2048);
			(new JSONWriter(ksWriter))
				.object()
				.key("keys").value(new JSONArray(keyWriter.toString()))
				.endObject();
			_JWK_VALUE = (new String(encoder.encode(ksWriter.toString().getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8)).replace("=", "");
		}
		catch (final IOException e) { throw new InitException("Falha no carregamento do key store", e); }
		catch (final GeneralSecurityException e) { throw new InitException("Falha no acesso as chaves do key store", e); }
		catch (final ClassCastException e) { throw new InitException("Chaves do tipo invalido no key store"); }
	}
	/**
	 * Obtém um encoder com os atributos JWT default, a saber:<br>
	 * <ol>
	 * 	<li>issuer:    http://cns.caixa.gov.br<li>
	 * 	<li>subject:   ACP-5003473-95.2017.4.04.7102/RS</li>
	 * 	<li>audience:  SEFIP</li>
	 * 	<li>algorithm: RS256</li>
	 * </ol>
	 * @return uma nova instância do facade
	 */
	public static JWTEncoder getEncoder() throws NoSuchAlgorithmException { return getEncoder(DEFAULT_ISSUER, DEFAULT_SUBJECT, DEFAULT_AUDIENCE, DEFAULT_ALGORITHM); }
	public static JWTEncoder getEncoder(final String issuer, final String subject, final String audience, final String algorithm) throws NoSuchAlgorithmException
	{
		return new JWT.JWTEncoder(issuer, subject, audience, algorithm);
	}
	/**
	 * Obtém um decoder com os atributos JWT default, a saber:<br>
	 * <ol>
	 * 	<li>issuer:    http://cns.caixa.gov.br<li>
	 * 	<li>subject:   ACP-5003473-95.2017.4.04.7102/RS</li>
	 * 	<li>audience:  SEFIP</li>
	 * </ol>
	 * @return uma nova instância do facade
	 */
	public static JWTDecoder getDecoder() { return getDecoder(DEFAULT_ISSUER, DEFAULT_SUBJECT, DEFAULT_AUDIENCE); }
	public static JWTDecoder getDecoder(final String issuer, final String subject, final String audience)
	{
		return new JWT.JWTDecoder(issuer, subject, audience);
	}

	protected final String _issuer;
	protected final String _subject;
	protected final String _audience;
	protected JWT(final String issuer, final String subject, final String audience)
	{
		if (_PRIVKEY == null || _PUBKEY == null || _EXPIRATION == 0L || _JWK_VALUE == null) throw new IllegalStateException("Instancias da classe requerem a chamada previa a JWt.init()");
		_issuer = issuer;
		_subject = subject;
		_audience = audience;
	}
	public String getJavaAlgorithm(final String algorithm) throws NoSuchAlgorithmException
	{
		if      (algorithm.equalsIgnoreCase("RS256")) return "SHA256withRSA";
		else if (algorithm.equalsIgnoreCase("RS384")) return "SHA384withRSA";
		else if (algorithm.equalsIgnoreCase("RS512")) return "SHA512withRSA";
		else throw new NoSuchAlgorithmException("Algoritmo nao suportado: " + algorithm);
	}

	public static void main( String[] args ) throws Exception
	{
		System.out.println("Teste de unidade da implementacao JWT...");
		final Properties props = new Properties();
		props.setProperty(KEY_STORE_ENTRY, "src/main/resources/test.pfx");
		props.setProperty(KEY_STORE_TYPE_ENTRY, "pkcs12");
		props.setProperty(KEY_STORE_PWD_ENTRY, "secret");
		props.setProperty(KEY_ALIAS_ENTRY, "signer");
		JWT.init(props);

		final String cnpj = "87766487000104";
		final String guid = UUID.randomUUID().toString();
		final String token = JWT.getEncoder().issue(cnpj, guid);
		System.out.println("Token JWT emitido: [\n" + token + "\n]");
		if (JWT.getDecoder().decode(token, cnpj).equalsIgnoreCase(guid)) System.out.println("Teste bem sucedido");
		else System.err.println("GUID retornado pela verificacao nao coincide com o emitido: " + guid);
	}
}
