package br.gov.caixa.cnscx.api;

public class InitException extends JWTException
{
	private static final long serialVersionUID = 392564235219820909L;
	public InitException(final String message) { super(message); }
	public InitException(final String message, final Throwable cause) { super(message, cause); }
}
