package br.gov.caixa.ecaixa.adapters;

import java.io.IOException;
import java.sql.SQLException;

/**
 * O trabalhador que faz o todo o esforço.
 */
public interface BusinessWorker
{
	/**
	 * Executa o processamento esperado do bean
	 * @param bean: feijãozinho de negócio
	 * @return seja lá o que for o resultado do processamento. Na implementação Quarkus, não
	 * é esperado que o resultado desse processamento seja recebido pelo chamador, já que a
	 * ideia é lançar uma thread e sair. No entanto, a implementação Things pode e deve
	 * considerar o resultado desse processamento em cada uma das threads de execução.
	 * @throws IOException em caso de falha de I/0 (assumida como transiente)
	 * @throws SQLException em caso de falha de acesso ao banco (assumida como transiente)
	 */
	Object toil(Bean bean) throws IOException, SQLException;
}
