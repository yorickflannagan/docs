package br.gov.caixa.ecaixa.adapters;

/**
 * Exceção disparada durante a inicialização de algum objeto
 * ou devido à falta de inicialização dele
 */
public class InitException extends Exception
{
	private static final long serialVersionUID = 8850587856420119902L;
	public InitException() { super(); }
	public InitException(final String msg) { super(msg); }
	public InitException(final Throwable e) { super(e); }
	public InitException(final String msg, final Throwable e) { super(msg, e); }
}
