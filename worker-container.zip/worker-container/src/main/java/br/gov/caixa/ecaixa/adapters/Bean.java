package br.gov.caixa.ecaixa.adapters;

/**
 * Todos os objetos de negócio devem descender deste bean.
 * Trata-se do mesmo objeto proposto no modelo anterior. (Usar aquele)
 * Ele existe apenas para marcar os objetos recebidos pelo BusinessWorker
 */
public abstract class Bean
{
	private final String name;
	protected Bean(final String name) { this.name = name; }
	public String getName() { return name; }
}
