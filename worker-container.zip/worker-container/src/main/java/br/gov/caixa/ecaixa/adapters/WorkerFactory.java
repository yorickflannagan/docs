package br.gov.caixa.ecaixa.adapters;

import java.util.Properties;

/**
 * A mãe de todas as fábricas de trabalhadores
 */
public abstract class WorkerFactory
{
	protected final Properties config;
	/**
	 * Cria uma nova instância da fábrica
	 * @param props: configurações eventualmente requeridas
	 * @throws InitException em caso de configuração inválida
	 */
	protected WorkerFactory(final Properties props) throws InitException
	{
		this.config = props;
	}
	/**
	 * Retorna uma nova instância do trabalhador braçal
	 * @return a instância
	 */
	public abstract BusinessWorker newWorker();
}
