package br.gov.caixa.ecaixa.adapters;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.crypthing.things.appservice.ThingsService;
import org.crypthing.things.snmp.ProcessingEvent;
import org.crypthing.things.snmp.SignalBean;
import org.crypthing.things.snmp.ProcessingEvent.ProcessingEventType;

/**
 * Supervisor do trabalho escravo.
 */
public class Overseer
{
	private static WorkerFactory _factory;
	private static ExecutorService _service;
	private static String _endpoint;
	/**
	 * Inicia o supervisor. Execute em @PostConstruct
	 * @param endpoint: nome distinto do endpoint (para identificação inequívoca no log)
	 * @param factory: instância da factory de trabalhadores apropriada
	 * @throws InitException em caso de falha na inicialização
	 */
	public static void init(final String endpoint, final WorkerFactory factory)  throws InitException
	{
		if
		(
			(_factory = factory) == null ||
			(_endpoint = endpoint) == null
		)	throw new InitException("Arguments must not be null", new NullPointerException());
		_service = Executors.newCachedThreadPool();
	}
	/**
	 * Finaliza graciosamente o supervisor. Execute em @PreDestroy
	 */
	public static void stop()
	{
		if (_service != null) _service.shutdown();
	}

	private ThingsService things;
	public Overseer(final ThingsService things) { this.things = things; }
	/**
	 * Submete a tarefa do trabalhador.
	 * @param bean: objeto de negócio a processar
	 * @return a tarefa
	 * @throws InitException em caso de a classe não ter sido inicializada estaticamente
	 */
	public Future<?> getTask(final Bean bean) throws InitException
	{
		if (_factory == null || _service == null) throw new InitException("Must run init() static method");
		return _service.submit(new Runner(bean));
	}

	/**
	 * A tarefa a ser executada numa thread à parte
	 */
	private class Runner implements Callable<Object>
	{
		private final BusinessWorker _worker;
		private final Bean _bean;
		/**
		 * Cria uma nova tarefa
		 * @param bean: objeto de negócio a ser processado.
		 */
		Runner(final Bean bean)
		{
			_worker = _factory.newWorker();
			_bean = bean;
		}
		@Override
		public Object call() throws Exception
		{
			Object ret = null;
			try
			{
				ret = _worker.toil(_bean);
				things.info
				(
					new ProcessingEvent
					(
						ProcessingEventType.info,
						new SignalBean
						(
							_endpoint,
							new StringBuilder(1024)
								.append("Resultado do processamento do bean ")
								.append(_bean.getName())
								.append(": ")
								.append(ret)
								.toString()
						).encode()
					)
				);
				things.success();
			}
			catch (final Exception e)
			{
				things.error(new ProcessingEvent(ProcessingEventType.error, e.getMessage(), e));
				things.failure();
			}
			return ret;
		}
	}
}
