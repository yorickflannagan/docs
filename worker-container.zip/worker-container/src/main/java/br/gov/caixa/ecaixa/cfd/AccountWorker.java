package br.gov.caixa.ecaixa.cfd;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;

import br.gov.caixa.ecaixa.adapters.Bean;
import br.gov.caixa.ecaixa.adapters.BusinessWorker;

/**
 * Implementação da tarefa de processamento das individualizações do FGTS Digital
 */
public class AccountWorker implements BusinessWorker
{
	public AccountWorker(final Properties props)
	{
		// TODO: Inicializar o worker
	}
	@Override
	public Object toil(final Bean bean) throws IOException, SQLException
	{
		/* TODO: Implementar o trabalho sujo
		 * É esperado que as informações necessárias à execução tenham sido passadas nas
		 * Properties de inicialização:
		 * 1. Verifica se existem vínculos a serem recompostos
		 * 2. Para cada vínculo a ser recomposto:
		 * 2.1. Consulta o serviço do Serpro
		 * 2.2. Valida a resposta?
		 * 2.3. Solicita a criação do vínculo ao FUG
		 * 2.4. Adiciona o IVC ao documento
		 * 2.5. Grava o IVC no BD
		 * 3. Despacha a guia completa para o FUG
		 * 4. Atualiza o BD com CONTEUDO_SOLICITACAO.IC_DIRECAO = 2 (despachado para o FUG)
		 * 5. Retorne algum indicador de tarefa completada com sucesso (ou não)
		 */
		return true;
	}
	
}
