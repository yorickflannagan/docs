package br.gov.caixa.ecaixa.cfd;

import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.crypthing.things.appservice.ThingsService;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import br.gov.caixa.ecaixa.adapters.Bean;
import br.gov.caixa.ecaixa.adapters.InitException;
import br.gov.caixa.ecaixa.adapters.Overseer;
import io.quarkus.runtime.Startup;

/**
 * Classe estritamente para demonstração e teste.
 */
@Path("/demo")
@Startup
public class ContainerDemo
{
	@Inject
	ThingsService _things;
	@ConfigProperty(name = "br.gov.caixa.ecaixa.endpoint", defaultValue = "br.gov.caixa.ecaixa.cfd.demo")
	String _endpoint;

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public Response hello()
	{
		if (_things == null) System.out.println("Holy shit!");
		String entity;
		Status status;

		/* Finja que tudo isso ocorreu
		 * 1. Recebe do Serpro
		 * 2. Efetua validação do documento
		 * 3. Calcula o protocolo (o hash do documento com um timestamp)
		 * 4. Grava no BD, indicando CONTEUDO_SOLICITACAO.IC_DIRECAO = 1 (a despachar)
		 */
		final Bean bean = new Individualizacao();
		final Overseer supervisor = new Overseer(_things);
		try
		{
			final Future<?> task = supervisor.getTask(bean);
			/* Na "vida real" você não precisa fazer nada com a task.
			 * Simplesmente devolva o protocolo ao Serpro e vá descansar.
			 * Nesta demonstração nós esperamos o resultado do processamento para fingir
			 * que estamos testando o endpoint...
			 */
			Object ret = task.get();
			status = Status.OK;
			entity = "Resultado da operação: " + ret;
		}
		catch (final InitException | InterruptedException | ExecutionException e)
		{
			e.printStackTrace();
			status = Status.INTERNAL_SERVER_ERROR;
			entity = e.getMessage();
		} 
		return Response.status(status).entity(entity).build();
	}

	@PostConstruct
	public void onStart()
	{
		try
		{
			final Properties props = new Properties();
			// TODO: Obtenha as variáveis necessárias à inicialização da factory e do worker da sua configuração
			Overseer.init(_endpoint, new WorkerFactoryImpl(props));
		}
		catch (final InitException e)
		{
			// Holy shit!
			e.printStackTrace();
		}
	}
	@PreDestroy
	public void onDestroy()
	{
		// Sempre finalize o supervisor, para garantir consistência no banco de dados
		Overseer.stop();
	}
	// Finja que isso é um bean de negócio
	private class Individualizacao extends Bean
	{
		public Individualizacao() { super("Individualizacao"); }
	}
}