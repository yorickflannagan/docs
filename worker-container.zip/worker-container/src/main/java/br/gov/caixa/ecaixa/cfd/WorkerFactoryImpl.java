package br.gov.caixa.ecaixa.cfd;

import java.util.Properties;

import br.gov.caixa.ecaixa.adapters.BusinessWorker;
import br.gov.caixa.ecaixa.adapters.InitException;
import br.gov.caixa.ecaixa.adapters.WorkerFactory;

/**
 * Implementação da factory para a individualização
 */
public class WorkerFactoryImpl extends WorkerFactory
{
	public WorkerFactoryImpl(final Properties props) throws InitException
	{
		super(props);
		// TODO: seja lá o que for necessário
	}

	@Override
	public BusinessWorker newWorker()
	{
		// TODO: seja lá o que for necessário
		return new AccountWorker(this.config);
	}

}
